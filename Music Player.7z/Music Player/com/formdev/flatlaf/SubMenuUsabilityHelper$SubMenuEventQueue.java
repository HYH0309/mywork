//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.awt.AWTEvent;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import javax.swing.Timer;

class SubMenuUsabilityHelper$SubMenuEventQueue extends EventQueue {
    private Timer mouseUpdateTimer;
    private Timer timeoutTimer;
    private int newMouseX;
    private int newMouseY;
    private AWTEvent lastMouseEvent;

    SubMenuUsabilityHelper$SubMenuEventQueue(SubMenuUsabilityHelper var1) {
        this.this$0 = var1;
        this.mouseUpdateTimer = new Timer(50, (e) -> {
            SubMenuUsabilityHelper.access$202(this.this$0, this.newMouseX);
            SubMenuUsabilityHelper.access$302(this.this$0, this.newMouseY);
            if (SubMenuUsabilityHelper.access$000(this.this$0) != null) {
                SubMenuUsabilityHelper.access$000(this.this$0).repaint();
            }

        });
        this.mouseUpdateTimer.setRepeats(false);
        this.timeoutTimer = new Timer(200, (e) -> {
            if (SubMenuUsabilityHelper.access$400(this.this$0) != null && !SubMenuUsabilityHelper.access$400(this.this$0).contains(this.newMouseX, this.newMouseY)) {
                if (this.lastMouseEvent != null) {
                    this.postEvent(this.lastMouseEvent);
                    this.lastMouseEvent = null;
                }

                SubMenuUsabilityHelper.access$500(this.this$0);
            }
        });
        this.timeoutTimer.setRepeats(false);
        Toolkit.getDefaultToolkit().getSystemEventQueue().push(this);
    }

    void uninstall() {
        this.mouseUpdateTimer.stop();
        this.mouseUpdateTimer = null;
        this.timeoutTimer.stop();
        this.timeoutTimer = null;
        this.lastMouseEvent = null;
        super.pop();
    }

    protected void dispatchEvent(AWTEvent e) {
        int id = e.getID();
        if (e instanceof MouseEvent && (id == 503 || id == 506)) {
            this.newMouseX = ((MouseEvent)e).getXOnScreen();
            this.newMouseY = ((MouseEvent)e).getYOnScreen();
            if (SubMenuUsabilityHelper.access$000(this.this$0) != null) {
                SubMenuUsabilityHelper.access$000(this.this$0).repaint();
            }

            this.mouseUpdateTimer.stop();
            this.timeoutTimer.stop();
            if (SubMenuUsabilityHelper.access$100(this.this$0).contains(this.newMouseX, this.newMouseY)) {
                this.mouseUpdateTimer.start();
                this.timeoutTimer.start();
                this.lastMouseEvent = e;
                return;
            }

            SubMenuUsabilityHelper.access$202(this.this$0, this.newMouseX);
            SubMenuUsabilityHelper.access$302(this.this$0, this.newMouseY);
        }

        super.dispatchEvent(e);
    }
}
