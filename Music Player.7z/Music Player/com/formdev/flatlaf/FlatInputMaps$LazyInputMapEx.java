//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import javax.swing.InputMap;
import javax.swing.LookAndFeel;
import javax.swing.UIDefaults;
import javax.swing.plaf.InputMapUIResource;

class FlatInputMaps$LazyInputMapEx implements UIDefaults.LazyValue {
    private final Object[][] bindingsArray;

    FlatInputMaps$LazyInputMapEx(Object[]... bindingsArray) {
        this.bindingsArray = bindingsArray;
    }

    public Object createValue(UIDefaults table) {
        InputMap inputMap = new InputMapUIResource();
        Object[][] var3 = this.bindingsArray;
        int var4 = var3.length;

        for(int var5 = 0; var5 < var4; ++var5) {
            Object[] bindings = var3[var5];
            LookAndFeel.loadKeyBindings(inputMap, bindings);
        }

        return inputMap;
    }
}
