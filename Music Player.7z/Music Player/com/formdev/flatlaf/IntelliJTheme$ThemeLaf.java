//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.util.ArrayList;
import javax.swing.UIDefaults;

public class IntelliJTheme$ThemeLaf extends FlatLaf {
    private final IntelliJTheme theme;

    public IntelliJTheme$ThemeLaf(IntelliJTheme theme) {
        this.theme = theme;
    }

    public String getName() {
        return this.theme.name;
    }

    public String getDescription() {
        return this.getName();
    }

    public boolean isDark() {
        return this.theme.dark;
    }

    public IntelliJTheme getTheme() {
        return this.theme;
    }

    void applyAdditionalDefaults(UIDefaults defaults) {
        IntelliJTheme.access$000(this.theme, defaults);
    }

    protected ArrayList<Class<?>> getLafClassesForDefaultsLoading() {
        ArrayList<Class<?>> lafClasses = new ArrayList();
        lafClasses.add(FlatLaf.class);
        lafClasses.add(this.theme.dark ? FlatDarkLaf.class : FlatLightLaf.class);
        lafClasses.add(this.theme.dark ? FlatDarculaLaf.class : FlatIntelliJLaf.class);
        lafClasses.add(IntelliJTheme$ThemeLaf.class);
        return lafClasses;
    }
}
