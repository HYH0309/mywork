//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import javax.swing.Icon;

public interface FlatLaf$DisabledIconProvider {
    Icon getDisabledIcon();
}
