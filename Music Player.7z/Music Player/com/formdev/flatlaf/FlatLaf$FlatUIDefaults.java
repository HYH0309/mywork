//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.util.List;
import java.util.Locale;
import java.util.function.Function;
import javax.swing.UIDefaults;
import javax.swing.plaf.metal.MetalLookAndFeel;

class FlatLaf$FlatUIDefaults extends UIDefaults {
    private UIDefaults metalDefaults;

    FlatLaf$FlatUIDefaults(FlatLaf var1, int initialCapacity, float loadFactor) {
        super(initialCapacity, loadFactor);
        this.this$0 = var1;
    }

    public Object get(Object key) {
        return this.get(key, (Locale)null);
    }

    public Object get(Object key, Locale l) {
        Object value = this.getFromUIDefaultsGetters(key);
        if (value != null) {
            return value != FlatLaf.NULL_VALUE ? value : null;
        } else {
            value = super.get(key, l);
            if (value != null) {
                return value;
            } else {
                return key instanceof String && ((String)key).startsWith("FileChooser.") ? this.getFromMetal((String)key, l) : null;
            }
        }
    }

    private Object getFromUIDefaultsGetters(Object key) {
        List<Function<Object, Object>> uiDefaultsGetters = FlatLaf.access$200(this.this$0);
        if (uiDefaultsGetters == null) {
            return null;
        } else {
            for(int i = uiDefaultsGetters.size() - 1; i >= 0; --i) {
                Object value = ((Function)uiDefaultsGetters.get(i)).apply(key);
                if (value != null) {
                    return value;
                }
            }

            return null;
        }
    }

    private synchronized Object getFromMetal(String key, Locale l) {
        if (this.metalDefaults == null) {
            this.metalDefaults = (new MetalLookAndFeel() {
                protected void initClassDefaults(UIDefaults table) {
                }

                protected void initSystemColorDefaults(UIDefaults table) {
                }
            }).getDefaults();
            this.metalDefaults.clear();
        }

        return this.metalDefaults.get(key, l);
    }
}
