//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.icons;

import java.awt.Graphics2D;

public class FlatRadioButtonMenuItemIcon extends FlatCheckBoxMenuItemIcon {
    public FlatRadioButtonMenuItemIcon() {
    }

    protected void paintCheckmark(Graphics2D g2) {
        g2.fillOval(4, 4, 7, 7);
    }
}
