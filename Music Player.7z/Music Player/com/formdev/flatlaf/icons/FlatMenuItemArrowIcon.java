//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.icons;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class FlatMenuItemArrowIcon extends FlatAbstractIcon {
    public FlatMenuItemArrowIcon() {
        super(6, 10, (Color)null);
    }

    public void paintIcon(Component c, Graphics g, int x, int y) {
    }

    protected void paintIcon(Component c, Graphics2D g) {
    }
}
