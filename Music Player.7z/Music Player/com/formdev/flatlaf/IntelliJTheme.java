//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import com.formdev.flatlaf.json.Json;
import com.formdev.flatlaf.json.ParseException;
import com.formdev.flatlaf.util.ColorFunctions;
import com.formdev.flatlaf.util.LoggingFacade;
import com.formdev.flatlaf.util.StringUtils;
import com.formdev.flatlaf.util.SystemInfo;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.UIDefaults;
import javax.swing.plaf.ColorUIResource;

public class IntelliJTheme {
    public final String name;
    public final boolean dark;
    public final String author;
    private final boolean isMaterialUILite;
    private Map<String, String> colors;
    private Map<String, Object> ui;
    private Map<String, Object> icons;
    private Map<String, ColorUIResource> namedColors = Collections.emptyMap();
    private static final Set<String> uiKeyExcludes = new HashSet(Arrays.asList("ActionButton.", "ActionToolbar.", "ActionsList.", "AppInspector.", "AssignedMnemonic.", "Autocomplete.", "AvailableMnemonic.", "BigSpinner.", "Bookmark.", "BookmarkIcon.", "BookmarkMnemonicAssigned.", "BookmarkMnemonicAvailable.", "BookmarkMnemonicCurrent.", "BookmarkMnemonicIcon.", "Borders.", "Breakpoint.", "Canvas.", "CodeWithMe.", "ComboBoxButton.", "CompletionPopup.", "ComplexPopup.", "Content.", "CurrentMnemonic.", "Counter.", "Debugger.", "DebuggerPopup.", "DebuggerTabs.", "DefaultTabs.", "Dialog.", "DialogWrapper.", "DragAndDrop.", "Editor.", "EditorGroupsTabs.", "EditorTabs.", "FileColor.", "FlameGraph.", "Focus.", "Git.", "Github.", "GotItTooltip.", "Group.", "Gutter.", "GutterTooltip.", "HeaderColor.", "HelpTooltip.", "Hg.", "IconBadge.", "InformationHint.", "InplaceRefactoringPopup.", "Lesson.", "Link.", "LiveIndicator.", "MainMenu.", "MainToolbar.", "MemoryIndicator.", "MlModelBinding.", "MnemonicIcon.", "NavBar.", "NewClass.", "NewPSD.", "Notification.", "Notifications.", "NotificationsToolwindow.", "OnePixelDivider.", "OptionButton.", "Outline.", "ParameterInfo.", "Plugins.", "ProgressIcon.", "PsiViewer.", "ReviewList.", "RunWidget.", "ScreenView.", "SearchEverywhere.", "SearchFieldWithExtension.", "SearchMatch.", "SearchOption.", "SearchResults.", "SegmentedButton.", "Settings.", "SidePanel.", "Space.", "SpeedSearch.", "StateWidget.", "StatusBar.", "Tag.", "TipOfTheDay.", "ToolbarComboWidget.", "ToolWindow.", "UIDesigner.", "UnattendedHostStatus.", "ValidationTooltip.", "VersionControl.", "WelcomeScreen.", "darcula.", "dropArea.", "icons.", "intellijlaf.", "macOSWindow.", "material.", "tooltips.", "Checkbox.", "Toolbar.", "Tooltip.", "UiDesigner.", "link."));
    private static final Set<String> uiKeyDoNotOverride = new HashSet(Arrays.asList("TabbedPane.selectedForeground"));
    private static final Map<String, String> uiKeyMapping = new HashMap();
    private static final Map<String, String> uiKeyCopying = new LinkedHashMap();
    private static final Map<String, String> uiKeyInverseMapping = new HashMap();
    private static final Map<String, String> checkboxKeyMapping = new HashMap();
    private static final Map<String, String> checkboxDuplicateColors = new HashMap();

    public static boolean setup(InputStream in) {
        try {
            return FlatLaf.setup(createLaf(in));
        } catch (Exception var2) {
            Exception ex = var2;
            LoggingFacade.INSTANCE.logSevere("FlatLaf: Failed to load IntelliJ theme", ex);
            return false;
        }
    }

    /** @deprecated */
    @Deprecated
    public static boolean install(InputStream in) {
        return setup(in);
    }

    public static FlatLaf createLaf(InputStream in) throws IOException {
        return createLaf(new IntelliJTheme(in));
    }

    public static FlatLaf createLaf(IntelliJTheme theme) {
        return new ThemeLaf(theme);
    }

    public IntelliJTheme(InputStream in) throws IOException {
        Map json;
        try {
            Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8);

            try {
                json = (Map)Json.parse(reader);
            } catch (Throwable var7) {
                try {
                    reader.close();
                } catch (Throwable var6) {
                    var7.addSuppressed(var6);
                }

                throw var7;
            }

            reader.close();
        } catch (ParseException var8) {
            ParseException ex = var8;
            throw new IOException(ex.getMessage(), ex);
        }

        this.name = (String)json.get("name");
        this.dark = Boolean.parseBoolean((String)json.get("dark"));
        this.author = (String)json.get("author");
        this.isMaterialUILite = this.author.equals("Mallowigi");
        this.colors = (Map)json.get("colors");
        this.ui = (Map)json.get("ui");
        this.icons = (Map)json.get("icons");
    }

    private void applyProperties(UIDefaults defaults) {
        if (this.ui != null) {
            defaults.put("Component.isIntelliJTheme", true);
            defaults.put("Button.paintShadow", true);
            defaults.put("Button.shadowWidth", this.dark ? 2 : 1);
            Map<Object, Object> themeSpecificDefaults = this.removeThemeSpecificDefaults(defaults);
            this.loadNamedColors(defaults);
            ArrayList<Object> defaultsKeysCache = new ArrayList();
            Set<String> uiKeys = new HashSet();
            Iterator var5 = this.ui.entrySet().iterator();

            Map.Entry e;
            while(var5.hasNext()) {
                e = (Map.Entry)var5.next();
                this.apply((String)e.getKey(), e.getValue(), defaults, defaultsKeysCache, uiKeys);
            }

            this.applyColorPalette(defaults);
            this.applyCheckBoxColors(defaults);
            var5 = uiKeyCopying.entrySet().iterator();

            Object helpButtonBorderColor;
            while(var5.hasNext()) {
                e = (Map.Entry)var5.next();
                helpButtonBorderColor = defaults.get(e.getValue());
                if (helpButtonBorderColor != null) {
                    defaults.put(e.getKey(), helpButtonBorderColor);
                }
            }

            Object panelBackground = defaults.get("Panel.background");
            defaults.put("Button.disabledBackground", panelBackground);
            defaults.put("ToggleButton.disabledBackground", panelBackground);
            this.copyIfNotSet(defaults, "Button.focusedBorderColor", "Component.focusedBorderColor", uiKeys);
            defaults.put("Button.hoverBorderColor", defaults.get("Button.focusedBorderColor"));
            defaults.put("HelpButton.hoverBorderColor", defaults.get("Button.focusedBorderColor"));
            Object helpButtonBackground = defaults.get("Button.startBackground");
            helpButtonBorderColor = defaults.get("Button.startBorderColor");
            if (helpButtonBackground == null) {
                helpButtonBackground = defaults.get("Button.background");
            }

            if (helpButtonBorderColor == null) {
                helpButtonBorderColor = defaults.get("Button.borderColor");
            }

            defaults.put("HelpButton.background", helpButtonBackground);
            defaults.put("HelpButton.borderColor", helpButtonBorderColor);
            defaults.put("HelpButton.disabledBackground", panelBackground);
            defaults.put("HelpButton.disabledBorderColor", defaults.get("Button.disabledBorderColor"));
            defaults.put("HelpButton.focusedBorderColor", defaults.get("Button.focusedBorderColor"));
            defaults.put("HelpButton.focusedBackground", defaults.get("Button.focusedBackground"));
            Object textFieldBackground = this.get(defaults, themeSpecificDefaults, "TextField.background");
            defaults.put("ComboBox.editableBackground", textFieldBackground);
            defaults.put("Spinner.background", textFieldBackground);
            defaults.put("Spinner.buttonBackground", defaults.get("ComboBox.buttonEditableBackground"));
            defaults.put("Spinner.buttonArrowColor", defaults.get("ComboBox.buttonArrowColor"));
            defaults.put("Spinner.buttonDisabledArrowColor", defaults.get("ComboBox.buttonDisabledArrowColor"));
            this.putAll(defaults, textFieldBackground, "EditorPane.background", "FormattedTextField.background", "PasswordField.background", "TextArea.background", "TextPane.background");
            this.putAll(defaults, this.get(defaults, themeSpecificDefaults, "TextField.selectionBackground"), "EditorPane.selectionBackground", "FormattedTextField.selectionBackground", "PasswordField.selectionBackground", "TextArea.selectionBackground", "TextPane.selectionBackground");
            this.putAll(defaults, this.get(defaults, themeSpecificDefaults, "TextField.selectionForeground"), "EditorPane.selectionForeground", "FormattedTextField.selectionForeground", "PasswordField.selectionForeground", "TextArea.selectionForeground", "TextPane.selectionForeground");
            this.putAll(defaults, panelBackground, "ComboBox.disabledBackground", "EditorPane.disabledBackground", "EditorPane.inactiveBackground", "FormattedTextField.disabledBackground", "FormattedTextField.inactiveBackground", "PasswordField.disabledBackground", "PasswordField.inactiveBackground", "Spinner.disabledBackground", "TextArea.disabledBackground", "TextArea.inactiveBackground", "TextField.disabledBackground", "TextField.inactiveBackground", "TextPane.disabledBackground", "TextPane.inactiveBackground");
            if (!uiKeys.contains("ToggleButton.startBackground") && !uiKeys.contains("*.startBackground")) {
                defaults.put("ToggleButton.startBackground", defaults.get("Button.startBackground"));
            }

            if (!uiKeys.contains("ToggleButton.endBackground") && !uiKeys.contains("*.endBackground")) {
                defaults.put("ToggleButton.endBackground", defaults.get("Button.endBackground"));
            }

            if (!uiKeys.contains("ToggleButton.foreground") && uiKeys.contains("Button.foreground")) {
                defaults.put("ToggleButton.foreground", defaults.get("Button.foreground"));
            }

            Color desktopBackgroundBase = defaults.getColor("Panel.background");
            Color desktopBackground = ColorFunctions.applyFunctions(desktopBackgroundBase, new ColorFunctions.ColorFunction[]{new ColorFunctions.HSLIncreaseDecrease(2, this.dark, 5.0F, false, true)});
            defaults.put("Desktop.background", new ColorUIResource(desktopBackground));
            if (this.isMaterialUILite) {
                defaults.put("List.background", defaults.get("Tree.background"));
                defaults.put("Table.background", defaults.get("Tree.background"));
            }

            int rowHeight = defaults.getInt("Tree.rowHeight");
            if (rowHeight > 22) {
                defaults.put("Tree.rowHeight", 22);
            }

            HashMap<String, Object> wildcards = new HashMap();
            Iterator<Map.Entry<Object, Object>> it = themeSpecificDefaults.entrySet().iterator();

            while(it.hasNext()) {
                Map.Entry<Object, Object> e = (Map.Entry)it.next();
                String key = (String)e.getKey();
                if (key.startsWith("*.")) {
                    wildcards.put(key.substring("*.".length()), e.getValue());
                    it.remove();
                }
            }

            Object key;
            if (!wildcards.isEmpty()) {
                Object[] var23 = defaults.keySet().toArray();
                int var25 = var23.length;

                for(int var16 = 0; var16 < var25; ++var16) {
                    key = var23[var16];
                    int dot;
                    if (key instanceof String && (dot = ((String)key).lastIndexOf(46)) >= 0) {
                        String wildcardKey = ((String)key).substring(dot + 1);
                        Object wildcardValue = wildcards.get(wildcardKey);
                        if (wildcardValue != null) {
                            defaults.put(key, wildcardValue);
                        }
                    }
                }
            }

            Object key;
            for(Iterator var24 = themeSpecificDefaults.entrySet().iterator(); var24.hasNext(); defaults.put(key, key)) {
                Map.Entry<Object, Object> e = (Map.Entry)var24.next();
                key = e.getKey();
                key = e.getValue();
                if (key instanceof String && ((String)key).startsWith("[style]")) {
                    Object oldValue = defaults.get(key);
                    if (oldValue != null) {
                        key = oldValue + "; " + key;
                    }
                }
            }

            this.colors = null;
            this.ui = null;
            this.icons = null;
        }
    }

    private Object get(UIDefaults defaults, Map<Object, Object> themeSpecificDefaults, String key) {
        return themeSpecificDefaults.getOrDefault(key, defaults.get(key));
    }

    private void putAll(UIDefaults defaults, Object value, String... keys) {
        String[] var4 = keys;
        int var5 = keys.length;

        for(int var6 = 0; var6 < var5; ++var6) {
            String key = var4[var6];
            defaults.put(key, value);
        }

    }

    private Map<Object, Object> removeThemeSpecificDefaults(UIDefaults defaults) {
        ArrayList<String> themeSpecificKeys = new ArrayList();
        Iterator var3 = defaults.keySet().iterator();

        while(var3.hasNext()) {
            Object key = var3.next();
            if (key instanceof String && ((String)key).startsWith("[") && !((String)key).startsWith("[style]")) {
                themeSpecificKeys.add((String)key);
            }
        }

        Map<Object, Object> themeSpecificDefaults = new HashMap();
        String currentThemePrefix = '[' + this.name.replace(' ', '_') + ']';
        String currentThemeAndAuthorPrefix = '[' + this.name.replace(' ', '_') + "---" + this.author.replace(' ', '_') + ']';
        String currentAuthorPrefix = "[author-" + this.author.replace(' ', '_') + ']';
        String allThemesPrefix = "[*]";
        String[] prefixes = new String[]{currentThemePrefix, currentThemeAndAuthorPrefix, currentAuthorPrefix, allThemesPrefix};
        Iterator var9 = themeSpecificKeys.iterator();

        while(true) {
            while(var9.hasNext()) {
                String key = (String)var9.next();
                Object value = defaults.remove(key);
                String[] var12 = prefixes;
                int var13 = prefixes.length;

                for(int var14 = 0; var14 < var13; ++var14) {
                    String prefix = var12[var14];
                    if (key.startsWith(prefix)) {
                        themeSpecificDefaults.put(key.substring(prefix.length()), value);
                        break;
                    }
                }
            }

            return themeSpecificDefaults;
        }
    }

    private void loadNamedColors(UIDefaults defaults) {
        if (this.colors != null) {
            this.namedColors = new HashMap();
            Iterator var2 = this.colors.entrySet().iterator();

            while(var2.hasNext()) {
                Map.Entry<String, String> e = (Map.Entry)var2.next();
                String value = (String)e.getValue();
                ColorUIResource color = this.parseColor(value);
                if (color != null) {
                    String key = (String)e.getKey();
                    this.namedColors.put(key, color);
                    defaults.put("ColorPalette." + key, color);
                }
            }

        }
    }

    private void apply(String key, Object value, UIDefaults defaults, ArrayList<Object> defaultsKeysCache, Set<String> uiKeys) {
        String valueStr;
        if (value instanceof Map) {
            Map<String, Object> map = (Map)value;
            if (!map.containsKey("os.default") && !map.containsKey("os.windows") && !map.containsKey("os.mac") && !map.containsKey("os.linux")) {
                Iterator var15 = map.entrySet().iterator();

                while(var15.hasNext()) {
                    Map.Entry<String, Object> e = (Map.Entry)var15.next();
                    this.apply(key + '.' + (String)e.getKey(), e.getValue(), defaults, defaultsKeysCache, uiKeys);
                }
            } else {
                valueStr = SystemInfo.isWindows ? "os.windows" : (SystemInfo.isMacOS ? "os.mac" : (SystemInfo.isLinux ? "os.linux" : null));
                if (valueStr != null && map.containsKey(valueStr)) {
                    this.apply(key, map.get(valueStr), defaults, defaultsKeysCache, uiKeys);
                } else if (map.containsKey("os.default")) {
                    this.apply(key, map.get("os.default"), defaults, defaultsKeysCache, uiKeys);
                }
            }
        } else {
            if ("".equals(value)) {
                return;
            }

            if (key.endsWith(".border") || key.endsWith(".rowHeight") || key.equals("ComboBox.padding") || key.equals("Spinner.padding") || key.equals("Tree.leftChildIndent") || key.equals("Tree.rightChildIndent")) {
                return;
            }

            key = (String)uiKeyMapping.getOrDefault(key, key);
            if (key.isEmpty()) {
                return;
            }

            int dot = key.indexOf(46);
            if (dot > 0 && uiKeyExcludes.contains(key.substring(0, dot + 1))) {
                return;
            }

            if (uiKeyDoNotOverride.contains(key) && uiKeys.contains(key)) {
                return;
            }

            uiKeys.add(key);
            valueStr = value.toString();
            Object uiValue = this.namedColors.get(valueStr);
            if (uiValue == null) {
                if (!valueStr.startsWith("#") && (key.endsWith("ground") || key.endsWith("Color"))) {
                    valueStr = this.fixColorIfValid("#" + valueStr, valueStr);
                } else if (valueStr.startsWith("##")) {
                    valueStr = this.fixColorIfValid(valueStr.substring(1), valueStr);
                } else if (key.endsWith(".border") || key.endsWith("Border")) {
                    List<String> parts = StringUtils.split(valueStr, ',');
                    if (parts.size() == 5 && !((String)parts.get(4)).startsWith("#")) {
                        parts.set(4, "#" + (String)parts.get(4));
                        valueStr = String.join(",", parts);
                    }
                }

                try {
                    uiValue = UIDefaultsLoader.parseValue(key, valueStr, (Class)null);
                } catch (RuntimeException var13) {
                    RuntimeException ex = var13;
                    UIDefaultsLoader.logParseError(key, valueStr, ex, false);
                    return;
                }
            }

            if (key.startsWith("*.")) {
                String tail = key.substring(1);
                if (defaultsKeysCache.size() != defaults.size()) {
                    defaultsKeysCache.clear();
                    Enumeration<Object> e = defaults.keys();

                    while(e.hasMoreElements()) {
                        defaultsKeysCache.add(e.nextElement());
                    }
                }

                Iterator var19 = defaultsKeysCache.iterator();

                while(var19.hasNext()) {
                    Object k = var19.next();
                    if (!k.equals("Desktop.background") && !k.equals("DesktopIcon.background") && !k.equals("TabbedPane.focusColor") && k instanceof String) {
                        String km = (String)uiKeyInverseMapping.getOrDefault(k, (String)k);
                        if (km.endsWith(tail) && !((String)k).startsWith("CheckBox.icon.")) {
                            defaults.put(k, uiValue);
                        }
                    }
                }
            } else {
                defaults.put(key, uiValue);
            }
        }

    }

    private String fixColorIfValid(String newColorStr, String colorStr) {
        try {
            UIDefaultsLoader.parseColorRGBA(newColorStr);
            return newColorStr;
        } catch (IllegalArgumentException var4) {
            return colorStr;
        }
    }

    private void applyColorPalette(UIDefaults defaults) {
        if (this.icons != null) {
            Object palette = this.icons.get("ColorPalette");
            if (palette instanceof Map) {
                Map<String, Object> colorPalette = (Map)palette;
                Iterator var4 = colorPalette.entrySet().iterator();

                while(var4.hasNext()) {
                    Map.Entry<String, Object> e = (Map.Entry)var4.next();
                    String key = (String)e.getKey();
                    Object value = e.getValue();
                    if (!key.startsWith("Checkbox.") && value instanceof String) {
                        if (this.dark) {
                            key = StringUtils.removeTrailing(key, ".Dark");
                        }

                        ColorUIResource color = this.toColor((String)value);
                        if (color != null) {
                            defaults.put(key, color);
                        }
                    }
                }

            }
        }
    }

    private ColorUIResource toColor(String value) {
        ColorUIResource color = (ColorUIResource)this.namedColors.get(value);
        return color != null ? color : this.parseColor(value);
    }

    private ColorUIResource parseColor(String value) {
        try {
            return UIDefaultsLoader.parseColor(value);
        } catch (IllegalArgumentException var3) {
            return null;
        }
    }

    private void applyCheckBoxColors(UIDefaults defaults) {
        if (this.icons != null) {
            Object palette = this.icons.get("ColorPalette");
            if (palette instanceof Map) {
                boolean checkboxModified = false;
                Map<String, Object> colorPalette = (Map)palette;
                Iterator var5 = colorPalette.entrySet().iterator();

                String newKey;
                while(var5.hasNext()) {
                    Map.Entry<String, Object> e = (Map.Entry)var5.next();
                    String key = (String)e.getKey();
                    Object value = e.getValue();
                    if (key.startsWith("Checkbox.") && value instanceof String) {
                        if (this.dark) {
                            key = StringUtils.removeTrailing(key, ".Dark");
                        }

                        newKey = (String)checkboxKeyMapping.get(key);
                        if (newKey != null) {
                            String checkBoxIconPrefix = "CheckBox.icon.";
                            if (!this.dark && newKey.startsWith(checkBoxIconPrefix)) {
                                newKey = "CheckBox.icon[filled].".concat(newKey.substring(checkBoxIconPrefix.length()));
                            }

                            ColorUIResource color = this.toColor((String)value);
                            if (color != null) {
                                defaults.put(newKey, color);
                                String key2 = (String)checkboxDuplicateColors.get(key + ".Dark");
                                if (key2 != null) {
                                    if (this.dark) {
                                        key2 = StringUtils.removeTrailing(key2, ".Dark");
                                    }

                                    String newKey2 = (String)checkboxKeyMapping.get(key2);
                                    if (newKey2 != null) {
                                        defaults.put(newKey2, color);
                                    }
                                }
                            }

                            checkboxModified = true;
                        }
                    }
                }

                if (checkboxModified) {
                    defaults.remove("CheckBox.icon.focusWidth");
                    defaults.put("CheckBox.icon.hoverBorderColor", defaults.get("CheckBox.icon.focusedBorderColor"));
                    defaults.remove("CheckBox.icon[filled].focusWidth");
                    defaults.put("CheckBox.icon[filled].hoverBorderColor", defaults.get("CheckBox.icon[filled].focusedBorderColor"));
                    defaults.put("CheckBox.icon[filled].focusedSelectedBackground", defaults.get("CheckBox.icon[filled].selectedBackground"));
                    if (this.dark) {
                        String[] focusedBorderColorKeys = new String[]{"CheckBox.icon.focusedBorderColor", "CheckBox.icon.focusedSelectedBorderColor", "CheckBox.icon[filled].focusedBorderColor", "CheckBox.icon[filled].focusedSelectedBorderColor"};
                        String[] var15 = focusedBorderColorKeys;
                        int var16 = focusedBorderColorKeys.length;

                        for(int var17 = 0; var17 < var16; ++var17) {
                            newKey = var15[var17];
                            Color color = defaults.getColor(newKey);
                            if (color != null) {
                                defaults.put(newKey, new ColorUIResource(new Color(color.getRGB() & 16777215 | -1509949440, true)));
                            }
                        }
                    }
                }

            }
        }
    }

    private void copyIfNotSet(UIDefaults defaults, String destKey, String srcKey, Set<String> uiKeys) {
        if (!uiKeys.contains(destKey)) {
            defaults.put(destKey, defaults.get(srcKey));
        }

    }

    static {
        uiKeyMapping.put("ComboBox.background", "");
        uiKeyMapping.put("ComboBox.buttonBackground", "");
        uiKeyMapping.put("ComboBox.nonEditableBackground", "ComboBox.background");
        uiKeyMapping.put("ComboBox.ArrowButton.background", "ComboBox.buttonEditableBackground");
        uiKeyMapping.put("ComboBox.ArrowButton.disabledIconColor", "ComboBox.buttonDisabledArrowColor");
        uiKeyMapping.put("ComboBox.ArrowButton.iconColor", "ComboBox.buttonArrowColor");
        uiKeyMapping.put("ComboBox.ArrowButton.nonEditableBackground", "ComboBox.buttonBackground");
        uiKeyCopying.put("ComboBox.buttonSeparatorColor", "Component.borderColor");
        uiKeyCopying.put("ComboBox.buttonDisabledSeparatorColor", "Component.disabledBorderColor");
        uiKeyMapping.put("Component.inactiveErrorFocusColor", "Component.error.borderColor");
        uiKeyMapping.put("Component.errorFocusColor", "Component.error.focusedBorderColor");
        uiKeyMapping.put("Component.inactiveWarningFocusColor", "Component.warning.borderColor");
        uiKeyMapping.put("Component.warningFocusColor", "Component.warning.focusedBorderColor");
        uiKeyMapping.put("Link.activeForeground", "Component.linkColor");
        uiKeyMapping.put("Menu.border", "Menu.margin");
        uiKeyMapping.put("MenuItem.border", "MenuItem.margin");
        uiKeyCopying.put("CheckBoxMenuItem.margin", "MenuItem.margin");
        uiKeyCopying.put("RadioButtonMenuItem.margin", "MenuItem.margin");
        uiKeyMapping.put("PopupMenu.border", "PopupMenu.borderInsets");
        uiKeyCopying.put("MenuItem.underlineSelectionColor", "TabbedPane.underlineColor");
        uiKeyCopying.put("Menu.selectionBackground", "List.selectionBackground");
        uiKeyCopying.put("MenuItem.selectionBackground", "List.selectionBackground");
        uiKeyCopying.put("CheckBoxMenuItem.selectionBackground", "List.selectionBackground");
        uiKeyCopying.put("RadioButtonMenuItem.selectionBackground", "List.selectionBackground");
        uiKeyMapping.put("ProgressBar.background", "");
        uiKeyMapping.put("ProgressBar.foreground", "");
        uiKeyMapping.put("ProgressBar.trackColor", "ProgressBar.background");
        uiKeyMapping.put("ProgressBar.progressColor", "ProgressBar.foreground");
        uiKeyCopying.put("ProgressBar.selectionForeground", "ProgressBar.background");
        uiKeyCopying.put("ProgressBar.selectionBackground", "ProgressBar.foreground");
        uiKeyMapping.put("ScrollBar.trackColor", "ScrollBar.track");
        uiKeyMapping.put("ScrollBar.thumbColor", "ScrollBar.thumb");
        uiKeyMapping.put("Separator.separatorColor", "Separator.foreground");
        uiKeyMapping.put("Slider.trackWidth", "");
        uiKeyCopying.put("Slider.trackValueColor", "ProgressBar.foreground");
        uiKeyCopying.put("Slider.thumbColor", "ProgressBar.foreground");
        uiKeyCopying.put("Slider.trackColor", "ProgressBar.background");
        uiKeyCopying.put("Spinner.buttonSeparatorColor", "Component.borderColor");
        uiKeyCopying.put("Spinner.buttonDisabledSeparatorColor", "Component.disabledBorderColor");
        uiKeyMapping.put("DefaultTabs.underlinedTabBackground", "TabbedPane.selectedBackground");
        uiKeyMapping.put("DefaultTabs.underlinedTabForeground", "TabbedPane.selectedForeground");
        uiKeyMapping.put("DefaultTabs.inactiveUnderlineColor", "TabbedPane.inactiveUnderlineColor");
        uiKeyCopying.put("TitlePane.inactiveBackground", "TitlePane.background");
        uiKeyMapping.put("TitlePane.infoForeground", "TitlePane.foreground");
        uiKeyMapping.put("TitlePane.inactiveInfoForeground", "TitlePane.inactiveForeground");
        Iterator var0 = uiKeyMapping.entrySet().iterator();

        while(var0.hasNext()) {
            Map.Entry<String, String> e = (Map.Entry)var0.next();
            uiKeyInverseMapping.put((String)e.getValue(), (String)e.getKey());
        }

        uiKeyCopying.put("ToggleButton.tab.underlineColor", "TabbedPane.underlineColor");
        uiKeyCopying.put("ToggleButton.tab.disabledUnderlineColor", "TabbedPane.disabledUnderlineColor");
        uiKeyCopying.put("ToggleButton.tab.selectedBackground", "TabbedPane.selectedBackground");
        uiKeyCopying.put("ToggleButton.tab.hoverBackground", "TabbedPane.hoverColor");
        uiKeyCopying.put("ToggleButton.tab.focusBackground", "TabbedPane.focusColor");
        checkboxKeyMapping.put("Checkbox.Background.Default", "CheckBox.icon.background");
        checkboxKeyMapping.put("Checkbox.Background.Disabled", "CheckBox.icon.disabledBackground");
        checkboxKeyMapping.put("Checkbox.Border.Default", "CheckBox.icon.borderColor");
        checkboxKeyMapping.put("Checkbox.Border.Disabled", "CheckBox.icon.disabledBorderColor");
        checkboxKeyMapping.put("Checkbox.Focus.Thin.Default", "CheckBox.icon.focusedBorderColor");
        checkboxKeyMapping.put("Checkbox.Focus.Wide", "CheckBox.icon.focusColor");
        checkboxKeyMapping.put("Checkbox.Foreground.Disabled", "CheckBox.icon.disabledCheckmarkColor");
        checkboxKeyMapping.put("Checkbox.Background.Selected", "CheckBox.icon.selectedBackground");
        checkboxKeyMapping.put("Checkbox.Border.Selected", "CheckBox.icon.selectedBorderColor");
        checkboxKeyMapping.put("Checkbox.Foreground.Selected", "CheckBox.icon.checkmarkColor");
        checkboxKeyMapping.put("Checkbox.Focus.Thin.Selected", "CheckBox.icon.focusedSelectedBorderColor");
        checkboxDuplicateColors.put("Checkbox.Background.Default.Dark", "Checkbox.Background.Selected.Dark");
        checkboxDuplicateColors.put("Checkbox.Border.Default.Dark", "Checkbox.Border.Selected.Dark");
        checkboxDuplicateColors.put("Checkbox.Focus.Thin.Default.Dark", "Checkbox.Focus.Thin.Selected.Dark");
        Map.Entry<String, String>[] entries = (Map.Entry[])checkboxDuplicateColors.entrySet().toArray(new Map.Entry[checkboxDuplicateColors.size()]);
        Map.Entry[] var6 = entries;
        int var2 = entries.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            Map.Entry<String, String> e = var6[var3];
            checkboxDuplicateColors.put((String)e.getValue(), (String)e.getKey());
        }

    }

    public static class ThemeLaf extends FlatLaf {
        private final IntelliJTheme theme;

        public ThemeLaf(IntelliJTheme theme) {
            this.theme = theme;
        }

        public String getName() {
            return this.theme.name;
        }

        public String getDescription() {
            return this.getName();
        }

        public boolean isDark() {
            return this.theme.dark;
        }

        public IntelliJTheme getTheme() {
            return this.theme;
        }

        void applyAdditionalDefaults(UIDefaults defaults) {
            this.theme.applyProperties(defaults);
        }

        protected ArrayList<Class<?>> getLafClassesForDefaultsLoading() {
            ArrayList<Class<?>> lafClasses = new ArrayList();
            lafClasses.add(FlatLaf.class);
            lafClasses.add(this.theme.dark ? FlatDarkLaf.class : FlatLightLaf.class);
            lafClasses.add(this.theme.dark ? FlatDarculaLaf.class : FlatIntelliJLaf.class);
            lafClasses.add(ThemeLaf.class);
            return lafClasses;
        }
    }
}
