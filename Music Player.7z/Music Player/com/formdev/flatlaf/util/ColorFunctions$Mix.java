//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Color;

public class ColorFunctions$Mix implements ColorFunctions.ColorFunction {
    public final Color color2;
    public final float weight;

    public ColorFunctions$Mix(Color color2, float weight) {
        this.color2 = color2;
        this.weight = weight;
    }

    public void apply(float[] hsla) {
        Color color1 = HSLColor.toRGB(hsla[0], hsla[1], hsla[2], hsla[3] / 100.0F);
        Color color = ColorFunctions.mix(color1, this.color2, this.weight / 100.0F);
        float[] hsl = HSLColor.fromRGB(color);
        System.arraycopy(hsl, 0, hsla, 0, hsl.length);
        hsla[3] = (float)color.getAlpha() / 255.0F * 100.0F;
    }

    public String toString() {
        return String.format("mix(#%08x,%.0f%%)", this.color2.getRGB(), this.weight);
    }
}
