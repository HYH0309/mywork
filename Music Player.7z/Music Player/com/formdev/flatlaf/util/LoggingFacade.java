//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

public interface LoggingFacade {
    LoggingFacade INSTANCE = new LoggingFacadeImpl();

    void logSevere(String var1, Throwable var2);

    void logConfig(String var1, Throwable var2);
}
