//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

public class ColorFunctions$HSLChange implements ColorFunctions.ColorFunction {
    public final int hslIndex;
    public final float value;

    public ColorFunctions$HSLChange(int hslIndex, float value) {
        this.hslIndex = hslIndex;
        this.value = value;
    }

    public void apply(float[] hsla) {
        hsla[this.hslIndex] = this.hslIndex == 0 ? this.value % 360.0F : ColorFunctions.clamp(this.value);
    }

    public String toString() {
        String name;
        switch (this.hslIndex) {
            case 0:
                name = "changeHue";
                break;
            case 1:
                name = "changeSaturation";
                break;
            case 2:
                name = "changeLightness";
                break;
            case 3:
                name = "changeAlpha";
                break;
            default:
                throw new IllegalArgumentException();
        }

        return String.format("%s(%.0f%s)", name, this.value, this.hslIndex == 0 ? "" : "%");
    }
}
