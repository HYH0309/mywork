//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

@FunctionalInterface
public interface Animator$Interpolator {
    float interpolate(float var1);
}
