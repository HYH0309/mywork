//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Graphics2D;

public interface HiDPIUtils$Painter {
    void paint(Graphics2D var1, int var2, int var3, int var4, int var5, double var6);
}
