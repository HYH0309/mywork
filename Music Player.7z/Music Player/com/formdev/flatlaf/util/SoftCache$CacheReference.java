//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;

class SoftCache$CacheReference<K, V> extends SoftReference<V> {
    final K key;

    SoftCache$CacheReference(K key, V value, ReferenceQueue<? super V> queue) {
        super(value, queue);
        this.key = key;
    }
}
