//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

public class ColorFunctions$Fade implements ColorFunctions.ColorFunction {
    public final float amount;

    public ColorFunctions$Fade(float amount) {
        this.amount = amount;
    }

    public void apply(float[] hsla) {
        hsla[3] = ColorFunctions.clamp(this.amount);
    }

    public String toString() {
        return String.format("fade(%.0f%%)", this.amount);
    }
}
