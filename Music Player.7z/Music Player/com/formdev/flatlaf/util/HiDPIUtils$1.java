//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Graphics2D;
import java.awt.font.GlyphVector;
import java.text.AttributedCharacterIterator;

class HiDPIUtils$1 extends Graphics2DProxy {
    HiDPIUtils$1(Graphics2D delegate, float var2) {
        super(delegate);
        this.val$yCorrection = var2;
    }

    public void drawString(String str, int x, int y) {
        super.drawString(str, (float)x, (float)y + this.val$yCorrection);
    }

    public void drawString(String str, float x, float y) {
        super.drawString(str, x, y + this.val$yCorrection);
    }

    public void drawString(AttributedCharacterIterator iterator, int x, int y) {
        super.drawString(iterator, (float)x, (float)y + this.val$yCorrection);
    }

    public void drawString(AttributedCharacterIterator iterator, float x, float y) {
        super.drawString(iterator, x, y + this.val$yCorrection);
    }

    public void drawChars(char[] data, int offset, int length, int x, int y) {
        super.drawChars(data, offset, length, x, Math.round((float)y + this.val$yCorrection));
    }

    public void drawBytes(byte[] data, int offset, int length, int x, int y) {
        super.drawBytes(data, offset, length, x, Math.round((float)y + this.val$yCorrection));
    }

    public void drawGlyphVector(GlyphVector g, float x, float y) {
        super.drawGlyphVector(g, x, y + this.val$yCorrection);
    }
}
