//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import javax.swing.UIDefaults;
import javax.swing.plaf.metal.MetalLookAndFeel;

class FlatLaf$FlatUIDefaults$1 extends MetalLookAndFeel {
    FlatLaf$FlatUIDefaults$1(FlatLaf.FlatUIDefaults this$1) {
        this.this$1 = this$1;
    }

    protected void initClassDefaults(UIDefaults table) {
    }

    protected void initSystemColorDefaults(UIDefaults table) {
    }
}
