//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

enum UIDefaultsLoader$ValueType {
    UNKNOWN,
    STRING,
    BOOLEAN,
    CHARACTER,
    INTEGER,
    INTEGERORFLOAT,
    FLOAT,
    BORDER,
    ICON,
    INSETS,
    DIMENSION,
    COLOR,
    FONT,
    SCALEDINTEGER,
    SCALEDFLOAT,
    SCALEDINSETS,
    SCALEDDIMENSION,
    INSTANCE,
    CLASS,
    GRAYFILTER,
    NULL,
    LAZY;

    private UIDefaultsLoader$ValueType() {
    }
}
