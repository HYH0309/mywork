//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JTextField;

class FlatSpinnerUI$Handler implements LayoutManager, FocusListener, PropertyChangeListener {
    private Component editor;
    private Component nextButton;
    private Component previousButton;

    private FlatSpinnerUI$Handler(FlatSpinnerUI var1) {
        this.this$0 = var1;
        this.editor = null;
    }

    public void addLayoutComponent(String name, Component c) {
        switch (name) {
            case "Editor":
                this.editor = c;
                break;
            case "Next":
                this.nextButton = c;
                break;
            case "Previous":
                this.previousButton = c;
        }

    }

    public void removeLayoutComponent(Component c) {
        if (c == this.editor) {
            this.editor = null;
        } else if (c == this.nextButton) {
            this.nextButton = null;
        } else if (c == this.previousButton) {
            this.previousButton = null;
        }

    }

    public Dimension preferredLayoutSize(Container parent) {
        Insets insets = parent.getInsets();
        Insets padding = UIScale.scale(this.this$0.padding);
        Dimension editorSize = this.editor != null ? this.editor.getPreferredSize() : new Dimension(0, 0);
        int minimumWidth = FlatUIUtils.minimumWidth(FlatSpinnerUI.access$300(this.this$0), this.this$0.minimumWidth);
        int innerHeight = editorSize.height + padding.top + padding.bottom;
        float focusWidth = FlatUIUtils.getBorderFocusWidth(FlatSpinnerUI.access$400(this.this$0));
        return new Dimension(Math.max(insets.left + insets.right + editorSize.width + padding.left + padding.right + innerHeight, UIScale.scale(minimumWidth) + Math.round(focusWidth * 2.0F)), insets.top + insets.bottom + innerHeight);
    }

    public Dimension minimumLayoutSize(Container parent) {
        return this.preferredLayoutSize(parent);
    }

    public void layoutContainer(Container parent) {
        Dimension size = parent.getSize();
        Insets insets = parent.getInsets();
        Rectangle r = FlatUIUtils.subtractInsets(new Rectangle(size), insets);
        if (this.nextButton == null && this.previousButton == null) {
            if (this.editor != null) {
                this.editor.setBounds(r);
            }

        } else {
            Rectangle editorRect = new Rectangle(r);
            Rectangle buttonsRect = new Rectangle(r);
            FontMetrics fm = FlatSpinnerUI.access$600(this.this$0).getFontMetrics(FlatSpinnerUI.access$500(this.this$0).getFont());
            int maxButtonWidth = fm.getHeight() + UIScale.scale(this.this$0.padding.top) + UIScale.scale(this.this$0.padding.bottom);
            int minButtonWidth = maxButtonWidth * 3 / 4;
            boolean isMacStyle = this.this$0.isMacStyle();
            int buttonsGap = isMacStyle ? UIScale.scale(3) : 0;
            int prefButtonWidth = isMacStyle ? UIScale.scale(15) : buttonsRect.height;
            int buttonsWidth = Math.min(Math.max(prefButtonWidth, minButtonWidth), maxButtonWidth);
            buttonsRect.width = buttonsWidth;
            editorRect.width -= buttonsWidth + buttonsGap;
            boolean ltr = parent.getComponentOrientation().isLeftToRight();
            if (ltr) {
                buttonsRect.x += editorRect.width + buttonsGap;
            } else {
                editorRect.x += buttonsWidth + buttonsGap;
            }

            int nextHeight;
            if (isMacStyle) {
                nextHeight = Math.round(FlatUIUtils.getBorderLineWidth(FlatSpinnerUI.access$700(this.this$0)));
                if (nextHeight > 0) {
                    buttonsRect.x += ltr ? nextHeight : -nextHeight;
                    buttonsRect.y -= nextHeight;
                    buttonsRect.height += nextHeight * 2;
                }
            }

            if (this.editor != null) {
                this.editor.setBounds(editorRect);
            }

            nextHeight = buttonsRect.height / 2 + buttonsRect.height % 2;
            if (this.nextButton != null) {
                this.nextButton.setBounds(buttonsRect.x, buttonsRect.y, buttonsRect.width, nextHeight);
            }

            if (this.previousButton != null) {
                int previousY = buttonsRect.y + buttonsRect.height - nextHeight;
                this.previousButton.setBounds(buttonsRect.x, previousY, buttonsRect.width, nextHeight);
            }

        }
    }

    public void focusGained(FocusEvent e) {
        FlatSpinnerUI.access$800(this.this$0).repaint();
        if (e.getComponent() == FlatSpinnerUI.access$900(this.this$0)) {
            JTextField textField = FlatSpinnerUI.access$1100(FlatSpinnerUI.access$1000(this.this$0).getEditor());
            if (textField != null) {
                textField.requestFocusInWindow();
            }
        }

    }

    public void focusLost(FocusEvent e) {
        FlatSpinnerUI.access$1200(this.this$0).repaint();
    }

    public void propertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "foreground":
            case "enabled":
                FlatSpinnerUI.access$1300(this.this$0);
                break;
            case "JComponent.roundRect":
            case "JComponent.outline":
                FlatSpinnerUI.access$1400(this.this$0).repaint();
                break;
            case "JComponent.minimumWidth":
                FlatSpinnerUI.access$1500(this.this$0).revalidate();
                break;
            case "FlatLaf.style":
            case "FlatLaf.styleClass":
                this.this$0.installStyle();
                FlatSpinnerUI.access$1600(this.this$0).revalidate();
                FlatSpinnerUI.access$1700(this.this$0).repaint();
        }

    }
}
