//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.FocusEvent;
import javax.swing.plaf.basic.BasicComboBoxUI;

class FlatComboBoxUI$3 extends BasicComboBoxUI.FocusHandler {
    FlatComboBoxUI$3(FlatComboBoxUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void focusGained(FocusEvent e) {
        super.focusGained(e);
        if (FlatComboBoxUI.access$2000(this.this$0) != null && FlatComboBoxUI.access$2100(this.this$0).isEditable()) {
            FlatComboBoxUI.access$2200(this.this$0).repaint();
        }

    }

    public void focusLost(FocusEvent e) {
        super.focusLost(e);
        if (FlatComboBoxUI.access$2300(this.this$0) != null && FlatComboBoxUI.access$2400(this.this$0).isEditable()) {
            FlatComboBoxUI.access$2500(this.this$0).repaint();
        }

    }
}
