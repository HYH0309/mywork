//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;

class FlatRadioButtonUI$AWTPeerMouseExitedFix extends MouseAdapter implements PropertyChangeListener {
    private final JComponent button;

    static void install(JComponent button) {
        FlatRadioButtonUI$AWTPeerMouseExitedFix l = new FlatRadioButtonUI$AWTPeerMouseExitedFix(button);
        button.addPropertyChangeListener("ancestor", l);
        Container parent = button.getParent();
        if (parent != null) {
            parent.addMouseListener(l);
        }

    }

    static void uninstall(JComponent button) {
        PropertyChangeListener[] var1 = button.getPropertyChangeListeners("ancestor");
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            PropertyChangeListener l = var1[var3];
            if (l instanceof FlatRadioButtonUI$AWTPeerMouseExitedFix) {
                button.removePropertyChangeListener("ancestor", l);
                Container parent = button.getParent();
                if (parent != null) {
                    parent.removeMouseListener((FlatRadioButtonUI$AWTPeerMouseExitedFix)l);
                }
                break;
            }
        }

    }

    FlatRadioButtonUI$AWTPeerMouseExitedFix(JComponent button) {
        this.button = button;
    }

    public void propertyChange(PropertyChangeEvent e) {
        if (e.getOldValue() instanceof Component) {
            ((Component)e.getOldValue()).removeMouseListener(this);
        }

        if (e.getNewValue() instanceof Component) {
            ((Component)e.getNewValue()).removeMouseListener(this);
            ((Component)e.getNewValue()).addMouseListener(this);
        }

    }

    public void mouseExited(MouseEvent e) {
        this.button.dispatchEvent(SwingUtilities.convertMouseEvent(e.getComponent(), e, this.button));
    }
}
