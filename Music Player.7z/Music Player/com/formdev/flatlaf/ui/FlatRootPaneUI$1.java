//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JRootPane;

class FlatRootPaneUI$1 extends ComponentAdapter {
    FlatRootPaneUI$1(FlatRootPaneUI this$0, JRootPane var2) {
        this.this$0 = this$0;
        this.val$root = var2;
    }

    public void componentShown(ComponentEvent e) {
        this.val$root.getParent().repaint(this.val$root.getX(), this.val$root.getY(), this.val$root.getWidth(), this.val$root.getHeight());
    }
}
