//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.InputMap;
import javax.swing.KeyStroke;

class FlatComboBoxUI$EditorDelegateAction extends AbstractAction {
    private final KeyStroke keyStroke;

    FlatComboBoxUI$EditorDelegateAction(FlatComboBoxUI var1, InputMap inputMap, KeyStroke keyStroke) {
        this.this$0 = var1;
        this.keyStroke = keyStroke;
        inputMap.put(keyStroke, this);
    }

    public void actionPerformed(ActionEvent e) {
        ActionListener action = FlatComboBoxUI.access$4100(this.this$0).getActionForKeyStroke(this.keyStroke);
        if (action != null) {
            action.actionPerformed(new ActionEvent(FlatComboBoxUI.access$4200(this.this$0), e.getID(), e.getActionCommand(), e.getWhen(), e.getModifiers()));
        }

    }
}
