//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatSplitPaneUI.FlatSplitPaneDivider;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Container;
import javax.swing.plaf.basic.BasicSplitPaneDivider;

public class FlatSplitPaneUI$FlatSplitPaneDivider$FlatDividerLayout extends BasicSplitPaneDivider.DividerLayout {
    protected FlatSplitPaneUI$FlatSplitPaneDivider$FlatDividerLayout(FlatSplitPaneUI.FlatSplitPaneDivider this$1) {
        super(this$1);
        this.this$1 = this$1;
    }

    public void layoutContainer(Container c) {
        super.layoutContainer(c);
        if (FlatSplitPaneDivider.access$300(this.this$1) != null && FlatSplitPaneDivider.access$400(this.this$1) != null && FlatSplitPaneDivider.access$500(this.this$1).isOneTouchExpandable()) {
            int extraSize = UIScale.scale(4);
            if (FlatSplitPaneDivider.access$600(this.this$1) == 0) {
                FlatSplitPaneDivider.access$900(this.this$1).setSize(FlatSplitPaneDivider.access$700(this.this$1).getWidth() + extraSize, FlatSplitPaneDivider.access$800(this.this$1).getHeight());
                FlatSplitPaneDivider.access$1500(this.this$1).setBounds(FlatSplitPaneDivider.access$1000(this.this$1).getX() + FlatSplitPaneDivider.access$1100(this.this$1).getWidth(), FlatSplitPaneDivider.access$1200(this.this$1).getY(), FlatSplitPaneDivider.access$1300(this.this$1).getWidth() + extraSize, FlatSplitPaneDivider.access$1400(this.this$1).getHeight());
            } else {
                FlatSplitPaneDivider.access$1800(this.this$1).setSize(FlatSplitPaneDivider.access$1600(this.this$1).getWidth(), FlatSplitPaneDivider.access$1700(this.this$1).getHeight() + extraSize);
                FlatSplitPaneDivider.access$2400(this.this$1).setBounds(FlatSplitPaneDivider.access$1900(this.this$1).getX(), FlatSplitPaneDivider.access$2000(this.this$1).getY() + FlatSplitPaneDivider.access$2100(this.this$1).getHeight(), FlatSplitPaneDivider.access$2200(this.this$1).getWidth(), FlatSplitPaneDivider.access$2300(this.this$1).getHeight() + extraSize);
            }

            boolean leftCollapsed = this.this$1.isLeftCollapsed();
            boolean rightCollapsed = this.this$1.isRightCollapsed();
            if (!leftCollapsed && !rightCollapsed) {
                Object expandableSide = FlatSplitPaneDivider.access$2700(this.this$1).getClientProperty("JSplitPane.expandableSide");
                FlatSplitPaneDivider.access$2800(this.this$1).setVisible(expandableSide == null || !"left".equals(expandableSide));
                FlatSplitPaneDivider.access$2900(this.this$1).setVisible(expandableSide == null || !"right".equals(expandableSide));
            } else {
                FlatSplitPaneDivider.access$2500(this.this$1).setVisible(!leftCollapsed);
                FlatSplitPaneDivider.access$2600(this.this$1).setVisible(!rightCollapsed);
            }

            if (!FlatSplitPaneDivider.access$3000(this.this$1).isVisible()) {
                FlatSplitPaneDivider.access$3200(this.this$1).setLocation(FlatSplitPaneDivider.access$3100(this.this$1).getLocation());
            }

        }
    }
}
