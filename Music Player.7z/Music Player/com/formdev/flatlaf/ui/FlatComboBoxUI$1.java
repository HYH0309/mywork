//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

class FlatComboBoxUI$1 extends MouseAdapter {
    FlatComboBoxUI$1(FlatComboBoxUI this$0) {
        this.this$0 = this$0;
    }

    public void mouseEntered(MouseEvent e) {
        this.this$0.hover = true;
        this.repaintArrowButton();
    }

    public void mouseExited(MouseEvent e) {
        this.this$0.hover = false;
        this.repaintArrowButton();
    }

    public void mousePressed(MouseEvent e) {
        this.this$0.pressed = true;
        this.repaintArrowButton();
    }

    public void mouseReleased(MouseEvent e) {
        this.this$0.pressed = false;
        this.repaintArrowButton();
    }

    private void repaintArrowButton() {
        if (FlatComboBoxUI.access$000(this.this$0) != null && !FlatComboBoxUI.access$100(this.this$0).isEditable()) {
            FlatComboBoxUI.access$200(this.this$0).repaint();
        }

    }
}
