//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatComboBoxUI.FlatComboPopup;
import java.awt.Component;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

class FlatComboBoxUI$FlatComboPopup$PopupListCellRenderer implements ListCellRenderer {
    private FlatComboBoxUI$FlatComboPopup$PopupListCellRenderer(FlatComboBoxUI.FlatComboPopup var1) {
        this.this$1 = var1;
    }

    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        FlatComboBoxUI.access$3500(this.this$1.this$0).uninstall();
        ListCellRenderer renderer = FlatComboPopup.access$3600(this.this$1).getRenderer();
        if (renderer == null) {
            renderer = new DefaultListCellRenderer();
        }

        Component c = ((ListCellRenderer)renderer).getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        c.applyComponentOrientation(FlatComboPopup.access$3700(this.this$1).getComponentOrientation());
        if (FlatComboPopup.access$3800(this.this$1) && c instanceof JComponent) {
            int selectedIndex = FlatComboPopup.access$3900(this.this$1).getSelectedIndex();
            ((JComponent)c).putClientProperty("FlatLaf.internal.FlatComboBoxUI.macStyleHint", selectedIndex >= 0 ? index == selectedIndex : null);
        }

        FlatComboBoxUI.access$3500(this.this$1.this$0).install(c, Math.round(FlatUIUtils.getBorderFocusWidth(FlatComboPopup.access$4000(this.this$1))));
        return c;
    }
}
