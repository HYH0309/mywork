//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;

class FlatDesktopIconUI$FlatDesktopIconLayout implements LayoutManager {
    private FlatDesktopIconUI$FlatDesktopIconLayout(FlatDesktopIconUI var1) {
        this.this$0 = var1;
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        return FlatDesktopIconUI.access$800(this.this$0).getPreferredSize();
    }

    public Dimension minimumLayoutSize(Container parent) {
        return FlatDesktopIconUI.access$800(this.this$0).getMinimumSize();
    }

    public void layoutContainer(Container parent) {
        Insets insets = parent.getInsets();
        FlatDesktopIconUI.access$800(this.this$0).setBounds(insets.left, insets.top, parent.getWidth() - insets.left - insets.right, parent.getHeight() - insets.top - insets.bottom);
        Dimension cSize = UIScale.scale(FlatDesktopIconUI.access$900(this.this$0));
        FlatDesktopIconUI.access$400(this.this$0).setBounds(parent.getWidth() - cSize.width, 0, cSize.width, cSize.height);
    }
}
