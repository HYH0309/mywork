//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

public class FlatStylingSupport$UnknownStyleException extends IllegalArgumentException {
    public FlatStylingSupport$UnknownStyleException(String key) {
        super(key);
    }

    public String getMessage() {
        return "unknown style '" + super.getMessage() + "'";
    }
}
