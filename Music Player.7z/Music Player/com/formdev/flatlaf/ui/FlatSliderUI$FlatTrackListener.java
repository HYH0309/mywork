//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicSliderUI;

public class FlatSliderUI$FlatTrackListener extends BasicSliderUI.TrackListener {
    protected FlatSliderUI$FlatTrackListener(FlatSliderUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void mouseEntered(MouseEvent e) {
        this.setThumbHover(this.isOverThumb(e));
        super.mouseEntered(e);
    }

    public void mouseExited(MouseEvent e) {
        this.setThumbHover(false);
        super.mouseExited(e);
    }

    public void mouseMoved(MouseEvent e) {
        this.setThumbHover(this.isOverThumb(e));
        super.mouseMoved(e);
    }

    public void mousePressed(MouseEvent e) {
        this.setThumbPressed(this.isOverThumb(e));
        if (FlatSliderUI.access$000(this.this$0).isEnabled()) {
            if (UIManager.getBoolean("Slider.scrollOnTrackClick")) {
                super.mousePressed(e);
            } else {
                int x = e.getX();
                int y = e.getY();
                FlatSliderUI.access$100(this.this$0);
                if (FlatSliderUI.access$200(this.this$0).contains(x, y)) {
                    super.mousePressed(e);
                } else if (!UIManager.getBoolean("Slider.onlyLeftMouseButtonDrag") || SwingUtilities.isLeftMouseButton(e)) {
                    int tx = FlatSliderUI.access$300(this.this$0).x + FlatSliderUI.access$400(this.this$0).width / 2 - x;
                    int ty = FlatSliderUI.access$500(this.this$0).y + FlatSliderUI.access$600(this.this$0).height / 2 - y;
                    e.translatePoint(tx, ty);
                    super.mousePressed(e);
                    e.translatePoint(-tx, -ty);
                    this.mouseDragged(e);
                    this.setThumbPressed(true);
                }
            }
        }
    }

    public void mouseReleased(MouseEvent e) {
        this.setThumbPressed(false);
        super.mouseReleased(e);
    }

    public void mouseDragged(MouseEvent e) {
        super.mouseDragged(e);
        if (FlatSliderUI.access$700(this.this$0) && FlatSliderUI.access$800(this.this$0).getSnapToTicks() && FlatSliderUI.access$900(this.this$0).isEnabled() && !UIManager.getBoolean("Slider.snapToTicksOnReleased")) {
            FlatSliderUI.access$1000(this.this$0);
            FlatSliderUI.access$1100(this.this$0).repaint();
        }

    }

    protected void setThumbHover(boolean hover) {
        if (hover != this.this$0.thumbHover) {
            this.this$0.thumbHover = hover;
            FlatSliderUI.access$1300(this.this$0).repaint(FlatSliderUI.access$1200(this.this$0));
        }

    }

    protected void setThumbPressed(boolean pressed) {
        if (pressed != this.this$0.thumbPressed) {
            this.this$0.thumbPressed = pressed;
            FlatSliderUI.access$1500(this.this$0).repaint(FlatSliderUI.access$1400(this.this$0));
        }

    }

    protected boolean isOverThumb(MouseEvent e) {
        return e != null && FlatSliderUI.access$1600(this.this$0).isEnabled() && FlatSliderUI.access$1700(this.this$0).contains(e.getX(), e.getY());
    }
}
