//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.UIResource;

class FlatTabbedPaneUI$Handler implements MouseListener, MouseMotionListener, PropertyChangeListener, ChangeListener, ComponentListener, ContainerListener, FocusListener {
    MouseListener mouseDelegate;
    PropertyChangeListener propertyChangeDelegate;
    ChangeListener changeDelegate;
    FocusListener focusDelegate;
    private final PropertyChangeListener contentListener;
    private int pressedTabIndex;
    private int lastTipTabIndex;
    private String lastTip;

    private FlatTabbedPaneUI$Handler(FlatTabbedPaneUI var1) {
        this.this$0 = var1;
        this.contentListener = this::contentPropertyChange;
        this.pressedTabIndex = -1;
        this.lastTipTabIndex = -1;
    }

    void installListeners() {
        FlatTabbedPaneUI.access$3700(this.this$0).addMouseMotionListener(this);
        FlatTabbedPaneUI.access$3800(this.this$0).addComponentListener(this);
        FlatTabbedPaneUI.access$3900(this.this$0).addContainerListener(this);
        Component[] var1 = FlatTabbedPaneUI.access$4000(this.this$0).getComponents();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            Component c = var1[var3];
            if (!(c instanceof UIResource)) {
                c.addPropertyChangeListener(this.contentListener);
            }
        }

    }

    void uninstallListeners() {
        FlatTabbedPaneUI.access$4100(this.this$0).removeMouseMotionListener(this);
        FlatTabbedPaneUI.access$4200(this.this$0).removeComponentListener(this);
        FlatTabbedPaneUI.access$4300(this.this$0).removeContainerListener(this);
        Component[] var1 = FlatTabbedPaneUI.access$4400(this.this$0).getComponents();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            Component c = var1[var3];
            if (!(c instanceof UIResource)) {
                c.removePropertyChangeListener(this.contentListener);
            }
        }

    }

    public void mouseClicked(MouseEvent e) {
        this.mouseDelegate.mouseClicked(e);
    }

    public void mousePressed(MouseEvent e) {
        this.updateRollover(e);
        if (!this.this$0.isPressedTabClose() && SwingUtilities.isLeftMouseButton(e)) {
            this.mouseDelegate.mousePressed(e);
        }

    }

    public void mouseReleased(MouseEvent e) {
        if (this.this$0.isPressedTabClose()) {
            this.updateRollover(e);
            if (this.pressedTabIndex >= 0 && this.pressedTabIndex == FlatTabbedPaneUI.access$4500(this.this$0)) {
                this.restoreTabToolTip();
                this.this$0.closeTab(this.pressedTabIndex);
            }
        } else {
            this.mouseDelegate.mouseReleased(e);
        }

        this.pressedTabIndex = -1;
        this.updateRollover(e);
    }

    public void mouseEntered(MouseEvent e) {
        this.updateRollover(e);
    }

    public void mouseExited(MouseEvent e) {
        this.updateRollover(e);
    }

    public void mouseDragged(MouseEvent e) {
        this.updateRollover(e);
    }

    public void mouseMoved(MouseEvent e) {
        this.updateRollover(e);
    }

    private void updateRollover(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        int tabIndex = this.this$0.tabForCoordinate(FlatTabbedPaneUI.access$4600(this.this$0), x, y);
        this.this$0.setRolloverTab(tabIndex);
        boolean hitClose = this.this$0.isTabClosable(tabIndex) && this.this$0.getTabCloseHitArea(tabIndex).contains(x, y);
        if (e.getID() == 501 && SwingUtilities.isLeftMouseButton(e)) {
            this.pressedTabIndex = hitClose ? tabIndex : -1;
        }

        this.this$0.setRolloverTabClose(hitClose);
        this.this$0.setPressedTabClose(hitClose && tabIndex == this.pressedTabIndex);
        if (tabIndex >= 0 && hitClose) {
            Object closeTip = this.this$0.getTabClientProperty(tabIndex, "JTabbedPane.tabCloseToolTipText");
            if (closeTip == null) {
                closeTip = this.this$0.tabCloseToolTipText;
            }

            if (closeTip instanceof String) {
                this.setCloseToolTip(tabIndex, (String)closeTip);
            } else {
                this.restoreTabToolTip();
            }
        } else {
            this.restoreTabToolTip();
        }

    }

    private void setCloseToolTip(int tabIndex, String closeTip) {
        if (tabIndex != this.lastTipTabIndex) {
            this.restoreTabToolTip();
            this.lastTipTabIndex = tabIndex;
            this.lastTip = FlatTabbedPaneUI.access$4700(this.this$0).getToolTipTextAt(this.lastTipTabIndex);
            FlatTabbedPaneUI.access$4800(this.this$0).setToolTipTextAt(this.lastTipTabIndex, closeTip);
        }
    }

    private void restoreTabToolTip() {
        if (this.lastTipTabIndex >= 0) {
            if (this.lastTipTabIndex < FlatTabbedPaneUI.access$4900(this.this$0).getTabCount()) {
                FlatTabbedPaneUI.access$5000(this.this$0).setToolTipTextAt(this.lastTipTabIndex, this.lastTip);
            }

            this.lastTip = null;
            this.lastTipTabIndex = -1;
        }
    }

    public void propertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "tabPlacement":
            case "opaque":
            case "background":
            case "indexForTabComponent":
                FlatTabbedPaneUI.access$2700(this.this$0, () -> {
                    this.propertyChangeDelegate.propertyChange(e);
                });
                break;
            default:
                this.propertyChangeDelegate.propertyChange(e);
        }

        switch (e.getPropertyName()) {
            case "tabPlacement":
                if (FlatTabbedPaneUI.access$5100(this.this$0) instanceof FlatTabbedPaneUI.FlatMoreTabsButton) {
                    ((FlatTabbedPaneUI.FlatMoreTabsButton)FlatTabbedPaneUI.access$5100(this.this$0)).updateDirection();
                }
                break;
            case "componentOrientation":
                this.this$0.ensureSelectedTabIsVisibleLater();
                break;
            case "JTabbedPane.showTabSeparators":
            case "JTabbedPane.tabType":
                FlatTabbedPaneUI.access$5200(this.this$0).repaint();
                break;
            case "JTabbedPane.showContentSeparator":
            case "JTabbedPane.hasFullBorder":
            case "JTabbedPane.hideTabAreaWithOneTab":
            case "JTabbedPane.minimumTabWidth":
            case "JTabbedPane.maximumTabWidth":
            case "JTabbedPane.tabHeight":
            case "JTabbedPane.tabInsets":
            case "JTabbedPane.tabAreaInsets":
            case "JTabbedPane.tabsPopupPolicy":
            case "JTabbedPane.scrollButtonsPolicy":
            case "JTabbedPane.scrollButtonsPlacement":
            case "JTabbedPane.tabAreaAlignment":
            case "JTabbedPane.tabAlignment":
            case "JTabbedPane.tabWidthMode":
            case "JTabbedPane.tabIconPlacement":
            case "JTabbedPane.tabClosable":
                FlatTabbedPaneUI.access$5300(this.this$0).revalidate();
                FlatTabbedPaneUI.access$5400(this.this$0).repaint();
                break;
            case "JTabbedPane.leadingComponent":
                this.this$0.uninstallLeadingComponent();
                this.this$0.installLeadingComponent();
                FlatTabbedPaneUI.access$5500(this.this$0).revalidate();
                FlatTabbedPaneUI.access$5600(this.this$0).repaint();
                this.this$0.ensureSelectedTabIsVisibleLater();
                break;
            case "JTabbedPane.trailingComponent":
                this.this$0.uninstallTrailingComponent();
                this.this$0.installTrailingComponent();
                FlatTabbedPaneUI.access$5700(this.this$0).revalidate();
                FlatTabbedPaneUI.access$5800(this.this$0).repaint();
                this.this$0.ensureSelectedTabIsVisibleLater();
                break;
            case "FlatLaf.style":
            case "FlatLaf.styleClass":
                this.this$0.installStyle();
                FlatTabbedPaneUI.access$5900(this.this$0).revalidate();
                FlatTabbedPaneUI.access$6000(this.this$0).repaint();
        }

    }

    public void stateChanged(ChangeEvent e) {
        this.changeDelegate.stateChanged(e);
        if (FlatTabbedPaneUI.access$5100(this.this$0) != null) {
            this.this$0.ensureSelectedTabIsVisible();
        }

    }

    protected void contentPropertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "JTabbedPane.minimumTabWidth":
            case "JTabbedPane.maximumTabWidth":
            case "JTabbedPane.tabInsets":
            case "JTabbedPane.tabAlignment":
            case "JTabbedPane.tabClosable":
                FlatTabbedPaneUI.access$6100(this.this$0).revalidate();
                FlatTabbedPaneUI.access$6200(this.this$0).repaint();
            default:
        }
    }

    public void componentResized(ComponentEvent e) {
        this.this$0.ensureSelectedTabIsVisibleLater();
    }

    public void componentMoved(ComponentEvent e) {
    }

    public void componentShown(ComponentEvent e) {
    }

    public void componentHidden(ComponentEvent e) {
    }

    public void componentAdded(ContainerEvent e) {
        Component c = e.getChild();
        if (!(c instanceof UIResource)) {
            c.addPropertyChangeListener(this.contentListener);
        }

    }

    public void componentRemoved(ContainerEvent e) {
        Component c = e.getChild();
        if (!(c instanceof UIResource)) {
            c.removePropertyChangeListener(this.contentListener);
        }

    }

    public void focusGained(FocusEvent e) {
        this.focusDelegate.focusGained(e);
        FlatTabbedPaneUI.access$6400(this.this$0, FlatTabbedPaneUI.access$6300(this.this$0).getSelectedIndex());
    }

    public void focusLost(FocusEvent e) {
        this.focusDelegate.focusLost(e);
        FlatTabbedPaneUI.access$6400(this.this$0, FlatTabbedPaneUI.access$6500(this.this$0).getSelectedIndex());
    }
}
