//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Dimension;
import javax.swing.Icon;
import javax.swing.JButton;

class FlatTitlePane$5 extends JButton {
    FlatTitlePane$5(FlatTitlePane this$0, Icon arg0) {
        super(arg0);
        this.this$0 = this$0;
    }

    public Dimension getMinimumSize() {
        return new Dimension(UIScale.scale(this.this$0.buttonMinimumWidth), super.getMinimumSize().height);
    }
}
