//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatPopupFactory.DropShadowPopup;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;

class FlatPopupFactory$DropShadowPopup$1 implements ComponentListener {
    FlatPopupFactory$DropShadowPopup$1(FlatPopupFactory.DropShadowPopup this$1) {
        this.this$1 = this$1;
    }

    public void componentShown(ComponentEvent e) {
        if (DropShadowPopup.access$400(this.this$1) != null) {
            DropShadowPopup.access$400(this.this$1).setVisible(true);
        }

    }

    public void componentHidden(ComponentEvent e) {
        if (DropShadowPopup.access$400(this.this$1) != null) {
            DropShadowPopup.access$400(this.this$1).setVisible(false);
        }

    }

    public void componentMoved(ComponentEvent e) {
        DropShadowPopup.access$500(this.this$1);
    }

    public void componentResized(ComponentEvent e) {
        DropShadowPopup.access$600(this.this$1);
    }
}
