//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.MouseEvent;
import java.beans.PropertyVetoException;
import javax.swing.event.MouseInputAdapter;

class FlatDesktopIconUI$1 extends MouseInputAdapter {
    FlatDesktopIconUI$1(FlatDesktopIconUI this$0) {
        this.this$0 = this$0;
    }

    public void mouseReleased(MouseEvent e) {
        if (FlatDesktopIconUI.access$100(this.this$0).isIcon() && FlatDesktopIconUI.access$200(this.this$0).contains(e.getX(), e.getY())) {
            FlatDesktopIconUI.access$300(this.this$0);
            FlatDesktopIconUI.access$400(this.this$0).setVisible(false);

            try {
                FlatDesktopIconUI.access$500(this.this$0).setIcon(false);
            } catch (PropertyVetoException var3) {
            }
        }

    }

    public void mouseEntered(MouseEvent e) {
        FlatDesktopIconUI.access$600(this.this$0);
        if (FlatDesktopIconUI.access$700(this.this$0).isClosable()) {
            FlatDesktopIconUI.access$400(this.this$0).setVisible(true);
        }

    }

    public void mouseExited(MouseEvent e) {
        FlatDesktopIconUI.access$300(this.this$0);
        FlatDesktopIconUI.access$400(this.this$0).setVisible(false);
    }
}
