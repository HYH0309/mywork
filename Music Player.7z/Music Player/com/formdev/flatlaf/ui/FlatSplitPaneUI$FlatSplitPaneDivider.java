//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatStylingSupport.Styleable;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.util.Map;
import javax.swing.JButton;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicSplitPaneDivider;
import javax.swing.plaf.basic.BasicSplitPaneUI;

public class FlatSplitPaneUI$FlatSplitPaneDivider extends BasicSplitPaneDivider {
    @Styleable
    protected String style;
    @Styleable
    protected Color gripColor;
    @Styleable
    protected int gripDotCount;
    @Styleable
    protected int gripDotSize;
    @Styleable
    protected int gripGap;

    protected FlatSplitPaneUI$FlatSplitPaneDivider(FlatSplitPaneUI this$0, BasicSplitPaneUI ui) {
        super(ui);
        this.this$0 = this$0;
        this.style = UIManager.getString("SplitPaneDivider.style");
        this.gripColor = UIManager.getColor("SplitPaneDivider.gripColor");
        this.gripDotCount = FlatUIUtils.getUIInt("SplitPaneDivider.gripDotCount", 3);
        this.gripDotSize = FlatUIUtils.getUIInt("SplitPaneDivider.gripDotSize", 3);
        this.gripGap = FlatUIUtils.getUIInt("SplitPaneDivider.gripGap", 2);
        this.setLayout(new FlatDividerLayout());
    }

    protected Object applyStyleProperty(String key, Object value) {
        return FlatStylingSupport.applyToAnnotatedObject(this, key, value);
    }

    public Map<String, Class<?>> getStyleableInfos() {
        return FlatStylingSupport.getAnnotatedStyleableInfos(this);
    }

    public Object getStyleableValue(String key) {
        return FlatStylingSupport.getAnnotatedStyleableValue(this, key);
    }

    void updateStyle() {
        if (this.leftButton instanceof FlatOneTouchButton) {
            ((FlatOneTouchButton)this.leftButton).updateStyle();
        }

        if (this.rightButton instanceof FlatOneTouchButton) {
            ((FlatOneTouchButton)this.rightButton).updateStyle();
        }

    }

    public void setDividerSize(int newSize) {
        super.setDividerSize(UIScale.scale(newSize));
    }

    protected JButton createLeftOneTouchButton() {
        return new FlatOneTouchButton(true);
    }

    protected JButton createRightOneTouchButton() {
        return new FlatOneTouchButton(false);
    }

    public void propertyChange(PropertyChangeEvent e) {
        super.propertyChange(e);
        switch (e.getPropertyName()) {
            case "dividerLocation":
                this.doLayout();
            default:
        }
    }

    public void paint(Graphics g) {
        super.paint(g);
        if (!"plain".equals(this.style)) {
            Object[] oldRenderingHints = FlatUIUtils.setRenderingHints(g);
            g.setColor(this.gripColor);
            this.paintGrip(g, 0, 0, this.getWidth(), this.getHeight());
            FlatUIUtils.resetRenderingHints(g, oldRenderingHints);
        }
    }

    protected void paintGrip(Graphics g, int x, int y, int width, int height) {
        FlatUIUtils.paintGrip(g, x, y, width, height, this.splitPane.getOrientation() == 0, this.gripDotCount, this.gripDotSize, this.gripGap, true);
    }

    protected boolean isLeftCollapsed() {
        int location = this.splitPane.getDividerLocation();
        Insets insets = this.splitPane.getInsets();
        return this.orientation == 0 ? location == insets.top : location == insets.left;
    }

    protected boolean isRightCollapsed() {
        int location = this.splitPane.getDividerLocation();
        Insets insets = this.splitPane.getInsets();
        return this.orientation == 0 ? location == this.splitPane.getHeight() - this.getHeight() - insets.bottom : location == this.splitPane.getWidth() - this.getWidth() - insets.right;
    }

    protected class FlatDividerLayout extends BasicSplitPaneDivider.DividerLayout {
        protected FlatDividerLayout() {
            super(FlatSplitPaneUI$FlatSplitPaneDivider.this);
        }

        public void layoutContainer(Container c) {
            super.layoutContainer(c);
            if (FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton != null && FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton != null && FlatSplitPaneUI$FlatSplitPaneDivider.this.splitPane.isOneTouchExpandable()) {
                int extraSize = UIScale.scale(4);
                if (FlatSplitPaneUI$FlatSplitPaneDivider.this.orientation == 0) {
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.setSize(FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getWidth() + extraSize, FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getHeight());
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.setBounds(FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getX() + FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getWidth(), FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getY(), FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getWidth() + extraSize, FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getHeight());
                } else {
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.setSize(FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getWidth(), FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getHeight() + extraSize);
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.setBounds(FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getX(), FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getY() + FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getHeight(), FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getWidth(), FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.getHeight() + extraSize);
                }

                boolean leftCollapsed = FlatSplitPaneUI$FlatSplitPaneDivider.this.isLeftCollapsed();
                boolean rightCollapsed = FlatSplitPaneUI$FlatSplitPaneDivider.this.isRightCollapsed();
                if (!leftCollapsed && !rightCollapsed) {
                    Object expandableSide = FlatSplitPaneUI$FlatSplitPaneDivider.this.splitPane.getClientProperty("JSplitPane.expandableSide");
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.setVisible(expandableSide == null || !"left".equals(expandableSide));
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.setVisible(expandableSide == null || !"right".equals(expandableSide));
                } else {
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.setVisible(!leftCollapsed);
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.setVisible(!rightCollapsed);
                }

                if (!FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.isVisible()) {
                    FlatSplitPaneUI$FlatSplitPaneDivider.this.rightButton.setLocation(FlatSplitPaneUI$FlatSplitPaneDivider.this.leftButton.getLocation());
                }

            }
        }
    }

    protected class FlatOneTouchButton extends FlatArrowButton {
        protected final boolean left;

        protected FlatOneTouchButton(boolean left) {
            super(1, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.arrowType, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchArrowColor, (Color)null, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchHoverArrowColor, (Color)null, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchPressedArrowColor, (Color)null);
            this.setCursor(Cursor.getPredefinedCursor(0));
            ToolTipManager.sharedInstance().registerComponent(this);
            this.left = left;
        }

        protected void updateStyle() {
            this.updateStyle(FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.arrowType, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchArrowColor, (Color)null, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchHoverArrowColor, (Color)null, FlatSplitPaneUI$FlatSplitPaneDivider.this.this$0.oneTouchPressedArrowColor, (Color)null);
        }

        public int getDirection() {
            return FlatSplitPaneUI$FlatSplitPaneDivider.this.orientation == 0 ? (this.left ? 1 : 5) : (this.left ? 7 : 3);
        }

        public String getToolTipText(MouseEvent e) {
            String key = FlatSplitPaneUI$FlatSplitPaneDivider.this.orientation == 0 ? (this.left ? (FlatSplitPaneUI$FlatSplitPaneDivider.this.isRightCollapsed() ? "SplitPaneDivider.expandBottomToolTipText" : "SplitPaneDivider.collapseTopToolTipText") : (FlatSplitPaneUI$FlatSplitPaneDivider.this.isLeftCollapsed() ? "SplitPaneDivider.expandTopToolTipText" : "SplitPaneDivider.collapseBottomToolTipText")) : (this.left ? (FlatSplitPaneUI$FlatSplitPaneDivider.this.isRightCollapsed() ? "SplitPaneDivider.expandRightToolTipText" : "SplitPaneDivider.collapseLeftToolTipText") : (FlatSplitPaneUI$FlatSplitPaneDivider.this.isLeftCollapsed() ? "SplitPaneDivider.expandLeftToolTipText" : "SplitPaneDivider.collapseRightToolTipText"));
            Object value = FlatSplitPaneUI$FlatSplitPaneDivider.this.splitPane.getClientProperty(key);
            return value instanceof String ? (String)value : UIManager.getString(key, this.getLocale());
        }
    }
}
