//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import javax.swing.JComponent;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicColorChooserUI;

public class FlatColorChooserUI extends BasicColorChooserUI {
    public FlatColorChooserUI() {
    }

    public static ComponentUI createUI(JComponent c) {
        return new FlatColorChooserUI();
    }
}
