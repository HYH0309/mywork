//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Container;
import javax.swing.AbstractButton;
import javax.swing.LayoutFocusTraversalPolicy;

public class FlatToolBarUI$FlatToolBarFocusTraversalPolicy extends LayoutFocusTraversalPolicy {
    protected FlatToolBarUI$FlatToolBarFocusTraversalPolicy(FlatToolBarUI this$0) {
        this.this$0 = this$0;
    }

    public Component getComponentAfter(Container aContainer, Component aComponent) {
        if (!(aComponent instanceof AbstractButton)) {
            return super.getComponentAfter(aContainer, aComponent);
        } else {
            Component c = aComponent;

            do {
                if ((c = super.getComponentAfter(aContainer, c)) == null) {
                    return null;
                }
            } while(c instanceof AbstractButton);

            return c;
        }
    }

    public Component getComponentBefore(Container aContainer, Component aComponent) {
        if (!(aComponent instanceof AbstractButton)) {
            return super.getComponentBefore(aContainer, aComponent);
        } else {
            Component c = aComponent;

            do {
                if ((c = super.getComponentBefore(aContainer, c)) == null) {
                    return null;
                }
            } while(c instanceof AbstractButton);

            return c;
        }
    }

    public Component getFirstComponent(Container aContainer) {
        return this.getRecentComponent(aContainer, true);
    }

    public Component getLastComponent(Container aContainer) {
        return this.getRecentComponent(aContainer, false);
    }

    private Component getRecentComponent(Container aContainer, boolean first) {
        if (FlatToolBarUI.access$100(this.this$0) >= 0 && FlatToolBarUI.access$200(this.this$0) < FlatToolBarUI.access$300(this.this$0).getComponentCount()) {
            return FlatToolBarUI.access$500(this.this$0).getComponent(FlatToolBarUI.access$400(this.this$0));
        } else {
            return first ? super.getFirstComponent(aContainer) : super.getLastComponent(aContainer);
        }
    }
}
