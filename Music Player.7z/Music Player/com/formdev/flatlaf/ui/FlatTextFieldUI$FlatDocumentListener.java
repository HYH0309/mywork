//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

class FlatTextFieldUI$FlatDocumentListener implements DocumentListener {
    private FlatTextFieldUI$FlatDocumentListener(FlatTextFieldUI var1) {
        this.this$0 = var1;
    }

    public void insertUpdate(DocumentEvent e) {
        this.this$0.documentChanged(e);
    }

    public void removeUpdate(DocumentEvent e) {
        this.this$0.documentChanged(e);
    }

    public void changedUpdate(DocumentEvent e) {
        this.this$0.documentChanged(e);
    }
}
