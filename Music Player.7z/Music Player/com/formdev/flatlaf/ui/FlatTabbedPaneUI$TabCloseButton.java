//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import javax.swing.JButton;
import javax.swing.plaf.UIResource;

class FlatTabbedPaneUI$TabCloseButton extends JButton implements UIResource {
    private FlatTabbedPaneUI$TabCloseButton() {
    }
}
