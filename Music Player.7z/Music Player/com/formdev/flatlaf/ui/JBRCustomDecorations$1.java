//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Window;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import javax.swing.JRootPane;

class JBRCustomDecorations$1 implements HierarchyListener {
    JBRCustomDecorations$1(JRootPane var1) {
        this.val$rootPane = var1;
    }

    public void hierarchyChanged(HierarchyEvent e) {
        if (e.getChanged() == this.val$rootPane && (e.getChangeFlags() & 1L) != 0L) {
            Container parent = e.getChangedParent();
            if (parent instanceof Window) {
                FlatNativeWindowBorder.install((Window)parent);
            }

            EventQueue.invokeLater(() -> {
                rootPane.removeHierarchyListener(this);
            });
        }
    }
}
