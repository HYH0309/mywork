//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Color;
import java.awt.Dimension;

public class FlatScrollBarUI$FlatScrollBarButton extends FlatArrowButton {
    protected FlatScrollBarUI$FlatScrollBarButton(FlatScrollBarUI this$0, int direction) {
        this(this$0, direction, this$0.arrowType, this$0.buttonArrowColor, this$0.buttonDisabledArrowColor, (Color)null, this$0.hoverButtonBackground, (Color)null, this$0.pressedButtonBackground);
    }

    protected FlatScrollBarUI$FlatScrollBarButton(FlatScrollBarUI this$0, int direction, String type, Color foreground, Color disabledForeground, Color hoverForeground, Color hoverBackground, Color pressedForeground, Color pressedBackground) {
        super(direction, type, foreground, disabledForeground, hoverForeground, hoverBackground, pressedForeground, pressedBackground);
        this.this$0 = this$0;
        this.setFocusable(false);
        this.setRequestFocusEnabled(false);
    }

    protected void updateStyle() {
        this.updateStyle(this.this$0.arrowType, this.this$0.buttonArrowColor, this.this$0.buttonDisabledArrowColor, (Color)null, this.this$0.hoverButtonBackground, (Color)null, this.this$0.pressedButtonBackground);
    }

    public int getArrowWidth() {
        int arrowWidth = Math.round(6.0F * ((float)FlatScrollBarUI.access$600(this.this$0) / 10.0F));
        arrowWidth = FlatScrollBarUI.access$700(this.this$0) - (FlatScrollBarUI.access$800(this.this$0) - arrowWidth) / 2 * 2;
        return arrowWidth;
    }

    protected Color deriveBackground(Color background) {
        return FlatUIUtils.deriveColor(background, FlatScrollBarUI.access$900(this.this$0).getBackground());
    }

    public Dimension getPreferredSize() {
        if (this.this$0.isShowButtons()) {
            int w = UIScale.scale(Math.max(FlatScrollBarUI.access$1000(this.this$0), this.this$0.minimumButtonSize != null ? this.this$0.minimumButtonSize.width : 0));
            int h = UIScale.scale(Math.max(FlatScrollBarUI.access$1100(this.this$0), this.this$0.minimumButtonSize != null ? this.this$0.minimumButtonSize.height : 0));
            return new Dimension(w, h);
        } else {
            return new Dimension();
        }
    }

    public Dimension getMinimumSize() {
        return this.this$0.isShowButtons() ? super.getMinimumSize() : new Dimension();
    }

    public Dimension getMaximumSize() {
        return this.this$0.isShowButtons() ? super.getMaximumSize() : new Dimension();
    }
}
