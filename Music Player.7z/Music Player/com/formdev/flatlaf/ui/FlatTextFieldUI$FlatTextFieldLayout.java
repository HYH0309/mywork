//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.LayoutManager2;
import javax.swing.JComponent;
import javax.swing.plaf.UIResource;

class FlatTextFieldUI$FlatTextFieldLayout implements LayoutManager2, UIResource {
    private final LayoutManager delegate;

    FlatTextFieldUI$FlatTextFieldLayout(FlatTextFieldUI var1, LayoutManager delegate) {
        this.this$0 = var1;
        this.delegate = delegate;
    }

    public void addLayoutComponent(String name, Component comp) {
        if (this.delegate != null) {
            this.delegate.addLayoutComponent(name, comp);
        }

    }

    public void removeLayoutComponent(Component comp) {
        if (this.delegate != null) {
            this.delegate.removeLayoutComponent(comp);
        }

    }

    public Dimension preferredLayoutSize(Container parent) {
        return this.delegate != null ? this.delegate.preferredLayoutSize(parent) : null;
    }

    public Dimension minimumLayoutSize(Container parent) {
        return this.delegate != null ? this.delegate.minimumLayoutSize(parent) : null;
    }

    public void layoutContainer(Container parent) {
        if (this.delegate != null) {
            this.delegate.layoutContainer(parent);
        }

        int ow = FlatUIUtils.getBorderFocusAndLineWidth(FlatTextFieldUI.access$100(this.this$0));
        int h = parent.getHeight() - ow - ow;
        boolean ltr = this.this$0.isLeftToRight();
        JComponent[] leftComponents = ltr ? this.this$0.getLeadingComponents() : this.this$0.getTrailingComponents();
        JComponent[] rightComponents = ltr ? this.this$0.getTrailingComponents() : this.this$0.getLeadingComponents();
        int x = ow;
        JComponent[] var8 = leftComponents;
        int var9 = leftComponents.length;

        int var10;
        JComponent rightComponent;
        int cw;
        for(var10 = 0; var10 < var9; ++var10) {
            rightComponent = var8[var10];
            if (rightComponent != null && rightComponent.isVisible()) {
                cw = rightComponent.getPreferredSize().width;
                rightComponent.setBounds(x, ow, cw, h);
                x += cw;
            }
        }

        x = parent.getWidth() - ow;
        var8 = rightComponents;
        var9 = rightComponents.length;

        for(var10 = 0; var10 < var9; ++var10) {
            rightComponent = var8[var10];
            if (rightComponent != null && rightComponent.isVisible()) {
                cw = rightComponent.getPreferredSize().width;
                x -= cw;
                rightComponent.setBounds(x, ow, cw, h);
            }
        }

    }

    public void addLayoutComponent(Component comp, Object constraints) {
        if (this.delegate instanceof LayoutManager2) {
            ((LayoutManager2)this.delegate).addLayoutComponent(comp, constraints);
        }

    }

    public Dimension maximumLayoutSize(Container target) {
        return this.delegate instanceof LayoutManager2 ? ((LayoutManager2)this.delegate).maximumLayoutSize(target) : null;
    }

    public float getLayoutAlignmentX(Container target) {
        return this.delegate instanceof LayoutManager2 ? ((LayoutManager2)this.delegate).getLayoutAlignmentX(target) : 0.5F;
    }

    public float getLayoutAlignmentY(Container target) {
        return this.delegate instanceof LayoutManager2 ? ((LayoutManager2)this.delegate).getLayoutAlignmentY(target) : 0.5F;
    }

    public void invalidateLayout(Container target) {
        if (this.delegate instanceof LayoutManager2) {
            ((LayoutManager2)this.delegate).invalidateLayout(target);
        }

    }
}
