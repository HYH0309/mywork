//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

// $FF: synthetic class
class FlatScrollBarUI$1 {
}
