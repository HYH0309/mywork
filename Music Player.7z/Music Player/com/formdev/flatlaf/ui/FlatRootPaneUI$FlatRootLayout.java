//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.util.function.Function;
import javax.swing.JMenuBar;
import javax.swing.JRootPane;

public class FlatRootPaneUI$FlatRootLayout implements LayoutManager2 {
    protected FlatRootPaneUI$FlatRootLayout(FlatRootPaneUI this$0) {
        this.this$0 = this$0;
    }

    public void addLayoutComponent(String name, Component comp) {
    }

    public void addLayoutComponent(Component comp, Object constraints) {
    }

    public void removeLayoutComponent(Component comp) {
    }

    public Dimension preferredLayoutSize(Container parent) {
        return this.computeLayoutSize(parent, (c) -> {
            return c.getPreferredSize();
        });
    }

    public Dimension minimumLayoutSize(Container parent) {
        return this.computeLayoutSize(parent, (c) -> {
            return c.getMinimumSize();
        });
    }

    public Dimension maximumLayoutSize(Container parent) {
        return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
    }

    private Dimension computeLayoutSize(Container parent, Function<Component, Dimension> getSizeFunc) {
        JRootPane rootPane = (JRootPane)parent;
        Dimension titlePaneSize = this.this$0.titlePane != null ? (Dimension)getSizeFunc.apply(this.this$0.titlePane) : new Dimension();
        Dimension contentSize = rootPane.getContentPane() != null ? (Dimension)getSizeFunc.apply(rootPane.getContentPane()) : rootPane.getSize();
        int width = contentSize.width;
        int height = titlePaneSize.height + contentSize.height;
        if (this.this$0.titlePane == null || !this.this$0.titlePane.isMenuBarEmbedded()) {
            JMenuBar menuBar = rootPane.getJMenuBar();
            Dimension menuBarSize = menuBar != null && menuBar.isVisible() ? (Dimension)getSizeFunc.apply(menuBar) : new Dimension();
            width = Math.max(width, menuBarSize.width);
            height += menuBarSize.height;
        }

        Insets insets = rootPane.getInsets();
        return new Dimension(width + insets.left + insets.right, height + insets.top + insets.bottom);
    }

    public void layoutContainer(Container parent) {
        JRootPane rootPane = (JRootPane)parent;
        boolean isFullScreen = FlatUIUtils.isFullScreen(rootPane);
        Insets insets = rootPane.getInsets();
        int x = insets.left;
        int y = insets.top;
        int width = rootPane.getWidth() - insets.left - insets.right;
        int height = rootPane.getHeight() - insets.top - insets.bottom;
        if (rootPane.getLayeredPane() != null) {
            rootPane.getLayeredPane().setBounds(x, y, width, height);
        }

        int nextY = 0;
        if (this.this$0.titlePane != null) {
            int prefHeight = !isFullScreen ? this.this$0.titlePane.getPreferredSize().height : 0;
            this.this$0.titlePane.setBounds(0, 0, width, prefHeight);
            nextY += prefHeight;
        }

        if (rootPane.getGlassPane() != null) {
            boolean fullHeight = FlatClientProperties.clientPropertyBoolean(rootPane, "JRootPane.glassPaneFullHeight", false);
            int offset = fullHeight ? 0 : nextY;
            rootPane.getGlassPane().setBounds(x, y + offset, width, height - offset);
        }

        JMenuBar menuBar = rootPane.getJMenuBar();
        if (menuBar != null && menuBar.isVisible()) {
            boolean embedded = !isFullScreen && this.this$0.titlePane != null && this.this$0.titlePane.isMenuBarEmbedded();
            if (embedded) {
                this.this$0.titlePane.validate();
                menuBar.setBounds(this.this$0.titlePane.getMenuBarBounds());
            } else {
                Dimension prefSize = menuBar.getPreferredSize();
                menuBar.setBounds(0, nextY, width, prefSize.height);
                nextY += prefSize.height;
            }
        }

        Container contentPane = rootPane.getContentPane();
        if (contentPane != null) {
            contentPane.setBounds(0, nextY, width, Math.max(height - nextY, 0));
        }

        if (this.this$0.titlePane != null) {
            this.this$0.titlePane.menuBarLayouted();
        }

    }

    public void invalidateLayout(Container parent) {
        if (this.this$0.titlePane != null) {
            this.this$0.titlePane.menuBarChanged();
        }

    }

    public float getLayoutAlignmentX(Container target) {
        return 0.0F;
    }

    public float getLayoutAlignmentY(Container target) {
        return 0.0F;
    }
}
