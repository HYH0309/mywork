//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.lang.invoke.MethodHandles;

public interface FlatStylingSupport$StyleableLookupProvider {
    MethodHandles.Lookup getLookupForStyling();
}
