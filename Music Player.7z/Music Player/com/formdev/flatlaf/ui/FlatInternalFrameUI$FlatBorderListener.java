//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import javax.swing.plaf.basic.BasicInternalFrameUI;

public class FlatInternalFrameUI$FlatBorderListener extends BasicInternalFrameUI.BorderListener {
    protected FlatInternalFrameUI$FlatBorderListener(FlatInternalFrameUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2 && !FlatInternalFrameUI.access$000(this.this$0).isIcon() && e.getSource() instanceof FlatInternalFrameTitlePane) {
            Rectangle iconBounds = ((FlatInternalFrameTitlePane)e.getSource()).getFrameIconBounds();
            if (iconBounds != null && iconBounds.contains(e.getX(), e.getY())) {
                if (FlatInternalFrameUI.access$100(this.this$0).isClosable()) {
                    FlatInternalFrameUI.access$200(this.this$0).doDefaultCloseAction();
                }

                return;
            }
        }

        super.mouseClicked(e);
    }
}
