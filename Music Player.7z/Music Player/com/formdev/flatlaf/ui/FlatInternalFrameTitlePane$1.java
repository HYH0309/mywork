//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Dimension;
import javax.swing.JPanel;

class FlatInternalFrameTitlePane$1 extends JPanel {
    FlatInternalFrameTitlePane$1(FlatInternalFrameTitlePane this$0) {
        this.this$0 = this$0;
    }

    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        int height = size.height;
        if (!FlatInternalFrameTitlePane.access$000(this.this$0).isVisible()) {
            height = Math.max(height, FlatInternalFrameTitlePane.access$100(this.this$0).getPreferredSize().height);
        }

        if (!FlatInternalFrameTitlePane.access$200(this.this$0).isVisible()) {
            height = Math.max(height, FlatInternalFrameTitlePane.access$300(this.this$0).getPreferredSize().height);
        }

        if (!FlatInternalFrameTitlePane.access$400(this.this$0).isVisible()) {
            height = Math.max(height, FlatInternalFrameTitlePane.access$500(this.this$0).getPreferredSize().height);
        }

        return new Dimension(size.width, height);
    }
}
