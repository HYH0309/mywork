//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.Graphics2DProxy;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

class FlatListUI$1RoundedSelectionGraphics extends Graphics2DProxy {
    private boolean inPaintSelection;

    FlatListUI$1RoundedSelectionGraphics(FlatListUI this$0, Graphics delegate, Rectangle var3, Component var4, int var5) {
        super((Graphics2D)delegate);
        this.this$0 = this$0;
        this.val$rowBounds = var3;
        this.val$rendererComponent = var4;
        this.val$row = var5;
    }

    public Graphics create() {
        return new FlatListUI$1RoundedSelectionGraphics(this.this$0, super.create(), this.val$rowBounds, this.val$rendererComponent, this.val$row);
    }

    public Graphics create(int x, int y, int width, int height) {
        return new FlatListUI$1RoundedSelectionGraphics(this.this$0, super.create(x, y, width, height), this.val$rowBounds, this.val$rendererComponent, this.val$row);
    }

    public void fillRect(int x, int y, int width, int height) {
        if (!this.inPaintSelection && x == 0 && y == 0 && width == this.val$rowBounds.width && height == this.val$rowBounds.height && this.getColor() == this.val$rendererComponent.getBackground()) {
            this.inPaintSelection = true;
            this.this$0.paintCellSelection(this, this.val$row, x, y, width, height);
            this.inPaintSelection = false;
        } else {
            super.fillRect(x, y, width, height);
        }

    }
}
