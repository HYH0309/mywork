//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Graphics;

public class FlatTableCellBorder$Default extends FlatTableCellBorder {
    public FlatTableCellBorder$Default() {
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
    }
}
