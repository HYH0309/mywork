//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;

class FlatScrollBarUI$ScrollBarHoverListener extends MouseAdapter {
    private FlatScrollBarUI$ScrollBarHoverListener(FlatScrollBarUI var1) {
        this.this$0 = var1;
    }

    public void mouseExited(MouseEvent e) {
        if (!FlatScrollBarUI.access$100()) {
            this.this$0.hoverTrack = this.this$0.hoverThumb = false;
            this.repaint();
        }

    }

    public void mouseMoved(MouseEvent e) {
        if (!FlatScrollBarUI.access$100()) {
            this.update(e.getX(), e.getY());
        }

    }

    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e) || this.isAbsolutePositioning(e)) {
            FlatScrollBarUI.access$102(true);
            this.repaint();
            if (this.isAbsolutePositioning(e)) {
                this.update(e.getX(), e.getY());
            }
        }

    }

    public void mouseReleased(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e) || this.isAbsolutePositioning(e)) {
            FlatScrollBarUI.access$102(false);
            this.repaint();
        }

        this.update(e.getX(), e.getY());
    }

    private boolean isAbsolutePositioning(MouseEvent e) {
        return this.this$0.getSupportsAbsolutePositioning() && SwingUtilities.isMiddleMouseButton(e);
    }

    private void update(int x, int y) {
        boolean inTrack = FlatScrollBarUI.access$200(this.this$0).contains(x, y);
        boolean inThumb = FlatScrollBarUI.access$300(this.this$0).contains(x, y);
        if (inTrack != this.this$0.hoverTrack || inThumb != this.this$0.hoverThumb) {
            this.this$0.hoverTrack = inTrack;
            this.this$0.hoverThumb = inThumb;
            this.repaint();
        }

    }

    private void repaint() {
        if (FlatScrollBarUI.access$400(this.this$0).isEnabled()) {
            FlatScrollBarUI.access$500(this.this$0).repaint();
        }

    }
}
