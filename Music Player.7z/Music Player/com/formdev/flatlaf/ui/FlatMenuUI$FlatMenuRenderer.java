//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Window;
import java.util.function.Function;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.MenuBarUI;

public class FlatMenuUI$FlatMenuRenderer extends FlatMenuItemRenderer {
    protected Insets menuBarSelectionInsets;
    protected Insets menuBarSelectionEmbeddedInsets;
    protected int menuBarSelectionArc;
    protected Color hoverBackground;
    protected Color menuBarSelectionBackground;
    protected Color menuBarSelectionForeground;
    protected Color menuBarUnderlineSelectionBackground;
    protected Color menuBarUnderlineSelectionColor;
    protected int menuBarUnderlineSelectionHeight;

    protected FlatMenuUI$FlatMenuRenderer(FlatMenuUI this$0, JMenuItem menuItem, Icon checkIcon, Icon arrowIcon, Font acceleratorFont, String acceleratorDelimiter) {
        super(menuItem, checkIcon, arrowIcon, acceleratorFont, acceleratorDelimiter);
        this.this$0 = this$0;
        this.menuBarSelectionInsets = UIManager.getInsets("MenuBar.selectionInsets");
        this.menuBarSelectionEmbeddedInsets = UIManager.getInsets("MenuBar.selectionEmbeddedInsets");
        this.menuBarSelectionArc = UIManager.getInt("MenuBar.selectionArc");
        this.hoverBackground = UIManager.getColor("MenuBar.hoverBackground");
        this.menuBarSelectionBackground = UIManager.getColor("MenuBar.selectionBackground");
        this.menuBarSelectionForeground = UIManager.getColor("MenuBar.selectionForeground");
        this.menuBarUnderlineSelectionBackground = UIManager.getColor("MenuBar.underlineSelectionBackground");
        this.menuBarUnderlineSelectionColor = UIManager.getColor("MenuBar.underlineSelectionColor");
        this.menuBarUnderlineSelectionHeight = FlatUIUtils.getUIInt("MenuBar.underlineSelectionHeight", -1);
    }

    protected void paintBackground(Graphics g) {
        super.paintBackground(g);
        if (((JMenu)this.menuItem).isTopLevelMenu() && this.isHover()) {
            Color color = this.deriveBackground((Color)this.getStyleFromMenuBarUI((ui) -> {
                return ui.hoverBackground;
            }, this.hoverBackground));
            if (this.isUnderlineSelection()) {
                g.setColor(color);
                g.fillRect(0, 0, this.menuItem.getWidth(), this.menuItem.getHeight());
            } else {
                this.paintSelection(g, color, this.selectionInsets, this.selectionArc);
            }
        }

    }

    protected void paintSelection(Graphics g, Color selectionBackground, Insets selectionInsets, int selectionArc) {
        if (((JMenu)this.menuItem).isTopLevelMenu()) {
            if (!this.isHover()) {
                selectionBackground = (Color)this.getStyleFromMenuBarUI((ui) -> {
                    return ui.selectionBackground;
                }, this.menuBarSelectionBackground, selectionBackground);
            }

            JMenuBar menuBar = (JMenuBar)this.menuItem.getParent();
            JRootPane rootPane = SwingUtilities.getRootPane(menuBar);
            if (rootPane != null && rootPane.getParent() instanceof Window && rootPane.getJMenuBar() == menuBar && FlatRootPaneUI.isMenuBarEmbedded(rootPane)) {
                selectionInsets = (Insets)this.getStyleFromMenuBarUI((ui) -> {
                    return ui.selectionEmbeddedInsets;
                }, this.menuBarSelectionEmbeddedInsets);
            } else {
                selectionInsets = (Insets)this.getStyleFromMenuBarUI((ui) -> {
                    return ui.selectionInsets;
                }, this.menuBarSelectionInsets);
            }

            selectionArc = (Integer)this.getStyleFromMenuBarUI((ui) -> {
                return ui.selectionArc != -1 ? ui.selectionArc : null;
            }, this.menuBarSelectionArc);
        }

        super.paintSelection(g, selectionBackground, selectionInsets, selectionArc);
    }

    protected void paintUnderlineSelection(Graphics g, Color underlineSelectionBackground, Color underlineSelectionColor, int underlineSelectionHeight) {
        if (((JMenu)this.menuItem).isTopLevelMenu()) {
            underlineSelectionBackground = (Color)this.getStyleFromMenuBarUI((ui) -> {
                return ui.underlineSelectionBackground;
            }, this.menuBarUnderlineSelectionBackground, underlineSelectionBackground);
            underlineSelectionColor = (Color)this.getStyleFromMenuBarUI((ui) -> {
                return ui.underlineSelectionColor;
            }, this.menuBarUnderlineSelectionColor, underlineSelectionColor);
            underlineSelectionHeight = (Integer)this.getStyleFromMenuBarUI((ui) -> {
                return ui.underlineSelectionHeight != -1 ? ui.underlineSelectionHeight : null;
            }, this.menuBarUnderlineSelectionHeight != -1 ? this.menuBarUnderlineSelectionHeight : underlineSelectionHeight);
        }

        super.paintUnderlineSelection(g, underlineSelectionBackground, underlineSelectionColor, underlineSelectionHeight);
    }

    protected void paintText(Graphics g, Rectangle textRect, String text, Color selectionForeground, Color disabledForeground) {
        if (((JMenu)this.menuItem).isTopLevelMenu() && !this.isUnderlineSelection()) {
            selectionForeground = (Color)this.getStyleFromMenuBarUI((ui) -> {
                return ui.selectionForeground;
            }, this.menuBarSelectionForeground, selectionForeground);
        }

        super.paintText(g, textRect, text, selectionForeground, disabledForeground);
    }

    private boolean isHover() {
        ButtonModel model = this.menuItem.getModel();
        return model.isRollover() && !model.isArmed() && !model.isSelected() && model.isEnabled();
    }

    private <T> T getStyleFromMenuBarUI(Function<FlatMenuBarUI, T> f, T defaultValue, T defaultValue2) {
        return this.getStyleFromMenuBarUI(f, defaultValue != null ? defaultValue : defaultValue2);
    }

    private <T> T getStyleFromMenuBarUI(Function<FlatMenuBarUI, T> f, T defaultValue) {
        MenuBarUI ui = ((JMenuBar)this.menuItem.getParent()).getUI();
        if (!(ui instanceof FlatMenuBarUI)) {
            return defaultValue;
        } else {
            T value = f.apply((FlatMenuBarUI)ui);
            return value != null ? value : defaultValue;
        }
    }
}
