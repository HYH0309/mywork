//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Dimension;
import javax.swing.JComponent;
import javax.swing.JMenuBar;

class FlatTitlePane$2 extends JComponent {
    FlatTitlePane$2(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public Dimension getPreferredSize() {
        JMenuBar menuBar = this.this$0.rootPane.getJMenuBar();
        return this.this$0.hasVisibleEmbeddedMenuBar(menuBar) ? menuBar.getPreferredSize() : new Dimension();
    }
}
