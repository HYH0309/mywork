//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

class FlatStylingSupport$StyleableInfosMap<K, V> extends LinkedHashMap<K, V> {
    FlatStylingSupport$StyleableInfosMap() {
    }

    public V put(K key, V value) throws IllegalArgumentException {
        V oldValue = super.put(key, value);
        if (oldValue != null) {
            throw new IllegalArgumentException("duplicate key '" + key + "'");
        } else {
            return oldValue;
        }
    }

    public void putAll(Map<? extends K, ? extends V> m) {
        Iterator var2 = m.entrySet().iterator();

        while(var2.hasNext()) {
            Map.Entry<? extends K, ? extends V> e = (Map.Entry)var2.next();
            this.put(e.getKey(), e.getValue());
        }

    }
}
