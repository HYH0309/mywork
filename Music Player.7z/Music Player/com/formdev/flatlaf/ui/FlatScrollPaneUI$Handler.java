//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

class FlatScrollPaneUI$Handler implements ContainerListener, FocusListener {
    private FlatScrollPaneUI$Handler(FlatScrollPaneUI var1) {
        this.this$0 = var1;
    }

    public void componentAdded(ContainerEvent e) {
        e.getChild().addFocusListener(this);
    }

    public void componentRemoved(ContainerEvent e) {
        e.getChild().removeFocusListener(this);
    }

    public void focusGained(FocusEvent e) {
        FlatScrollPaneUI.access$100(this.this$0).repaint();
    }

    public void focusLost(FocusEvent e) {
        FlatScrollPaneUI.access$200(this.this$0).repaint();
    }
}
