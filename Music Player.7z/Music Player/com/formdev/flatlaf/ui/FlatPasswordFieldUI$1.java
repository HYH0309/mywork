//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

class FlatPasswordFieldUI$1 extends KeyAdapter {
    FlatPasswordFieldUI$1(FlatPasswordFieldUI this$0) {
        this.this$0 = this$0;
    }

    public void keyPressed(KeyEvent e) {
        this.repaint(e);
    }

    public void keyReleased(KeyEvent e) {
        this.repaint(e);
    }

    private void repaint(KeyEvent e) {
        if (e.getKeyCode() == 20) {
            e.getComponent().repaint();
            this.this$0.scrollCaretToVisible();
        }

    }
}
