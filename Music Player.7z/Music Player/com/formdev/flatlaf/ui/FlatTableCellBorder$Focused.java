//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;

public class FlatTableCellBorder$Focused extends FlatTableCellBorder {
    public FlatTableCellBorder$Focused() {
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        if (c != null && c.getClass().getName().equals("javax.swing.JTable$BooleanRenderer")) {
            JTable table = (JTable)SwingUtilities.getAncestorOfClass(JTable.class, c);
            if (table != null && c.getForeground() == table.getSelectionForeground() && c.getBackground() == table.getSelectionBackground()) {
                Border border = UIManager.getBorder("Table.focusSelectedCellHighlightBorder");
                if (border != null) {
                    border.paintBorder(c, g, x, y, width, height);
                    return;
                }
            }
        }

        super.paintBorder(c, g, x, y, width, height);
    }
}
