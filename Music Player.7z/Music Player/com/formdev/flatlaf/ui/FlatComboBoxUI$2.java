//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Container;
import java.awt.FontMetrics;
import java.awt.Insets;
import javax.swing.plaf.basic.BasicComboBoxUI;

class FlatComboBoxUI$2 extends BasicComboBoxUI.ComboBoxLayoutManager {
    FlatComboBoxUI$2(FlatComboBoxUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void layoutContainer(Container parent) {
        super.layoutContainer(parent);
        if (FlatComboBoxUI.access$300(this.this$0) != null && FlatComboBoxUI.access$400(this.this$0).getFont() != null) {
            FontMetrics fm = FlatComboBoxUI.access$600(this.this$0).getFontMetrics(FlatComboBoxUI.access$500(this.this$0).getFont());
            int maxButtonWidth = fm.getHeight() + UIScale.scale(FlatComboBoxUI.access$700(this.this$0).top) + UIScale.scale(FlatComboBoxUI.access$800(this.this$0).bottom);
            int minButtonWidth = maxButtonWidth * 3 / 4;
            Insets insets = FlatComboBoxUI.access$900(this.this$0);
            int buttonWidth = Math.min(Math.max(parent.getHeight() - insets.top - insets.bottom, minButtonWidth), maxButtonWidth);
            if (buttonWidth != FlatComboBoxUI.access$1000(this.this$0).getWidth()) {
                int xOffset = FlatComboBoxUI.access$1100(this.this$0).getComponentOrientation().isLeftToRight() ? FlatComboBoxUI.access$1200(this.this$0).getWidth() - buttonWidth : 0;
                FlatComboBoxUI.access$1600(this.this$0).setBounds(FlatComboBoxUI.access$1300(this.this$0).getX() + xOffset, FlatComboBoxUI.access$1400(this.this$0).getY(), buttonWidth, FlatComboBoxUI.access$1500(this.this$0).getHeight());
                if (FlatComboBoxUI.access$1700(this.this$0) != null) {
                    FlatComboBoxUI.access$1900(this.this$0).setBounds(FlatComboBoxUI.access$1800(this.this$0));
                }
            }
        }

    }
}
