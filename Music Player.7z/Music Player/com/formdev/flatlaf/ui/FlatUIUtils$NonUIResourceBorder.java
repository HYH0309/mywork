//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.Border;

class FlatUIUtils$NonUIResourceBorder implements Border {
    private final Border delegate;

    FlatUIUtils$NonUIResourceBorder(Border delegate) {
        this.delegate = delegate;
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        this.delegate.paintBorder(c, g, x, y, width, height);
    }

    public Insets getBorderInsets(Component c) {
        return this.delegate.getBorderInsets(c);
    }

    public boolean isBorderOpaque() {
        return this.delegate.isBorderOpaque();
    }
}
