//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JViewport;

public interface FlatViewportUI$ViewportPainter {
    void paintViewport(Graphics var1, JComponent var2, JViewport var3);
}
