//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.ScaledImageIcon;
import java.io.File;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.plaf.basic.BasicFileChooserUI;

class FlatFileChooserUI$FlatFileView extends BasicFileChooserUI.BasicFileView {
    private FlatFileChooserUI$FlatFileView(FlatFileChooserUI var1) {
        super(var1);
        this.this$0 = var1;
    }

    public Icon getIcon(File f) {
        Icon icon = this.getCachedIcon(f);
        if (icon != null) {
            return icon;
        } else {
            Object icon;
            if (f != null) {
                icon = this.this$0.getFileChooser().getFileSystemView().getSystemIcon(f);
                if (icon != null) {
                    if (icon instanceof ImageIcon) {
                        icon = new ScaledImageIcon((ImageIcon)icon);
                    }

                    this.cacheIcon(f, (Icon)icon);
                    return (Icon)icon;
                }
            }

            icon = super.getIcon(f);
            if (icon instanceof ImageIcon) {
                icon = new ScaledImageIcon((ImageIcon)icon);
                this.cacheIcon(f, (Icon)icon);
            }

            return (Icon)icon;
        }
    }
}
