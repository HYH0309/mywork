//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatLaf;
import java.awt.Component;
import java.awt.KeyboardFocusManager;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JTabbedPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.TabbedPaneUI;

class FlatTabbedPaneUI$FlatSelectedTabRepainter implements PropertyChangeListener {
    private static FlatTabbedPaneUI$FlatSelectedTabRepainter instance;
    private KeyboardFocusManager keyboardFocusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager();

    static void install() {
        Class var0 = FlatTabbedPaneUI$FlatSelectedTabRepainter.class;
        synchronized(FlatTabbedPaneUI$FlatSelectedTabRepainter.class) {
            if (instance == null) {
                instance = new FlatTabbedPaneUI$FlatSelectedTabRepainter();
            }
        }
    }

    FlatTabbedPaneUI$FlatSelectedTabRepainter() {
        this.keyboardFocusManager.addPropertyChangeListener(this);
    }

    private void uninstall() {
        Class var1 = FlatTabbedPaneUI$FlatSelectedTabRepainter.class;
        synchronized(FlatTabbedPaneUI$FlatSelectedTabRepainter.class) {
            if (instance != null) {
                this.keyboardFocusManager.removePropertyChangeListener(this);
                this.keyboardFocusManager = null;
                instance = null;
            }
        }
    }

    public void propertyChange(PropertyChangeEvent e) {
        if (!(UIManager.getLookAndFeel() instanceof FlatLaf)) {
            this.uninstall();
        } else {
            switch (e.getPropertyName()) {
                case "permanentFocusOwner":
                    Object oldValue = e.getOldValue();
                    Object newValue = e.getNewValue();
                    if (oldValue instanceof Component) {
                        this.repaintSelectedTabs((Component)oldValue);
                    }

                    if (newValue instanceof Component) {
                        this.repaintSelectedTabs((Component)newValue);
                    }
                    break;
                case "activeWindow":
                    this.repaintSelectedTabs(this.keyboardFocusManager.getPermanentFocusOwner());
            }

        }
    }

    private void repaintSelectedTabs(Component c) {
        if (c instanceof JTabbedPane) {
            this.repaintSelectedTab((JTabbedPane)c);
        }

        while((c = SwingUtilities.getAncestorOfClass(JTabbedPane.class, (Component)c)) != null) {
            this.repaintSelectedTab((JTabbedPane)c);
        }

    }

    private void repaintSelectedTab(JTabbedPane tabbedPane) {
        TabbedPaneUI ui = tabbedPane.getUI();
        if (ui instanceof FlatTabbedPaneUI) {
            FlatTabbedPaneUI.access$6400((FlatTabbedPaneUI)ui, tabbedPane.getSelectedIndex());
        }

    }
}
