//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class FlatTabbedPaneUI$FlatScrollableTabButton extends FlatTabbedPaneUI.FlatTabAreaButton implements MouseListener {
    private Timer autoRepeatTimer;

    protected FlatTabbedPaneUI$FlatScrollableTabButton(FlatTabbedPaneUI this$0, int direction) {
        super(this$0, direction);
        this.this$0 = this$0;
        this.addMouseListener(this);
    }

    protected void fireActionPerformed(ActionEvent event) {
        FlatTabbedPaneUI.access$2700(this.this$0, () -> {
            super.fireActionPerformed(event);
        });
    }

    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e) && this.isEnabled()) {
            if (this.autoRepeatTimer == null) {
                this.autoRepeatTimer = new Timer(60, (e2) -> {
                    if (this.isEnabled()) {
                        this.doClick();
                    }

                });
                this.autoRepeatTimer.setInitialDelay(300);
            }

            this.autoRepeatTimer.start();
        }

    }

    public void mouseReleased(MouseEvent e) {
        if (this.autoRepeatTimer != null) {
            this.autoRepeatTimer.stop();
        }

    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
        if (this.autoRepeatTimer != null && this.isPressed()) {
            this.autoRepeatTimer.start();
        }

    }

    public void mouseExited(MouseEvent e) {
        if (this.autoRepeatTimer != null) {
            this.autoRepeatTimer.stop();
        }

    }
}
