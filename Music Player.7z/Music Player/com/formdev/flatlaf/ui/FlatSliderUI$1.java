//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.Graphics2DProxy;
import java.awt.Color;
import java.awt.Graphics2D;

class FlatSliderUI$1 extends Graphics2DProxy {
    FlatSliderUI$1(FlatSliderUI this$0, Graphics2D delegate) {
        super(delegate);
        this.this$0 = this$0;
    }

    public void setColor(Color c) {
        super.setColor(this.this$0.tickColor);
    }
}
