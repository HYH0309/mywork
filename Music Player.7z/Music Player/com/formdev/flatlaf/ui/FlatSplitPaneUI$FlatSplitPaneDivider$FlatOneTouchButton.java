//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatSplitPaneUI.FlatSplitPaneDivider;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import javax.swing.ToolTipManager;
import javax.swing.UIManager;

public class FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton extends FlatArrowButton {
    protected final boolean left;

    protected FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton(FlatSplitPaneUI.FlatSplitPaneDivider this$1, boolean left) {
        super(1, this$1.this$0.arrowType, this$1.this$0.oneTouchArrowColor, (Color)null, this$1.this$0.oneTouchHoverArrowColor, (Color)null, this$1.this$0.oneTouchPressedArrowColor, (Color)null);
        this.this$1 = this$1;
        this.setCursor(Cursor.getPredefinedCursor(0));
        ToolTipManager.sharedInstance().registerComponent(this);
        this.left = left;
    }

    protected void updateStyle() {
        this.updateStyle(this.this$1.this$0.arrowType, this.this$1.this$0.oneTouchArrowColor, (Color)null, this.this$1.this$0.oneTouchHoverArrowColor, (Color)null, this.this$1.this$0.oneTouchPressedArrowColor, (Color)null);
    }

    public int getDirection() {
        return FlatSplitPaneDivider.access$000(this.this$1) == 0 ? (this.left ? 1 : 5) : (this.left ? 7 : 3);
    }

    public String getToolTipText(MouseEvent e) {
        String key = FlatSplitPaneDivider.access$100(this.this$1) == 0 ? (this.left ? (this.this$1.isRightCollapsed() ? "SplitPaneDivider.expandBottomToolTipText" : "SplitPaneDivider.collapseTopToolTipText") : (this.this$1.isLeftCollapsed() ? "SplitPaneDivider.expandTopToolTipText" : "SplitPaneDivider.collapseBottomToolTipText")) : (this.left ? (this.this$1.isRightCollapsed() ? "SplitPaneDivider.expandRightToolTipText" : "SplitPaneDivider.collapseLeftToolTipText") : (this.this$1.isLeftCollapsed() ? "SplitPaneDivider.expandLeftToolTipText" : "SplitPaneDivider.collapseRightToolTipText"));
        Object value = FlatSplitPaneDivider.access$200(this.this$1).getClientProperty(key);
        return value instanceof String ? (String)value : UIManager.getString(key, this.getLocale());
    }
}
