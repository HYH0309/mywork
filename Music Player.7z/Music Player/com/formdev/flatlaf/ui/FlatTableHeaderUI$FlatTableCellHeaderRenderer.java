//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.plaf.UIResource;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

class FlatTableHeaderUI$FlatTableCellHeaderRenderer implements TableCellRenderer, Border, UIResource {
    private final TableCellRenderer delegate;
    private JLabel l;
    private Color oldBackground;
    private Color oldForeground;
    private Boolean oldOpaque;
    private int oldHorizontalTextPosition;
    private Border origBorder;
    private Icon sortIcon;

    FlatTableHeaderUI$FlatTableCellHeaderRenderer(FlatTableHeaderUI var1, TableCellRenderer delegate) {
        this.this$0 = var1;
        this.oldHorizontalTextPosition = -1;
        this.delegate = delegate;
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        Component c = this.delegate.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        if (!(c instanceof JLabel)) {
            return c;
        } else {
            this.l = (JLabel)c;
            TableColumn draggedColumn = FlatTableHeaderUI.access$100(this.this$0).getDraggedColumn();
            Color background = null;
            Color foreground = null;
            if (draggedColumn != null && FlatTableHeaderUI.access$200(this.this$0).getTable().convertColumnIndexToView(draggedColumn.getModelIndex()) == column) {
                background = this.this$0.pressedBackground;
                foreground = this.this$0.pressedForeground;
            } else if (this.this$0.getRolloverColumn() == column) {
                background = this.this$0.hoverBackground;
                foreground = this.this$0.hoverForeground;
            }

            if (background != null) {
                if (this.oldBackground == null) {
                    this.oldBackground = this.l.getBackground();
                }

                if (this.oldOpaque == null) {
                    this.oldOpaque = this.l.isOpaque();
                }

                this.l.setBackground(FlatUIUtils.deriveColor(background, FlatTableHeaderUI.access$300(this.this$0).getBackground()));
                this.l.setOpaque(true);
            }

            if (foreground != null) {
                if (this.oldForeground == null) {
                    this.oldForeground = this.l.getForeground();
                }

                this.l.setForeground(FlatUIUtils.deriveColor(foreground, FlatTableHeaderUI.access$400(this.this$0).getForeground()));
            }

            if (this.this$0.sortIconPosition == 2) {
                if (this.oldHorizontalTextPosition < 0) {
                    this.oldHorizontalTextPosition = this.l.getHorizontalTextPosition();
                }

                this.l.setHorizontalTextPosition(4);
            } else if (this.this$0.sortIconPosition == 1 || this.this$0.sortIconPosition == 3) {
                this.sortIcon = this.l.getIcon();
                this.origBorder = this.l.getBorder();
                this.l.setIcon((Icon)null);
                this.l.setBorder(this);
            }

            return this.l;
        }
    }

    void reset() {
        if (this.l != null) {
            if (this.oldBackground != null) {
                this.l.setBackground(this.oldBackground);
            }

            if (this.oldForeground != null) {
                this.l.setForeground(this.oldForeground);
            }

            if (this.oldOpaque != null) {
                this.l.setOpaque(this.oldOpaque);
            }

            if (this.oldHorizontalTextPosition >= 0) {
                this.l.setHorizontalTextPosition(this.oldHorizontalTextPosition);
            }

        }
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        if (this.origBorder != null) {
            this.origBorder.paintBorder(c, g, x, y, width, height);
        }

        if (this.sortIcon != null) {
            int xi = x + (width - this.sortIcon.getIconWidth()) / 2;
            int yi = this.this$0.sortIconPosition == 1 ? y + UIScale.scale(1) : y + height - this.sortIcon.getIconHeight() - 1 - (int)(1.0F * UIScale.getUserScaleFactor());
            this.sortIcon.paintIcon(c, g, xi, yi);
        }

    }

    public Insets getBorderInsets(Component c) {
        return this.origBorder != null ? this.origBorder.getBorderInsets(c) : new Insets(0, 0, 0, 0);
    }

    public boolean isBorderOpaque() {
        return this.origBorder != null ? this.origBorder.isBorderOpaque() : false;
    }
}
