//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.util.Map;
import javax.swing.JComponent;

public interface FlatStylingSupport$StyleableUI {
    Map<String, Class<?>> getStyleableInfos(JComponent var1) throws IllegalArgumentException;

    Object getStyleableValue(JComponent var1, String var2) throws IllegalArgumentException;
}
