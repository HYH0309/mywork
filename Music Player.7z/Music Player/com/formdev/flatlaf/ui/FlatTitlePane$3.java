//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Insets;
import java.awt.Point;
import javax.swing.Icon;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;

class FlatTitlePane$3 extends BorderLayout {
    FlatTitlePane$3(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public void layoutContainer(Container target) {
        Insets insets = target.getInsets();
        int x = insets.left;
        int y = insets.top;
        int w = target.getWidth() - insets.left - insets.right;
        int h = target.getHeight() - insets.top - insets.bottom;
        int leftWidth = this.this$0.leftPanel.getPreferredSize().width;
        int buttonsWidth = this.this$0.buttonPanel.getPreferredSize().width;
        int titleWidth = w - leftWidth - buttonsWidth;
        int minTitleWidth = UIScale.scale(this.this$0.titleMinimumWidth);
        Icon icon = this.this$0.titleLabel.getIcon();
        if (icon != null) {
            Insets iconInsets = this.this$0.iconLabel.getInsets();
            int iconTextGap = this.this$0.titleLabel.getComponentOrientation().isLeftToRight() ? iconInsets.right : iconInsets.left;
            minTitleWidth += icon.getIconWidth() + iconTextGap;
        }

        if (titleWidth < minTitleWidth) {
            buttonsWidth = Math.max(buttonsWidth - (minTitleWidth - titleWidth), this.this$0.buttonPanel.getMinimumSize().width);
            titleWidth = w - leftWidth - buttonsWidth;
        }

        if (titleWidth < minTitleWidth) {
            int minLeftWidth = this.this$0.iconLabel.isVisible() ? this.this$0.iconLabel.getWidth() - this.this$0.iconLabel.getInsets().right : UIScale.scale(this.this$0.noIconLeftGap);
            leftWidth = Math.max(leftWidth - (minTitleWidth - titleWidth), minLeftWidth);
            titleWidth = w - leftWidth - buttonsWidth;
        }

        if (target.getComponentOrientation().isLeftToRight()) {
            this.this$0.leftPanel.setBounds(x, y, leftWidth, h);
            this.this$0.titleLabel.setBounds(x + leftWidth, y, titleWidth, h);
            this.this$0.buttonPanel.setBounds(x + leftWidth + titleWidth, y, buttonsWidth, h);
        } else {
            this.this$0.buttonPanel.setBounds(x, y, buttonsWidth, h);
            this.this$0.titleLabel.setBounds(x + buttonsWidth, y, titleWidth, h);
            this.this$0.leftPanel.setBounds(x + buttonsWidth + titleWidth, y, leftWidth, h);
        }

        JMenuBar menuBar = this.this$0.rootPane.getJMenuBar();
        if (this.this$0.hasVisibleEmbeddedMenuBar(menuBar)) {
            Component horizontalGlue = this.this$0.findHorizontalGlue(menuBar);
            if (horizontalGlue != null) {
                Point glueLocation = SwingUtilities.convertPoint(horizontalGlue, 0, 0, this.this$0.titleLabel);
                this.this$0.titleLabel.setBounds(this.this$0.titleLabel.getX() + glueLocation.x, this.this$0.titleLabel.getY(), horizontalGlue.getWidth(), this.this$0.titleLabel.getHeight());
            }
        }

    }
}
