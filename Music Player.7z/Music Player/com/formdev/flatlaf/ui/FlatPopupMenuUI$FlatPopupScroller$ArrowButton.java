//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatPopupMenuUI.FlatPopupScroller;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.Timer;

class FlatPopupMenuUI$FlatPopupScroller$ArrowButton extends FlatArrowButton implements MouseListener, ActionListener {
    private Timer timer;

    FlatPopupMenuUI$FlatPopupScroller$ArrowButton(FlatPopupMenuUI.FlatPopupScroller var1, int direction) {
        super(direction, var1.this$0.arrowType, var1.this$0.scrollArrowColor, (Color)null, (Color)null, var1.this$0.hoverScrollArrowBackground, (Color)null, (Color)null);
        this.this$1 = var1;
        this.addMouseListener(this);
    }

    public void paint(Graphics g) {
        g.setColor(FlatPopupScroller.access$000(this.this$1).getBackground());
        g.fillRect(0, 0, this.getWidth(), this.getHeight());
        super.paint(g);
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
        if (this.timer == null) {
            this.timer = new Timer(50, this);
        }

        this.timer.start();
    }

    public void mouseExited(MouseEvent e) {
        if (this.timer != null) {
            this.timer.stop();
        }

    }

    public void actionPerformed(ActionEvent e) {
        if (this.timer != null && !this.isDisplayable()) {
            this.timer.stop();
        } else {
            this.this$1.scroll(this.direction == 1 ? -1 : 1);
        }
    }
}
