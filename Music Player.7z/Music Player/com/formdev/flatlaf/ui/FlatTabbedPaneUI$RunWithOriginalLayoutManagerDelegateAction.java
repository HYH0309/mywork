//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.JTabbedPane;
import javax.swing.plaf.ComponentUI;

class FlatTabbedPaneUI$RunWithOriginalLayoutManagerDelegateAction implements Action {
    private final Action delegate;

    static void install(ActionMap map, String key) {
        Action oldAction = map.get(key);
        if (oldAction != null && !(oldAction instanceof FlatTabbedPaneUI$RunWithOriginalLayoutManagerDelegateAction)) {
            map.put(key, new FlatTabbedPaneUI$RunWithOriginalLayoutManagerDelegateAction(oldAction));
        }
    }

    private FlatTabbedPaneUI$RunWithOriginalLayoutManagerDelegateAction(Action delegate) {
        this.delegate = delegate;
    }

    public Object getValue(String key) {
        return this.delegate.getValue(key);
    }

    public boolean isEnabled() {
        return this.delegate.isEnabled();
    }

    public void putValue(String key, Object value) {
    }

    public void setEnabled(boolean b) {
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
    }

    public void actionPerformed(ActionEvent e) {
        JTabbedPane tabbedPane = (JTabbedPane)e.getSource();
        ComponentUI ui = tabbedPane.getUI();
        if (ui instanceof FlatTabbedPaneUI) {
            FlatTabbedPaneUI.access$2700((FlatTabbedPaneUI)ui, () -> {
                this.delegate.actionPerformed(e);
            });
        } else {
            this.delegate.actionPerformed(e);
        }

    }
}
