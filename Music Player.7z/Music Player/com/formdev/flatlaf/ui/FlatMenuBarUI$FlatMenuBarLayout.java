//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import javax.swing.JMenuBar;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.plaf.basic.DefaultMenuLayout;

public class FlatMenuBarUI$FlatMenuBarLayout extends DefaultMenuLayout {
    public FlatMenuBarUI$FlatMenuBarLayout(Container target) {
        super(target, 2);
    }

    public void layoutContainer(Container target) {
        super.layoutContainer(target);
        JRootPane rootPane = SwingUtilities.getRootPane(target);
        if (rootPane != null && rootPane.getJMenuBar() == target) {
            FlatTitlePane titlePane = FlatRootPaneUI.getTitlePane(rootPane);
            if (titlePane != null && titlePane.isMenuBarEmbedded()) {
                Component horizontalGlue = titlePane.findHorizontalGlue((JMenuBar)target);
                int minTitleWidth = UIScale.scale(titlePane.titleMinimumWidth);
                if (horizontalGlue != null && horizontalGlue.getWidth() < minTitleWidth) {
                    int glueIndex = -1;
                    Component[] components = target.getComponents();

                    int offset;
                    for(offset = components.length - 1; offset >= 0; --offset) {
                        if (components[offset] == horizontalGlue) {
                            glueIndex = offset;
                            break;
                        }
                    }

                    if (glueIndex < 0) {
                        return;
                    }

                    int minGlueX;
                    int x;
                    Component c;
                    if (target.getComponentOrientation().isLeftToRight()) {
                        offset = minTitleWidth - horizontalGlue.getWidth();
                        horizontalGlue.setSize(minTitleWidth, horizontalGlue.getHeight());
                        minGlueX = target.getWidth() - target.getInsets().right - minTitleWidth;
                        if (minGlueX < horizontalGlue.getX()) {
                            offset -= horizontalGlue.getX() - minGlueX;
                            horizontalGlue.setLocation(minGlueX, horizontalGlue.getY());

                            for(x = glueIndex - 1; x >= 0; --x) {
                                c = components[x];
                                if (c.getX() <= minGlueX) {
                                    c.setSize(minGlueX - c.getX(), c.getHeight());
                                    break;
                                }

                                c.setBounds(minGlueX, c.getY(), 0, c.getHeight());
                            }
                        }

                        for(x = glueIndex + 1; x < components.length; ++x) {
                            c = components[x];
                            c.setLocation(c.getX() + offset, c.getY());
                        }
                    } else {
                        offset = minTitleWidth - horizontalGlue.getWidth();
                        horizontalGlue.setBounds(horizontalGlue.getX() - offset, horizontalGlue.getY(), minTitleWidth, horizontalGlue.getHeight());
                        minGlueX = target.getInsets().left;
                        if (minGlueX > horizontalGlue.getX()) {
                            offset -= horizontalGlue.getX() - minGlueX;
                            horizontalGlue.setLocation(minGlueX, horizontalGlue.getY());
                            x = horizontalGlue.getX() + horizontalGlue.getWidth();

                            for(int i = glueIndex - 1; i >= 0; --i) {
                                Component c = components[i];
                                if (c.getX() + c.getWidth() >= x) {
                                    c.setBounds(x, c.getY(), c.getWidth() - (x - c.getX()), c.getHeight());
                                    break;
                                }

                                c.setBounds(x, c.getY(), 0, c.getHeight());
                            }
                        }

                        for(x = glueIndex + 1; x < components.length; ++x) {
                            c = components[x];
                            c.setLocation(c.getX() - offset, c.getY());
                        }
                    }
                }

            }
        }
    }
}
