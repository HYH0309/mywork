//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.icons.FlatCheckBoxMenuItemIcon;
import java.awt.Component;
import java.awt.Graphics2D;

class FlatComboBoxUI$MacCheckedItemIcon extends FlatCheckBoxMenuItemIcon {
    static FlatComboBoxUI$MacCheckedItemIcon INSTANCE = new FlatComboBoxUI$MacCheckedItemIcon();

    private FlatComboBoxUI$MacCheckedItemIcon() {
    }

    protected void paintIcon(Component c, Graphics2D g2) {
        g2.setColor(c.getForeground());
        this.paintCheckmark(g2);
    }
}
