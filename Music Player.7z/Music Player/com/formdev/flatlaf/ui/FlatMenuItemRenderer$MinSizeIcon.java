//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Graphics;
import javax.swing.Icon;

class FlatMenuItemRenderer$MinSizeIcon implements Icon {
    private final Icon delegate;

    FlatMenuItemRenderer$MinSizeIcon(FlatMenuItemRenderer var1, Icon delegate) {
        this.this$0 = var1;
        this.delegate = delegate;
    }

    public int getIconWidth() {
        int iconWidth = this.delegate != null ? this.delegate.getIconWidth() : 0;
        iconWidth = Math.max(iconWidth, FlatMenuItemRenderer.access$000(this.this$0));
        return Math.max(iconWidth, UIScale.scale(this.this$0.minimumIconSize.width));
    }

    public int getIconHeight() {
        int iconHeight = this.delegate != null ? this.delegate.getIconHeight() : 0;
        return Math.max(iconHeight, UIScale.scale(this.this$0.minimumIconSize.height));
    }

    public void paintIcon(Component c, Graphics g, int x, int y) {
    }
}
