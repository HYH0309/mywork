//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.Animator;
import com.formdev.flatlaf.util.CubicBezierEasing;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import javax.swing.Timer;

public class FlatTabbedPaneUI$FlatWheelTabScroller extends MouseAdapter {
    private int lastMouseX;
    private int lastMouseY;
    private boolean inViewport;
    private boolean scrolled;
    private Timer rolloverTimer;
    private Timer exitedTimer;
    private Animator animator;
    private Point startViewPosition;
    private Point targetViewPosition;

    protected FlatTabbedPaneUI$FlatWheelTabScroller(FlatTabbedPaneUI this$0) {
        this.this$0 = this$0;
    }

    protected void uninstall() {
        if (this.rolloverTimer != null) {
            this.rolloverTimer.stop();
        }

        if (this.exitedTimer != null) {
            this.exitedTimer.stop();
        }

        if (this.animator != null) {
            this.animator.cancel();
        }

    }

    public void mouseWheelMoved(MouseWheelEvent e) {
        if (FlatTabbedPaneUI.access$2800(this.this$0).getMouseWheelListeners().length <= 1) {
            if (this.isInViewport(e.getX(), e.getY())) {
                this.lastMouseX = e.getX();
                this.lastMouseY = e.getY();
                double preciseWheelRotation = e.getPreciseWheelRotation();
                boolean isPreciseWheel = preciseWheelRotation != 0.0 && preciseWheelRotation != (double)e.getWheelRotation();
                int amount = (int)((double)FlatTabbedPaneUI.access$2900(this.this$0) * preciseWheelRotation);
                if (amount == 0) {
                    if (preciseWheelRotation > 0.0) {
                        amount = 1;
                    } else if (preciseWheelRotation < 0.0) {
                        amount = -1;
                    }
                }

                Point viewPosition = this.targetViewPosition != null ? this.targetViewPosition : this.this$0.tabViewport.getViewPosition();
                Dimension viewSize = this.this$0.tabViewport.getViewSize();
                boolean horizontal = this.this$0.isHorizontalTabPlacement();
                int x = viewPosition.x;
                int y = viewPosition.y;
                if (horizontal) {
                    x += FlatTabbedPaneUI.access$1200(this.this$0) ? amount : -amount;
                } else {
                    y += amount;
                }

                if (isPreciseWheel && this.this$0.getScrollButtonsPlacement() == 100 && this.this$0.getScrollButtonsPolicy() == 3 && (FlatTabbedPaneUI.access$1200(this.this$0) || !horizontal) && FlatTabbedPaneUI.access$3000(this.this$0) != null) {
                    if (horizontal) {
                        if (viewPosition.x == 0 && x > 0) {
                            x += FlatTabbedPaneUI.access$3000(this.this$0).width;
                        } else if (amount < 0 && x <= FlatTabbedPaneUI.access$3000(this.this$0).width) {
                            x = 0;
                        }
                    } else if (viewPosition.y == 0 && y > 0) {
                        y += FlatTabbedPaneUI.access$3000(this.this$0).height;
                    } else if (amount < 0 && y <= FlatTabbedPaneUI.access$3000(this.this$0).height) {
                        y = 0;
                    }
                }

                if (horizontal) {
                    x = Math.min(Math.max(x, 0), viewSize.width - this.this$0.tabViewport.getWidth());
                } else {
                    y = Math.min(Math.max(y, 0), viewSize.height - this.this$0.tabViewport.getHeight());
                }

                Point newViewPosition = new Point(x, y);
                if (!newViewPosition.equals(viewPosition)) {
                    if (isPreciseWheel) {
                        if (this.animator != null) {
                            this.animator.stop();
                        }

                        this.this$0.tabViewport.setViewPosition(newViewPosition);
                        this.updateRolloverDelayed();
                    } else {
                        this.setViewPositionAnimated(newViewPosition);
                    }

                    this.scrolled = true;
                }
            }
        }
    }

    protected void setViewPositionAnimated(Point viewPosition) {
        if (!viewPosition.equals(this.this$0.tabViewport.getViewPosition())) {
            if (!this.this$0.isSmoothScrollingEnabled()) {
                this.this$0.tabViewport.setViewPosition(viewPosition);
                this.updateRolloverDelayed();
            } else {
                this.startViewPosition = this.this$0.tabViewport.getViewPosition();
                this.targetViewPosition = viewPosition;
                if (this.animator == null) {
                    int duration = 200;
                    int resolution = 10;
                    this.animator = new Animator(duration, (fraction) -> {
                        if (this.this$0.tabViewport != null && this.this$0.tabViewport.isShowing()) {
                            int x = this.startViewPosition.x + Math.round((float)(this.targetViewPosition.x - this.startViewPosition.x) * fraction);
                            int y = this.startViewPosition.y + Math.round((float)(this.targetViewPosition.y - this.startViewPosition.y) * fraction);
                            this.this$0.tabViewport.setViewPosition(new Point(x, y));
                        } else {
                            this.animator.stop();
                        }
                    }, () -> {
                        this.startViewPosition = this.targetViewPosition = null;
                        if (FlatTabbedPaneUI.access$3600(this.this$0) != null) {
                            this.this$0.setRolloverTab(this.lastMouseX, this.lastMouseY);
                        }

                    });
                    this.animator.setResolution(resolution);
                    this.animator.setInterpolator(new CubicBezierEasing(0.5F, 0.5F, 0.5F, 1.0F));
                }

                this.animator.restart();
            }
        }
    }

    protected void updateRolloverDelayed() {
        FlatTabbedPaneUI.access$3102(this.this$0, true);
        int oldIndex = FlatTabbedPaneUI.access$3200(this.this$0);
        if (oldIndex >= 0) {
            int index = this.this$0.tabForCoordinate(FlatTabbedPaneUI.access$3300(this.this$0), this.lastMouseX, this.lastMouseY);
            if (index >= 0 && index != oldIndex) {
                FlatTabbedPaneUI.access$3102(this.this$0, false);
                this.this$0.setRolloverTab(-1);
                FlatTabbedPaneUI.access$3102(this.this$0, true);
            }
        }

        if (this.rolloverTimer == null) {
            this.rolloverTimer = new Timer(150, (e) -> {
                FlatTabbedPaneUI.access$3102(this.this$0, false);
                if (FlatTabbedPaneUI.access$3500(this.this$0) != null) {
                    this.this$0.setRolloverTab(this.lastMouseX, this.lastMouseY);
                }

            });
            this.rolloverTimer.setRepeats(false);
        }

        this.rolloverTimer.restart();
    }

    public void mouseMoved(MouseEvent e) {
        this.checkViewportExited(e.getX(), e.getY());
    }

    public void mouseExited(MouseEvent e) {
        this.checkViewportExited(e.getX(), e.getY());
    }

    public void mousePressed(MouseEvent e) {
        this.this$0.setRolloverTab(e.getX(), e.getY());
    }

    protected boolean isInViewport(int x, int y) {
        return this.this$0.tabViewport != null && this.this$0.tabViewport.getBounds().contains(x, y);
    }

    protected void checkViewportExited(int x, int y) {
        this.lastMouseX = x;
        this.lastMouseY = y;
        boolean wasInViewport = this.inViewport;
        this.inViewport = this.isInViewport(x, y);
        if (this.inViewport != wasInViewport) {
            if (!this.inViewport) {
                this.viewportExited();
            } else if (this.exitedTimer != null) {
                this.exitedTimer.stop();
            }
        }

    }

    protected void viewportExited() {
        if (this.scrolled) {
            if (this.exitedTimer == null) {
                this.exitedTimer = new Timer(500, (e) -> {
                    this.ensureSelectedTabVisible();
                });
                this.exitedTimer.setRepeats(false);
            }

            this.exitedTimer.start();
        }
    }

    protected void ensureSelectedTabVisible() {
        if (FlatTabbedPaneUI.access$3400(this.this$0) != null && this.this$0.tabViewport != null) {
            if (this.scrolled) {
                this.scrolled = false;
                this.this$0.ensureSelectedTabIsVisible();
            }
        }
    }
}
