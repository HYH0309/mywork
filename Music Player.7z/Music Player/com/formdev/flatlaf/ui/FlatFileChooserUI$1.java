//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

class FlatFileChooserUI$1 implements TableCellRenderer {
    FlatFileChooserUI$1(FlatFileChooserUI this$0, TableCellRenderer var2) {
        this.this$0 = this$0;
        this.val$defaultRenderer = var2;
    }

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value instanceof String && ((String)value).startsWith("\u200e")) {
            String str = (String)value;
            char[] buf = new char[str.length()];
            int j = 0;

            for(int i = 0; i < buf.length; ++i) {
                char ch = str.charAt(i);
                if (ch != 8206 && ch != 8207) {
                    buf[j++] = ch;
                }
            }

            value = new String(buf, 0, j);
        }

        return this.val$defaultRenderer.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }
}
