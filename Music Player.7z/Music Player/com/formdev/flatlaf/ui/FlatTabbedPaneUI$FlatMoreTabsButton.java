//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.StringUtils;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.accessibility.Accessible;
import javax.accessibility.AccessibleContext;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.text.JTextComponent;

public class FlatTabbedPaneUI$FlatMoreTabsButton extends FlatTabbedPaneUI.FlatTabAreaButton implements ActionListener, PopupMenuListener {
    private boolean popupVisible;

    public FlatTabbedPaneUI$FlatMoreTabsButton(FlatTabbedPaneUI this$0) {
        super(this$0, 5);
        this.this$0 = this$0;
        this.updateDirection();
        this.setToolTipText(this$0.moreTabsButtonToolTipText);
        this.addActionListener(this);
    }

    protected void updateDirection() {
        byte direction;
        switch (FlatTabbedPaneUI.access$900(this.this$0).getTabPlacement()) {
            case 1:
            default:
                direction = 5;
                break;
            case 2:
                direction = 3;
                break;
            case 3:
                direction = 1;
                break;
            case 4:
                direction = 7;
        }

        this.setDirection(direction);
    }

    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        boolean horizontal = this.direction == 5 || this.direction == 1;
        int margin = UIScale.scale(8);
        return new Dimension(size.width + (horizontal ? margin : 0), size.height + (horizontal ? 0 : margin));
    }

    public void paint(Graphics g) {
        if (this.direction != 3 && this.direction != 7) {
            this.setXOffset(0.0F);
        } else {
            int xoffset = Math.max(UIScale.unscale((this.getWidth() - this.getHeight()) / 2) - 4, 0);
            this.setXOffset(this.direction == 3 ? (float)xoffset : (float)(-xoffset));
        }

        super.paint(g);
    }

    protected boolean isHover() {
        return super.isHover() || this.popupVisible;
    }

    public void actionPerformed(ActionEvent e) {
        if (this.this$0.tabViewport != null) {
            JPopupMenu popupMenu = new JPopupMenu();
            popupMenu.addPopupMenuListener(this);
            Rectangle viewRect = this.this$0.tabViewport.getViewRect();
            int lastIndex = -1;

            int i;
            for(i = 0; i < FlatTabbedPaneUI.access$1000(this.this$0).length; ++i) {
                if (!viewRect.contains(FlatTabbedPaneUI.access$1100(this.this$0)[i])) {
                    if (lastIndex >= 0 && lastIndex + 1 != i) {
                        popupMenu.addSeparator();
                    }

                    lastIndex = i;
                    popupMenu.add(this.createTabMenuItem(i));
                }
            }

            i = this.getWidth();
            int buttonHeight = this.getHeight();
            Dimension popupSize = popupMenu.getPreferredSize();
            int x = FlatTabbedPaneUI.access$1200(this.this$0) ? i - popupSize.width : 0;
            int y = buttonHeight - popupSize.height;
            switch (FlatTabbedPaneUI.access$1300(this.this$0).getTabPlacement()) {
                case 1:
                default:
                    y = buttonHeight;
                    break;
                case 2:
                    x = i;
                    break;
                case 3:
                    y = -popupSize.height;
                    break;
                case 4:
                    x = -popupSize.width;
            }

            popupMenu.show(this, x, y);
        }
    }

    protected JMenuItem createTabMenuItem(int tabIndex) {
        String title = FlatTabbedPaneUI.access$1400(this.this$0).getTitleAt(tabIndex);
        if (StringUtils.isEmpty(title)) {
            Component tabComp = FlatTabbedPaneUI.access$1500(this.this$0).getTabComponentAt(tabIndex);
            if (tabComp != null) {
                title = this.findTabTitle(tabComp);
            }

            if (StringUtils.isEmpty(title)) {
                title = FlatTabbedPaneUI.access$1600(this.this$0).getAccessibleContext().getAccessibleChild(tabIndex).getAccessibleContext().getAccessibleName();
            }

            if (StringUtils.isEmpty(title) && tabComp instanceof Accessible) {
                title = this.findTabTitleInAccessible((Accessible)tabComp);
            }

            if (StringUtils.isEmpty(title)) {
                title = tabIndex + 1 + ". Tab";
            }
        }

        JMenuItem menuItem = new JMenuItem(title, FlatTabbedPaneUI.access$1700(this.this$0).getIconAt(tabIndex));
        menuItem.setDisabledIcon(FlatTabbedPaneUI.access$1800(this.this$0).getDisabledIconAt(tabIndex));
        menuItem.setToolTipText(FlatTabbedPaneUI.access$1900(this.this$0).getToolTipTextAt(tabIndex));
        Color foregroundAt = FlatTabbedPaneUI.access$2000(this.this$0).getForegroundAt(tabIndex);
        if (foregroundAt != FlatTabbedPaneUI.access$2100(this.this$0).getForeground()) {
            menuItem.setForeground(foregroundAt);
        }

        Color backgroundAt = FlatTabbedPaneUI.access$2200(this.this$0).getBackgroundAt(tabIndex);
        if (backgroundAt != FlatTabbedPaneUI.access$2300(this.this$0).getBackground()) {
            menuItem.setBackground(backgroundAt);
            menuItem.setOpaque(true);
        }

        if (!FlatTabbedPaneUI.access$2400(this.this$0).isEnabled() || !FlatTabbedPaneUI.access$2500(this.this$0).isEnabledAt(tabIndex)) {
            menuItem.setEnabled(false);
        }

        menuItem.addActionListener((e) -> {
            this.selectTab(tabIndex);
        });
        return menuItem;
    }

    private String findTabTitle(Component c) {
        String title = null;
        if (c instanceof JLabel) {
            title = ((JLabel)c).getText();
        } else if (c instanceof JTextComponent) {
            title = ((JTextComponent)c).getText();
        }

        if (!StringUtils.isEmpty(title)) {
            return title;
        } else {
            if (c instanceof Container) {
                Component[] var3 = ((Container)c).getComponents();
                int var4 = var3.length;

                for(int var5 = 0; var5 < var4; ++var5) {
                    Component child = var3[var5];
                    title = this.findTabTitle(child);
                    if (title != null) {
                        return title;
                    }
                }
            }

            return null;
        }
    }

    private String findTabTitleInAccessible(Accessible accessible) {
        AccessibleContext context = accessible.getAccessibleContext();
        if (context == null) {
            return null;
        } else {
            String title = context.getAccessibleName();
            if (!StringUtils.isEmpty(title)) {
                return title;
            } else {
                int childrenCount = context.getAccessibleChildrenCount();

                for(int i = 0; i < childrenCount; ++i) {
                    title = this.findTabTitleInAccessible(context.getAccessibleChild(i));
                    if (title != null) {
                        return title;
                    }
                }

                return null;
            }
        }
    }

    protected void selectTab(int tabIndex) {
        FlatTabbedPaneUI.access$2600(this.this$0).setSelectedIndex(tabIndex);
        this.this$0.ensureSelectedTabIsVisible();
    }

    public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
        this.popupVisible = true;
        this.repaint();
    }

    public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
        this.popupVisible = false;
        this.repaint();
    }

    public void popupMenuCanceled(PopupMenuEvent e) {
        this.popupVisible = false;
        this.repaint();
    }
}
