//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Container;
import java.awt.Dimension;
import javax.swing.plaf.basic.DefaultMenuLayout;

public class FlatPopupMenuUI$FlatPopupMenuLayout extends DefaultMenuLayout {
    public FlatPopupMenuUI$FlatPopupMenuLayout(Container target, int axis) {
        super(target, axis);
    }

    public Dimension preferredLayoutSize(Container target) {
        FlatMenuItemRenderer.clearClientProperties(target);
        return super.preferredLayoutSize(target);
    }
}
