//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Color;

class FlatSpinnerUI$1 extends FlatArrowButton {
    FlatSpinnerUI$1(FlatSpinnerUI this$0, int direction, String type, Color foreground, Color disabledForeground, Color hoverForeground, Color hoverBackground, Color pressedForeground, Color pressedBackground) {
        super(direction, type, foreground, disabledForeground, hoverForeground, hoverBackground, pressedForeground, pressedBackground);
        this.this$0 = this$0;
    }

    public int getArrowWidth() {
        return this.this$0.isMacStyle() ? 7 : super.getArrowWidth();
    }

    public float getArrowThickness() {
        return this.this$0.isMacStyle() ? 1.5F : super.getArrowThickness();
    }

    public float getYOffset() {
        return this.this$0.isMacStyle() ? 0.0F : super.getYOffset();
    }

    public boolean isRoundBorderAutoXOffset() {
        return this.this$0.isMacStyle() ? false : super.isRoundBorderAutoXOffset();
    }
}
