//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;

class FlatDesktopPaneUI$LayoutDockListener extends ComponentAdapter implements ContainerListener {
    private FlatDesktopPaneUI$LayoutDockListener(FlatDesktopPaneUI var1) {
        this.this$0 = var1;
    }

    public void componentAdded(ContainerEvent e) {
        FlatDesktopPaneUI.access$100(this.this$0);
    }

    public void componentRemoved(ContainerEvent e) {
        FlatDesktopPaneUI.access$100(this.this$0);
    }

    public void componentResized(ComponentEvent e) {
        FlatDesktopPaneUI.access$100(this.this$0);
    }
}
