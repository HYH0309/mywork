//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.EventQueue;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.UIManager;
import javax.swing.plaf.UIResource;

class FlatComboBoxUI$FlatKeySelectionManager implements JComboBox.KeySelectionManager, UIResource {
    private final JComboBox.KeySelectionManager delegate;
    private final long timeFactor;
    private long lastTime;

    FlatComboBoxUI$FlatKeySelectionManager(FlatComboBoxUI var1, JComboBox.KeySelectionManager delegate) {
        this.this$0 = var1;
        this.delegate = delegate;
        Long value = (Long)UIManager.get("ComboBox.timeFactor");
        this.timeFactor = value != null ? value : 1000L;
    }

    public int selectionForKey(char aKey, ComboBoxModel aModel) {
        long time = EventQueue.getMostRecentEventTime();
        long oldLastTime = this.lastTime;
        this.lastTime = time;
        if (aKey == ' ' && time - oldLastTime >= this.timeFactor && !FlatComboBoxUI.access$4300(this.this$0).isPopupVisible()) {
            FlatComboBoxUI.access$4400(this.this$0).setPopupVisible(true);
            return -1;
        } else {
            return this.delegate.selectionForKey(aKey, aModel);
        }
    }
}
