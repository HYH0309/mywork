//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatNativeWindowBorder.WindowTopBorder;
import com.formdev.flatlaf.util.SystemInfo;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.SwingUtilities;

public class FlatTitlePane$Handler extends WindowAdapter implements PropertyChangeListener, MouseListener, MouseMotionListener, ComponentListener {
    private Point dragOffset;
    private boolean linuxNativeMove;
    private long lastSingleClickWhen;

    protected FlatTitlePane$Handler(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public void propertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "title":
                this.this$0.titleLabel.setText(this.this$0.getWindowTitle());
                break;
            case "resizable":
                if (this.this$0.window instanceof Frame) {
                    this.this$0.frameStateChanged();
                }
                break;
            case "iconImage":
                this.this$0.updateIcon();
                break;
            case "componentOrientation":
                this.this$0.updateNativeTitleBarHeightAndHitTestSpotsLater();
        }

    }

    public void windowActivated(WindowEvent e) {
        this.this$0.activeChanged(true);
        this.this$0.updateNativeTitleBarHeightAndHitTestSpots();
        if (!SystemInfo.isWindows_11_orLater && this.this$0.hasNativeCustomDecoration()) {
            WindowTopBorder.getInstance().repaintBorder(this.this$0);
        }

        this.this$0.repaintWindowBorder();
    }

    public void windowDeactivated(WindowEvent e) {
        this.this$0.activeChanged(false);
        this.this$0.updateNativeTitleBarHeightAndHitTestSpots();
        if (!SystemInfo.isWindows_11_orLater && this.this$0.hasNativeCustomDecoration()) {
            WindowTopBorder.getInstance().repaintBorder(this.this$0);
        }

        this.this$0.repaintWindowBorder();
    }

    public void windowStateChanged(WindowEvent e) {
        this.this$0.frameStateChanged();
        this.this$0.updateNativeTitleBarHeightAndHitTestSpots();
    }

    public void mouseClicked(MouseEvent e) {
        if (this.linuxNativeMove && SystemInfo.isLinux && FlatNativeLinuxLibrary.isWMUtilsSupported(this.this$0.window)) {
            if (this.lastSingleClickWhen != 0L && e.getWhen() - this.lastSingleClickWhen <= (long)this.getMultiClickInterval()) {
                this.lastSingleClickWhen = 0L;
                FlatTitlePane.access$000(this.this$0);
            }

        } else {
            if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                if (e.getSource() == this.this$0.iconLabel) {
                    this.this$0.close();
                } else if (!this.this$0.hasNativeCustomDecoration()) {
                    FlatTitlePane.access$000(this.this$0);
                }
            }

        }
    }

    public void mousePressed(MouseEvent e) {
        if (this.this$0.window != null) {
            if (SwingUtilities.isRightMouseButton(e) && SystemInfo.isLinux && FlatNativeLinuxLibrary.isWMUtilsSupported(this.this$0.window)) {
                e.consume();
                FlatNativeLinuxLibrary.showWindowMenu(this.this$0.window, e);
            } else if (SwingUtilities.isLeftMouseButton(e)) {
                this.dragOffset = SwingUtilities.convertPoint(this.this$0, e.getPoint(), this.this$0.window);
                this.linuxNativeMove = false;
                if (SystemInfo.isLinux && FlatNativeLinuxLibrary.isWMUtilsSupported(this.this$0.window)) {
                    int clickCount = e.getClickCount();
                    if (clickCount == 1 && this.lastSingleClickWhen != 0L && e.getWhen() - this.lastSingleClickWhen <= (long)this.getMultiClickInterval()) {
                        clickCount = 2;
                    }

                    switch (clickCount) {
                        case 1:
                            e.consume();
                            this.linuxNativeMove = FlatNativeLinuxLibrary.moveOrResizeWindow(this.this$0.window, e, 8);
                            this.lastSingleClickWhen = e.getWhen();
                            break;
                        case 2:
                            this.lastSingleClickWhen = 0L;
                            FlatTitlePane.access$000(this.this$0);
                    }
                }

            }
        }
    }

    private int getMultiClickInterval() {
        Object value = Toolkit.getDefaultToolkit().getDesktopProperty("awt.multiClickInterval");
        return value instanceof Integer ? (Integer)value : 500;
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
        if (this.this$0.window != null && this.dragOffset != null) {
            if (!this.linuxNativeMove) {
                if (SwingUtilities.isLeftMouseButton(e)) {
                    if (!this.this$0.hasNativeCustomDecoration()) {
                        int newY;
                        if (this.this$0.window instanceof Frame) {
                            Frame frame = (Frame)this.this$0.window;
                            newY = frame.getExtendedState();
                            if ((newY & 6) != 0) {
                                int maximizedWidth = this.this$0.window.getWidth();
                                frame.setExtendedState(newY & -7);
                                int restoredWidth = this.this$0.window.getWidth();
                                int center = restoredWidth / 2;
                                if (this.dragOffset.x > center) {
                                    if (this.dragOffset.x > maximizedWidth - center) {
                                        this.dragOffset.x = restoredWidth - (maximizedWidth - this.dragOffset.x);
                                    } else {
                                        this.dragOffset.x = center;
                                    }
                                }
                            }
                        }

                        int newX = e.getXOnScreen() - this.dragOffset.x;
                        newY = e.getYOnScreen() - this.dragOffset.y;
                        if (newX != this.this$0.window.getX() || newY != this.this$0.window.getY()) {
                            this.this$0.window.setLocation(newX, newY);
                        }
                    }
                }
            }
        }
    }

    public void mouseMoved(MouseEvent e) {
    }

    public void componentResized(ComponentEvent e) {
        this.this$0.updateNativeTitleBarHeightAndHitTestSpotsLater();
    }

    public void componentShown(ComponentEvent e) {
        this.this$0.frameStateChanged();
    }

    public void componentMoved(ComponentEvent e) {
    }

    public void componentHidden(ComponentEvent e) {
    }
}
