//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.SystemInfo;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import javax.swing.JRootPane;

public class FlatWindowResizer$WindowResizer extends FlatWindowResizer implements WindowStateListener {
    protected Window window;
    private final boolean limitResizeToScreenBounds;

    public FlatWindowResizer$WindowResizer(JRootPane rootPane) {
        super(rootPane);
        this.limitResizeToScreenBounds = SystemInfo.isLinux;
    }

    protected void addNotify() {
        Container parent = this.resizeComp.getParent();
        this.window = parent instanceof Window ? (Window)parent : null;
        if (this.window instanceof Frame) {
            this.window.addPropertyChangeListener("resizable", this);
            this.window.addWindowStateListener(this);
        }

        super.addNotify();
    }

    protected void removeNotify() {
        if (this.window instanceof Frame) {
            this.window.removePropertyChangeListener("resizable", this);
            this.window.removeWindowStateListener(this);
        }

        this.window = null;
        super.removeNotify();
    }

    protected boolean isWindowResizable() {
        if (FlatUIUtils.isFullScreen(this.resizeComp)) {
            return false;
        } else if (!(this.window instanceof Frame)) {
            return this.window instanceof Dialog ? ((Dialog)this.window).isResizable() : false;
        } else {
            return ((Frame)this.window).isResizable() && (((Frame)this.window).getExtendedState() & 6) == 0;
        }
    }

    protected Rectangle getWindowBounds() {
        return this.window.getBounds();
    }

    protected void setWindowBounds(Rectangle r) {
        this.window.setBounds(r);
        this.doLayout();
        if (Toolkit.getDefaultToolkit().isDynamicLayoutActive()) {
            this.window.validate();
            this.resizeComp.repaint();
        }

    }

    protected boolean limitToParentBounds() {
        return this.limitResizeToScreenBounds && this.window != null;
    }

    protected Rectangle getParentBounds() {
        if (this.limitResizeToScreenBounds && this.window != null) {
            GraphicsConfiguration gc = this.window.getGraphicsConfiguration();
            Rectangle bounds = gc.getBounds();
            Insets insets = this.window.getToolkit().getScreenInsets(gc);
            return new Rectangle(bounds.x + insets.left, bounds.y + insets.top, bounds.width - insets.left - insets.right, bounds.height - insets.top - insets.bottom);
        } else {
            return null;
        }
    }

    protected boolean honorMinimumSizeOnResize() {
        return this.honorFrameMinimumSizeOnResize && this.window instanceof Frame || this.honorDialogMinimumSizeOnResize && this.window instanceof Dialog;
    }

    protected boolean honorMaximumSizeOnResize() {
        return false;
    }

    protected Dimension getWindowMinimumSize() {
        return this.window.getMinimumSize();
    }

    protected Dimension getWindowMaximumSize() {
        return this.window.getMaximumSize();
    }

    boolean isDialog() {
        return this.window instanceof Dialog;
    }

    public void windowStateChanged(WindowEvent e) {
        this.updateVisibility();
    }
}
