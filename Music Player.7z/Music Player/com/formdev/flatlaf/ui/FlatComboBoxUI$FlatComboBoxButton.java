//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Color;
import java.awt.Graphics2D;

public class FlatComboBoxUI$FlatComboBoxButton extends FlatArrowButton {
    protected FlatComboBoxUI$FlatComboBoxButton(FlatComboBoxUI this$0) {
        this(this$0, 5, this$0.arrowType, this$0.buttonArrowColor, this$0.buttonDisabledArrowColor, this$0.buttonHoverArrowColor, (Color)null, this$0.buttonPressedArrowColor, (Color)null);
    }

    protected FlatComboBoxUI$FlatComboBoxButton(FlatComboBoxUI this$0, int direction, String type, Color foreground, Color disabledForeground, Color hoverForeground, Color hoverBackground, Color pressedForeground, Color pressedBackground) {
        super(direction, type, foreground, disabledForeground, hoverForeground, hoverBackground, pressedForeground, pressedBackground);
        this.this$0 = this$0;
    }

    protected void updateStyle() {
        this.updateStyle(this.this$0.arrowType, this.this$0.buttonArrowColor, this.this$0.buttonDisabledArrowColor, this.this$0.buttonHoverArrowColor, (Color)null, this.this$0.buttonPressedArrowColor, (Color)null);
    }

    public int getArrowWidth() {
        return FlatComboBoxUI.access$2700(this.this$0) ? (this.getWidth() % 2 == 0 ? 6 : 7) : super.getArrowWidth();
    }

    public float getArrowThickness() {
        return FlatComboBoxUI.access$2700(this.this$0) ? 1.5F : super.getArrowThickness();
    }

    public boolean isRoundBorderAutoXOffset() {
        return FlatComboBoxUI.access$2700(this.this$0) ? false : super.isRoundBorderAutoXOffset();
    }

    protected boolean isHover() {
        return super.isHover() || !FlatComboBoxUI.access$2800(this.this$0).isEditable() && this.this$0.hover;
    }

    protected boolean isPressed() {
        return super.isPressed() || !FlatComboBoxUI.access$2900(this.this$0).isEditable() && this.this$0.pressed;
    }

    protected Color getArrowColor() {
        return FlatComboBoxUI.access$3000(this.this$0) && FlatComboBoxUI.access$3100(this.this$0) ? FlatComboBoxUI.access$3200(this.this$0).getForeground() : super.getArrowColor();
    }

    protected void paintArrow(Graphics2D g) {
        if (FlatComboBoxUI.access$2700(this.this$0) && !FlatComboBoxUI.access$3300(this.this$0).isEditable()) {
            int height = this.getHeight();
            int h = Math.round((float)height / 2.0F);
            FlatUIUtils.paintArrow(g, 0, 0, this.getWidth(), h, 1, this.chevron, this.getArrowWidth(), this.getArrowThickness(), this.getXOffset(), this.getYOffset() + 1.25F);
            FlatUIUtils.paintArrow(g, 0, height - h, this.getWidth(), h, 5, this.chevron, this.getArrowWidth(), this.getArrowThickness(), this.getXOffset(), this.getYOffset() - 1.25F);
        } else {
            super.paintArrow(g);
        }

    }
}
