//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Point;
import java.awt.Rectangle;
import javax.swing.JButton;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

public class FlatTabbedPaneUI$FlatTabbedPaneScrollLayout extends FlatTabbedPaneUI.FlatTabbedPaneLayout implements LayoutManager {
    private final BasicTabbedPaneUI.TabbedPaneLayout delegate;

    protected FlatTabbedPaneUI$FlatTabbedPaneScrollLayout(FlatTabbedPaneUI this$0, BasicTabbedPaneUI.TabbedPaneLayout delegate) {
        super(this$0);
        this.this$0 = this$0;
        this.delegate = delegate;
    }

    public void calculateLayoutInfo() {
        this.delegate.calculateLayoutInfo();
    }

    protected Dimension calculateTabAreaSize() {
        Dimension size = super.calculateTabAreaSize();
        if (this.this$0.isHorizontalTabPlacement()) {
            size.width = Math.min(size.width, UIScale.scale(100));
        } else {
            size.height = Math.min(size.height, UIScale.scale(100));
        }

        return size;
    }

    public Dimension preferredLayoutSize(Container parent) {
        return this.isContentEmpty() ? this.calculateTabAreaSize() : this.delegate.preferredLayoutSize(parent);
    }

    public Dimension minimumLayoutSize(Container parent) {
        return this.isContentEmpty() ? this.calculateTabAreaSize() : this.delegate.minimumLayoutSize(parent);
    }

    public void addLayoutComponent(String name, Component comp) {
        this.delegate.addLayoutComponent(name, comp);
    }

    public void removeLayoutComponent(Component comp) {
        this.delegate.removeLayoutComponent(comp);
    }

    public void layoutContainer(Container parent) {
        FlatTabbedPaneUI.access$2700(this.this$0, () -> {
            this.delegate.layoutContainer(parent);
        });
        int tabsPopupPolicy = this.this$0.getTabsPopupPolicy();
        int scrollButtonsPolicy = this.this$0.getScrollButtonsPolicy();
        int scrollButtonsPlacement = this.this$0.getScrollButtonsPlacement();
        boolean useMoreTabsButton = tabsPopupPolicy == 2;
        boolean useScrollButtons = scrollButtonsPolicy == 2 || scrollButtonsPolicy == 3;
        boolean hideDisabledScrollButtons = scrollButtonsPolicy == 3 && scrollButtonsPlacement == 100;
        boolean trailingScrollButtons = scrollButtonsPlacement == 11;
        boolean leftToRight = FlatTabbedPaneUI.access$1200(this.this$0);
        if (!leftToRight && this.this$0.isHorizontalTabPlacement()) {
            useMoreTabsButton = true;
            useScrollButtons = false;
        }

        JButton backwardButton = null;
        JButton forwardButton = null;
        Component[] var12 = FlatTabbedPaneUI.access$9700(this.this$0).getComponents();
        int var13 = var12.length;

        int tabPlacement;
        for(tabPlacement = 0; tabPlacement < var13; ++tabPlacement) {
            Component c = var12[tabPlacement];
            if (c instanceof FlatTabbedPaneUI.FlatScrollableTabButton) {
                int direction = ((FlatTabbedPaneUI.FlatScrollableTabButton)c).getDirection();
                if (direction != 7 && direction != 1) {
                    if (direction == 3 || direction == 5) {
                        forwardButton = (JButton)c;
                    }
                } else {
                    backwardButton = (JButton)c;
                }
            }
        }

        if (backwardButton != null && forwardButton != null) {
            Rectangle bounds = FlatTabbedPaneUI.access$9800(this.this$0).getBounds();
            Insets insets = FlatTabbedPaneUI.access$9900(this.this$0).getInsets();
            tabPlacement = FlatTabbedPaneUI.access$10000(this.this$0).getTabPlacement();
            int tabAreaAlignment = this.this$0.getTabAreaAlignment();
            Insets tabAreaInsets = this.this$0.getRealTabAreaInsets(tabPlacement);
            boolean moreTabsButtonVisible = false;
            boolean backwardButtonVisible = false;
            boolean forwardButtonVisible = false;
            if (tabAreaInsets.left != 0 || tabAreaInsets.top != 0) {
                FlatTabbedPaneUI.access$7600(this.this$0, -tabAreaInsets.left, -tabAreaInsets.top);
                Component view = this.this$0.tabViewport.getView();
                Dimension viewSize = view.getPreferredSize();
                boolean horizontal = tabPlacement == 1 || tabPlacement == 3;
                view.setPreferredSize(new Dimension(viewSize.width - (horizontal ? tabAreaInsets.left : 0), viewSize.height - (horizontal ? 0 : tabAreaInsets.top)));
            }

            int tw;
            int th;
            int topHeight;
            int bottomHeight;
            int availWidth;
            int totalTabWidth;
            int tyi;
            int leftWidth;
            int h;
            int buttonHeight;
            Point viewPosition;
            int tabAreaHeight;
            int tx;
            int ty;
            if (tabPlacement != 1 && tabPlacement != 3) {
                if (useScrollButtons && hideDisabledScrollButtons) {
                    viewPosition = this.this$0.tabViewport.getViewPosition();
                    if (viewPosition.y <= backwardButton.getPreferredSize().height) {
                        this.this$0.tabViewport.setViewPosition(new Point(viewPosition.x, 0));
                    }
                }

                tabAreaHeight = FlatTabbedPaneUI.access$11000(this.this$0) > 0 ? FlatTabbedPaneUI.access$11100(this.this$0) : Math.max(FlatTabbedPaneUI.access$8200(this.this$0), FlatTabbedPaneUI.access$7500(this.this$0));
                tx = tabPlacement == 2 ? insets.left + tabAreaInsets.left : bounds.width - insets.right - tabAreaInsets.right - tabAreaHeight;
                ty = insets.top;
                tw = tabAreaHeight;
                th = bounds.height - insets.top - insets.bottom;
                topHeight = FlatTabbedPaneUI.access$7900(this.this$0);
                bottomHeight = FlatTabbedPaneUI.access$8000(this.this$0);
                availWidth = th - topHeight - bottomHeight - tabAreaInsets.top - tabAreaInsets.bottom;
                totalTabWidth = FlatTabbedPaneUI.access$11200(this.this$0).length > 0 ? FlatTabbedPaneUI.access$9400(this.this$0) : 0;
                if (totalTabWidth < availWidth && FlatTabbedPaneUI.access$11300(this.this$0).length > 0) {
                    tyi = availWidth - totalTabWidth;
                    switch (tabAreaAlignment) {
                        case 0:
                            topHeight += tyi / 2;
                            bottomHeight += tyi - tyi / 2;
                            break;
                        case 10:
                            bottomHeight += tyi;
                            break;
                        case 11:
                            topHeight += tyi;
                            break;
                        case 100:
                            FlatTabbedPaneUI.access$9500(this.this$0, tyi);
                            totalTabWidth = FlatTabbedPaneUI.access$9400(this.this$0);
                    }
                } else if (FlatTabbedPaneUI.access$11400(this.this$0).length == 0) {
                    bottomHeight = th - topHeight;
                }

                if (FlatTabbedPaneUI.access$8800(this.this$0) != null) {
                    FlatTabbedPaneUI.access$8800(this.this$0).setBounds(tx, ty, tw, topHeight);
                }

                if (FlatTabbedPaneUI.access$8900(this.this$0) != null) {
                    FlatTabbedPaneUI.access$8900(this.this$0).setBounds(tx, ty + th - bottomHeight, tw, bottomHeight);
                }

                if (FlatTabbedPaneUI.access$11500(this.this$0).length > 0) {
                    tyi = ty + topHeight + tabAreaInsets.top;
                    leftWidth = th - topHeight - bottomHeight - tabAreaInsets.top - tabAreaInsets.bottom;
                    int y = tyi;
                    h = leftWidth;
                    if (h < totalTabWidth) {
                        if (useMoreTabsButton) {
                            buttonHeight = FlatTabbedPaneUI.access$5100(this.this$0).getPreferredSize().height;
                            FlatTabbedPaneUI.access$5100(this.this$0).setBounds(tx, tyi + h - buttonHeight, tw, buttonHeight);
                            h -= buttonHeight;
                            moreTabsButtonVisible = true;
                        }

                        if (useScrollButtons) {
                            if (!hideDisabledScrollButtons || forwardButton.isEnabled()) {
                                buttonHeight = forwardButton.getPreferredSize().height;
                                forwardButton.setBounds(tx, tyi + h - buttonHeight, tw, buttonHeight);
                                h -= buttonHeight;
                                forwardButtonVisible = true;
                            }

                            if (!hideDisabledScrollButtons || backwardButton.isEnabled()) {
                                buttonHeight = backwardButton.getPreferredSize().height;
                                if (trailingScrollButtons) {
                                    backwardButton.setBounds(tx, tyi + h - buttonHeight, tw, buttonHeight);
                                } else {
                                    backwardButton.setBounds(tx, tyi, tw, buttonHeight);
                                    y = tyi + buttonHeight;
                                }

                                h -= buttonHeight;
                                backwardButtonVisible = true;
                            }
                        }
                    }

                    this.this$0.tabViewport.setBounds(tx, y, tw, h);
                }
            } else {
                if (useScrollButtons && hideDisabledScrollButtons) {
                    viewPosition = this.this$0.tabViewport.getViewPosition();
                    if (viewPosition.x <= backwardButton.getPreferredSize().width) {
                        this.this$0.tabViewport.setViewPosition(new Point(0, viewPosition.y));
                    }
                }

                tabAreaHeight = FlatTabbedPaneUI.access$10100(this.this$0) > 0 ? FlatTabbedPaneUI.access$10200(this.this$0) : Math.max(Math.max(FlatTabbedPaneUI.access$7900(this.this$0), FlatTabbedPaneUI.access$8000(this.this$0)), UIScale.scale(FlatClientProperties.clientPropertyInt(FlatTabbedPaneUI.access$10300(this.this$0), "JTabbedPane.tabHeight", this.this$0.tabHeight)));
                tx = insets.left;
                ty = tabPlacement == 1 ? insets.top + tabAreaInsets.top : bounds.height - insets.bottom - tabAreaInsets.bottom - tabAreaHeight;
                tw = bounds.width - insets.left - insets.right;
                th = tabAreaHeight;
                topHeight = FlatTabbedPaneUI.access$8200(this.this$0);
                bottomHeight = FlatTabbedPaneUI.access$7500(this.this$0);
                availWidth = tw - topHeight - bottomHeight - tabAreaInsets.left - tabAreaInsets.right;
                totalTabWidth = FlatTabbedPaneUI.access$10400(this.this$0).length > 0 ? FlatTabbedPaneUI.access$8500(this.this$0, leftToRight) : 0;
                if (totalTabWidth < availWidth && FlatTabbedPaneUI.access$10500(this.this$0).length > 0) {
                    tyi = availWidth - totalTabWidth;
                    switch (tabAreaAlignment) {
                        case 0:
                            topHeight += tyi / 2;
                            bottomHeight += tyi - tyi / 2;
                            break;
                        case 10:
                            bottomHeight += tyi;
                            break;
                        case 11:
                            topHeight += tyi;
                            break;
                        case 100:
                            FlatTabbedPaneUI.access$8600(this.this$0, tyi, leftToRight);
                            totalTabWidth = FlatTabbedPaneUI.access$8500(this.this$0, leftToRight);
                    }
                } else if (FlatTabbedPaneUI.access$10600(this.this$0).length == 0) {
                    bottomHeight = tw - topHeight;
                }

                Container leftComponent = leftToRight ? FlatTabbedPaneUI.access$8800(this.this$0) : FlatTabbedPaneUI.access$8900(this.this$0);
                leftWidth = leftToRight ? topHeight : bottomHeight;
                if (leftComponent != null) {
                    leftComponent.setBounds(tx, ty, leftWidth, th);
                }

                Container rightComponent = leftToRight ? FlatTabbedPaneUI.access$8900(this.this$0) : FlatTabbedPaneUI.access$8800(this.this$0);
                h = leftToRight ? bottomHeight : topHeight;
                if (rightComponent != null) {
                    rightComponent.setBounds(tx + tw - h, ty, h, th);
                }

                if (FlatTabbedPaneUI.access$10700(this.this$0).length > 0) {
                    buttonHeight = tx + leftWidth + (leftToRight ? tabAreaInsets.left : tabAreaInsets.right);
                    int twi = tw - leftWidth - h - tabAreaInsets.left - tabAreaInsets.right;
                    int x = buttonHeight;
                    int w = twi;
                    if (w < totalTabWidth) {
                        int buttonWidth;
                        if (useMoreTabsButton) {
                            buttonWidth = FlatTabbedPaneUI.access$5100(this.this$0).getPreferredSize().width;
                            FlatTabbedPaneUI.access$5100(this.this$0).setBounds(leftToRight ? x + w - buttonWidth : x, ty, buttonWidth, th);
                            x += leftToRight ? 0 : buttonWidth;
                            w -= buttonWidth;
                            moreTabsButtonVisible = true;
                        }

                        if (useScrollButtons) {
                            if (!hideDisabledScrollButtons || forwardButton.isEnabled()) {
                                buttonWidth = forwardButton.getPreferredSize().width;
                                forwardButton.setBounds(leftToRight ? x + w - buttonWidth : x, ty, buttonWidth, th);
                                x += leftToRight ? 0 : buttonWidth;
                                w -= buttonWidth;
                                forwardButtonVisible = true;
                            }

                            if (!hideDisabledScrollButtons || backwardButton.isEnabled()) {
                                buttonWidth = backwardButton.getPreferredSize().width;
                                if (trailingScrollButtons) {
                                    backwardButton.setBounds(leftToRight ? x + w - buttonWidth : x, ty, buttonWidth, th);
                                    x += leftToRight ? 0 : buttonWidth;
                                } else {
                                    backwardButton.setBounds(leftToRight ? x : x + w - buttonWidth, ty, buttonWidth, th);
                                    x += leftToRight ? buttonWidth : 0;
                                }

                                w -= buttonWidth;
                                backwardButtonVisible = true;
                            }
                        }
                    }

                    this.this$0.tabViewport.setBounds(x, ty, w, th);
                    if (!leftToRight) {
                        this.this$0.tabViewport.doLayout();
                        FlatTabbedPaneUI.access$7600(this.this$0, this.this$0.tabViewport.getView().getWidth() - (FlatTabbedPaneUI.access$10800(this.this$0)[0].x + FlatTabbedPaneUI.access$10900(this.this$0)[0].width), 0);
                    }
                }
            }

            this.this$0.tabViewport.setVisible(FlatTabbedPaneUI.access$11600(this.this$0).length > 0);
            FlatTabbedPaneUI.access$5100(this.this$0).setVisible(moreTabsButtonVisible);
            backwardButton.setVisible(backwardButtonVisible);
            forwardButton.setVisible(forwardButtonVisible);
            FlatTabbedPaneUI.access$3002(this.this$0, backwardButton.getPreferredSize());
        }
    }
}
