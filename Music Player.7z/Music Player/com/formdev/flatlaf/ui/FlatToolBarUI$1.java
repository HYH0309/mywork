//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.ContainerEvent;
import javax.swing.plaf.basic.BasicToolBarUI;

class FlatToolBarUI$1 extends BasicToolBarUI.ToolBarContListener {
    FlatToolBarUI$1(FlatToolBarUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void componentAdded(ContainerEvent e) {
        super.componentAdded(e);
        if (!this.this$0.focusableButtons) {
            FlatToolBarUI.access$000(this.this$0, e.getChild(), false);
        }

    }

    public void componentRemoved(ContainerEvent e) {
        super.componentRemoved(e);
        if (!this.this$0.focusableButtons) {
            FlatToolBarUI.access$000(this.this$0, e.getChild(), true);
        }

    }
}
