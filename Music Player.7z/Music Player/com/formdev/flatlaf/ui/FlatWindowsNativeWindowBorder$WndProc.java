//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Color;
import java.awt.GraphicsConfiguration;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;
import java.awt.geom.AffineTransform;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JFrame;

class FlatWindowsNativeWindowBorder$WndProc implements PropertyChangeListener {
    private static final int HTCLIENT = 1;
    private static final int HTCAPTION = 2;
    private static final int HTSYSMENU = 3;
    private static final int HTMINBUTTON = 8;
    private static final int HTMAXBUTTON = 9;
    private static final int HTTOP = 12;
    private static final int HTCLOSE = 20;
    private Window window;
    private final long hwnd;
    private int titleBarHeight;
    private Rectangle[] hitTestSpots;
    private Rectangle appIconBounds;
    private Rectangle minimizeButtonBounds;
    private Rectangle maximizeButtonBounds;
    private Rectangle closeButtonBounds;

    FlatWindowsNativeWindowBorder$WndProc(FlatWindowsNativeWindowBorder var1, Window window) {
        this.this$0 = var1;
        this.window = window;
        this.hwnd = this.installImpl(window);
        if (this.hwnd != 0L) {
            this.updateFrame(this.hwnd, window instanceof JFrame ? ((JFrame)window).getExtendedState() : 0);
            this.updateWindowBackground();
            window.addPropertyChangeListener("background", this);
        }
    }

    void uninstall() {
        this.window.removePropertyChangeListener("background", this);
        this.uninstallImpl(this.hwnd);
        this.window = null;
    }

    public void propertyChange(PropertyChangeEvent e) {
        this.updateWindowBackground();
    }

    private void updateWindowBackground() {
        Color bg = this.window.getBackground();
        if (bg != null) {
            this.setWindowBackground(this.hwnd, bg.getRed(), bg.getGreen(), bg.getBlue());
        }

    }

    private native long installImpl(Window var1);

    private native void uninstallImpl(long var1);

    private native void updateFrame(long var1, int var3);

    private native void setWindowBackground(long var1, int var3, int var4, int var5);

    private native void showWindow(long var1, int var3);

    private int onNcHitTest(int x, int y, boolean isOnResizeBorder) {
        Point pt = this.scaleDown(x, y);
        int sx = pt.x;
        int sy = pt.y;
        if (this.contains(this.appIconBounds, sx, sy)) {
            return 3;
        } else if (this.contains(this.minimizeButtonBounds, sx, sy)) {
            return 8;
        } else if (this.contains(this.maximizeButtonBounds, sx, sy)) {
            return 9;
        } else if (this.contains(this.closeButtonBounds, sx, sy)) {
            return 20;
        } else {
            boolean isOnTitleBar = sy < this.titleBarHeight;
            if (isOnTitleBar) {
                Rectangle[] hitTestSpots2 = this.hitTestSpots;
                Rectangle[] var9 = hitTestSpots2;
                int var10 = hitTestSpots2.length;

                for(int var11 = 0; var11 < var10; ++var11) {
                    Rectangle spot = var9[var11];
                    if (spot.contains(sx, sy)) {
                        return 1;
                    }
                }

                return isOnResizeBorder ? 12 : 2;
            } else {
                return isOnResizeBorder ? 12 : 1;
            }
        }
    }

    private boolean contains(Rectangle rect, int x, int y) {
        return rect != null && rect.contains(x, y);
    }

    private Point scaleDown(int x, int y) {
        GraphicsConfiguration gc = this.window.getGraphicsConfiguration();
        if (gc == null) {
            return new Point(x, y);
        } else {
            AffineTransform t = gc.getDefaultTransform();
            return new Point(this.clipRound((double)x / t.getScaleX()), this.clipRound((double)y / t.getScaleY()));
        }
    }

    private int clipRound(double value) {
        value -= 0.5;
        if (value < -2.147483648E9) {
            return Integer.MIN_VALUE;
        } else {
            return value > 2.147483647E9 ? Integer.MAX_VALUE : (int)Math.ceil(value);
        }
    }

    private boolean isFullscreen() {
        GraphicsConfiguration gc = this.window.getGraphicsConfiguration();
        if (gc == null) {
            return false;
        } else {
            return gc.getDevice().getFullScreenWindow() == this.window;
        }
    }

    private void fireStateChangedLaterOnce() {
        this.this$0.fireStateChangedLaterOnce();
    }
}
