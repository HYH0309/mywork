//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Dimension;
import javax.swing.JPanel;

class FlatTitlePane$4 extends JPanel {
    FlatTitlePane$4(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        if (this.this$0.buttonMaximizedHeight > 0 && this.this$0.isWindowMaximized() && !this.this$0.hasVisibleEmbeddedMenuBar(this.this$0.rootPane.getJMenuBar())) {
            size = new Dimension(size.width, Math.min(size.height, UIScale.scale(this.this$0.buttonMaximizedHeight)));
        }

        return size;
    }
}
