//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

public class FlatListCellBorder$Focused extends FlatListCellBorder {
    public FlatListCellBorder$Focused() {
    }
}
