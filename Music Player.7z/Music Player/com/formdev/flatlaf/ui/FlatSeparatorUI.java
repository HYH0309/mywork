//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatStylingSupport.Styleable;
import com.formdev.flatlaf.util.LoggingFacade;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.Map;
import javax.swing.JComponent;
import javax.swing.JSeparator;
import javax.swing.UIManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicSeparatorUI;

public class FlatSeparatorUI extends BasicSeparatorUI implements FlatStylingSupport.StyleableUI, PropertyChangeListener {
    @Styleable
    protected int height;
    @Styleable
    protected int stripeWidth;
    @Styleable
    protected int stripeIndent;
    private final boolean shared;
    private boolean defaults_initialized = false;
    private Map<String, Object> oldStyleValues;

    public static ComponentUI createUI(JComponent c) {
        return (ComponentUI)(FlatUIUtils.canUseSharedUI(c) ? FlatUIUtils.createSharedUI(FlatSeparatorUI.class, () -> {
            return new FlatSeparatorUI(true);
        }) : new FlatSeparatorUI(false));
    }

    protected FlatSeparatorUI(boolean shared) {
        this.shared = shared;
    }

    protected String getPropertyPrefix() {
        return "Separator";
    }

    public void installUI(JComponent c) {
        super.installUI(c);
        this.installStyle((JSeparator)c);
    }

    protected void installDefaults(JSeparator s) {
        super.installDefaults(s);
        if (!this.defaults_initialized) {
            String prefix = this.getPropertyPrefix();
            this.height = UIManager.getInt(prefix + ".height");
            this.stripeWidth = UIManager.getInt(prefix + ".stripeWidth");
            this.stripeIndent = UIManager.getInt(prefix + ".stripeIndent");
            this.defaults_initialized = true;
        }

    }

    protected void uninstallDefaults(JSeparator s) {
        super.uninstallDefaults(s);
        this.defaults_initialized = false;
        this.oldStyleValues = null;
    }

    protected void installListeners(JSeparator s) {
        super.installListeners(s);
        s.addPropertyChangeListener(this);
    }

    protected void uninstallListeners(JSeparator s) {
        super.uninstallListeners(s);
        s.removePropertyChangeListener(this);
    }

    public void propertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "FlatLaf.style":
            case "FlatLaf.styleClass":
                JSeparator s = (JSeparator)e.getSource();
                if (this.shared && FlatStylingSupport.hasStyleProperty(s)) {
                    s.updateUI();
                } else {
                    this.installStyle(s);
                }

                s.revalidate();
                s.repaint();
            default:
        }
    }

    protected void installStyle(JSeparator s) {
        try {
            this.applyStyle(s, FlatStylingSupport.getResolvedStyle(s, this.getStyleType()));
        } catch (RuntimeException var3) {
            RuntimeException ex = var3;
            LoggingFacade.INSTANCE.logSevere((String)null, ex);
        }

    }

    String getStyleType() {
        return "Separator";
    }

    protected void applyStyle(JSeparator s, Object style) {
        this.oldStyleValues = FlatStylingSupport.parseAndApply(this.oldStyleValues, style, (key, value) -> {
            return this.applyStyleProperty(s, key, value);
        });
    }

    protected Object applyStyleProperty(JSeparator s, String key, Object value) {
        return FlatStylingSupport.applyToAnnotatedObjectOrComponent(this, s, key, value);
    }

    public Map<String, Class<?>> getStyleableInfos(JComponent c) {
        return FlatStylingSupport.getAnnotatedStyleableInfos(this);
    }

    public Object getStyleableValue(JComponent c, String key) {
        return FlatStylingSupport.getAnnotatedStyleableValue(this, key);
    }

    public void paint(Graphics g, JComponent c) {
        Graphics2D g2 = (Graphics2D)g.create();

        try {
            FlatUIUtils.setRenderingHints(g2);
            g2.setColor(c.getForeground());
            float width = UIScale.scale((float)this.stripeWidth);
            float indent = UIScale.scale((float)this.stripeIndent);
            if (((JSeparator)c).getOrientation() == 1) {
                g2.fill(new Rectangle2D.Float(indent, 0.0F, width, (float)c.getHeight()));
            } else {
                g2.fill(new Rectangle2D.Float(0.0F, indent, (float)c.getWidth(), width));
            }
        } finally {
            g2.dispose();
        }

    }

    public Dimension getPreferredSize(JComponent c) {
        return ((JSeparator)c).getOrientation() == 1 ? new Dimension(UIScale.scale(this.height), 0) : new Dimension(0, UIScale.scale(this.height));
    }
}
