//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Insets;

class MigLayoutVisualPadding$FlatMigInsets extends Insets {
    MigLayoutVisualPadding$FlatMigInsets(int top, int left, int bottom, int right) {
        super(top, left, bottom, right);
    }
}
