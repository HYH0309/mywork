//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Rectangle;
import java.util.function.Supplier;
import javax.swing.DesktopManager;
import javax.swing.JInternalFrame;

public class FlatWindowResizer$InternalFrameResizer extends FlatWindowResizer {
    protected final Supplier<DesktopManager> desktopManager;

    public FlatWindowResizer$InternalFrameResizer(JInternalFrame frame, Supplier<DesktopManager> desktopManager) {
        super(frame);
        this.desktopManager = desktopManager;
        frame.addPropertyChangeListener("resizable", this);
    }

    public void uninstall() {
        this.getFrame().removePropertyChangeListener("resizable", this);
        super.uninstall();
    }

    private JInternalFrame getFrame() {
        return (JInternalFrame)this.resizeComp;
    }

    protected Insets getResizeInsets() {
        return this.getFrame().getInsets();
    }

    protected boolean isWindowResizable() {
        return this.getFrame().isResizable();
    }

    protected Rectangle getWindowBounds() {
        return this.getFrame().getBounds();
    }

    protected void setWindowBounds(Rectangle r) {
        ((DesktopManager)this.desktopManager.get()).resizeFrame(this.getFrame(), r.x, r.y, r.width, r.height);
    }

    protected boolean limitToParentBounds() {
        return true;
    }

    protected Rectangle getParentBounds() {
        return new Rectangle(this.getFrame().getParent().getSize());
    }

    protected boolean honorMinimumSizeOnResize() {
        return true;
    }

    protected boolean honorMaximumSizeOnResize() {
        return true;
    }

    protected Dimension getWindowMinimumSize() {
        return this.getFrame().getMinimumSize();
    }

    protected Dimension getWindowMaximumSize() {
        return this.getFrame().getMaximumSize();
    }

    protected void beginResizing(int direction) {
        ((DesktopManager)this.desktopManager.get()).beginResizingFrame(this.getFrame(), direction);
    }

    protected void endResizing() {
        ((DesktopManager)this.desktopManager.get()).endResizingFrame(this.getFrame());
    }
}
