//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.ui.FlatComboBoxUI.MacCheckedItemIcon;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.JComponent;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;

class FlatComboBoxUI$CellPaddingBorder extends AbstractBorder {
    static final String KEY_MAC_STYLE_HINT = "FlatLaf.internal.FlatComboBoxUI.macStyleHint";
    static final int MAC_STYLE_GAP = 4;
    private Insets padding;
    private JComponent rendererComponent;
    private Border rendererBorder;
    private int focusWidth;

    FlatComboBoxUI$CellPaddingBorder(Insets padding) {
        this.padding = padding;
    }

    synchronized void install(Component c, int focusWidth) {
        if (c instanceof JComponent) {
            this.focusWidth = focusWidth;
            JComponent jc = (JComponent)c;
            Border oldBorder = jc.getBorder();
            if (oldBorder != this) {
                if (oldBorder instanceof FlatComboBoxUI$CellPaddingBorder) {
                    ((FlatComboBoxUI$CellPaddingBorder)oldBorder).uninstall();
                }

                this.uninstall();
                this.rendererComponent = jc;
                this.rendererBorder = jc.getBorder();
                jc.setBorder(this);
            }
        }
    }

    synchronized void uninstall() {
        if (this.rendererComponent != null) {
            this.rendererComponent.putClientProperty("FlatLaf.internal.FlatComboBoxUI.macStyleHint", (Object)null);
            if (this.rendererComponent.getBorder() == this) {
                this.rendererComponent.setBorder(this.rendererBorder);
            }

            this.rendererComponent = null;
            this.rendererBorder = null;
        }
    }

    public synchronized Insets getBorderInsets(Component c, Insets insets) {
        Insets padding = UIScale.scale(this.padding);
        if (this.rendererBorder != null && !(this.rendererBorder instanceof FlatComboBoxUI$CellPaddingBorder)) {
            Insets insideInsets = this.rendererBorder.getBorderInsets(c);
            insets.top = Math.max(padding.top, insideInsets.top);
            insets.left = Math.max(padding.left, insideInsets.left);
            insets.bottom = Math.max(padding.bottom, insideInsets.bottom);
            insets.right = Math.max(padding.right, insideInsets.right);
        } else {
            insets.top = padding.top;
            insets.left = padding.left;
            insets.bottom = padding.bottom;
            insets.right = padding.right;
        }

        insets.left += this.focusWidth;
        insets.right += this.focusWidth;
        if (c instanceof JComponent) {
            Boolean macStyleHint = FlatClientProperties.clientPropertyBooleanStrict((JComponent)c, "FlatLaf.internal.FlatComboBoxUI.macStyleHint", (Boolean)null);
            if (macStyleHint != null) {
                int indent = MacCheckedItemIcon.INSTANCE.getIconWidth() + UIScale.scale(4);
                if (c.getComponentOrientation().isLeftToRight()) {
                    insets.left += indent;
                } else {
                    insets.right += indent;
                }
            }
        }

        return insets;
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        if (this.rendererBorder != null) {
            this.rendererBorder.paintBorder(c, g, x, y, width, height);
        }

        if (c instanceof JComponent) {
            Boolean macStyleHint = FlatClientProperties.clientPropertyBooleanStrict((JComponent)c, "FlatLaf.internal.FlatComboBoxUI.macStyleHint", (Boolean)null);
            if (macStyleHint == Boolean.TRUE) {
                int ix = c.getComponentOrientation().isLeftToRight() ? x + UIScale.scale(this.padding.left) : x + width - UIScale.scale(this.padding.right) - MacCheckedItemIcon.INSTANCE.getIconWidth();
                MacCheckedItemIcon.INSTANCE.paintIcon(c, g, ix, y + (height - MacCheckedItemIcon.INSTANCE.getIconHeight()) / 2);
            }
        }

    }
}
