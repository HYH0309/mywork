//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.JBRCustomDecorations.JBRWindowTopBorder;
import java.awt.Color;
import java.awt.Window;

class FlatNativeWindowBorder$WindowTopBorder extends JBRCustomDecorations.JBRWindowTopBorder {
    private static FlatNativeWindowBorder$WindowTopBorder instance;

    FlatNativeWindowBorder$WindowTopBorder() {
    }

    static JBRCustomDecorations.JBRWindowTopBorder getInstance() {
        if (FlatNativeWindowBorder.access$000()) {
            return JBRWindowTopBorder.getInstance();
        } else {
            if (instance == null) {
                instance = new FlatNativeWindowBorder$WindowTopBorder();
            }

            return instance;
        }
    }

    void installListeners() {
        FlatNativeWindowBorder.access$100().addChangeListener((e) -> {
            this.update();
            Window[] var2 = Window.getWindows();
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                Window window = var2[var4];
                if (window.isDisplayable()) {
                    window.repaint(0, 0, window.getWidth(), 1);
                }
            }

        });
    }

    boolean isColorizationColorAffectsBorders() {
        return FlatNativeWindowBorder.access$100().isColorizationColorAffectsBorders();
    }

    Color getColorizationColor() {
        return FlatNativeWindowBorder.access$100().getColorizationColor();
    }

    int getColorizationColorBalance() {
        return FlatNativeWindowBorder.access$100().getColorizationColorBalance();
    }
}
