//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.TreePath;

class FlatTreeUI$1 extends BasicTreeUI.MouseHandler {
    FlatTreeUI$1(FlatTreeUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void mousePressed(MouseEvent e) {
        super.mousePressed(this.handleWideMouseEvent(e));
    }

    public void mouseReleased(MouseEvent e) {
        super.mouseReleased(this.handleWideMouseEvent(e));
    }

    public void mouseDragged(MouseEvent e) {
        super.mouseDragged(this.handleWideMouseEvent(e));
    }

    private MouseEvent handleWideMouseEvent(MouseEvent e) {
        if (this.this$0.isWideSelection() && FlatTreeUI.access$000(this.this$0).isEnabled() && SwingUtilities.isLeftMouseButton(e) && !e.isConsumed()) {
            int x = e.getX();
            int y = e.getY();
            TreePath path = this.this$0.getClosestPathForLocation(FlatTreeUI.access$100(this.this$0), x, y);
            if (path != null && !FlatTreeUI.access$200(this.this$0, path, x, y)) {
                Rectangle bounds = this.this$0.getPathBounds(FlatTreeUI.access$300(this.this$0), path);
                if (bounds != null && y >= bounds.y && y < bounds.y + bounds.height) {
                    int newX = Math.max(bounds.x, Math.min(x, bounds.x + bounds.width - 1));
                    return newX == x ? e : new MouseEvent(e.getComponent(), e.getID(), e.getWhen(), e.getModifiers() | e.getModifiersEx(), newX, e.getY(), e.getClickCount(), e.isPopupTrigger(), e.getButton());
                } else {
                    return e;
                }
            } else {
                return e;
            }
        } else {
            return e;
        }
    }
}
