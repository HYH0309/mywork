//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Cursor;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import javax.swing.JTable;
import javax.swing.plaf.basic.BasicTableHeaderUI;

public class FlatTableHeaderUI$FlatMouseInputHandler extends BasicTableHeaderUI.MouseInputHandler {
    Cursor oldCursor;

    protected FlatTableHeaderUI$FlatMouseInputHandler(FlatTableHeaderUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void mouseMoved(MouseEvent e) {
        if (this.oldCursor != null) {
            FlatTableHeaderUI.access$500(this.this$0).setCursor(this.oldCursor);
            this.oldCursor = null;
        }

        super.mouseMoved(e);
        JTable table;
        int column;
        if (FlatTableHeaderUI.access$600(this.this$0).isEnabled() && (table = FlatTableHeaderUI.access$700(this.this$0).getTable()) != null && table.getAutoResizeMode() != 0 && FlatTableHeaderUI.access$800(this.this$0).getCursor() == Cursor.getPredefinedCursor(11) && (column = FlatTableHeaderUI.access$900(this.this$0).columnAtPoint(e.getPoint())) >= 0 && column == FlatTableHeaderUI.access$1000(this.this$0).getColumnModel().getColumnCount() - 1) {
            Rectangle r = FlatTableHeaderUI.access$1100(this.this$0).getHeaderRect(column);
            r.grow(-3, 0);
            if (!r.contains(e.getX(), e.getY())) {
                boolean isResizeLastColumn = e.getX() >= r.x + r.width / 2;
                if (!FlatTableHeaderUI.access$1200(this.this$0).getComponentOrientation().isLeftToRight()) {
                    isResizeLastColumn = !isResizeLastColumn;
                }

                if (isResizeLastColumn) {
                    this.oldCursor = FlatTableHeaderUI.access$1300(this.this$0).getCursor();
                    FlatTableHeaderUI.access$1400(this.this$0).setCursor(Cursor.getDefaultCursor());
                }
            }
        }

    }
}
