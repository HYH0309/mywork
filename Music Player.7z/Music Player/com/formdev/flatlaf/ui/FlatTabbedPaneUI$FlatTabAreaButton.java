//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;

public class FlatTabbedPaneUI$FlatTabAreaButton extends FlatArrowButton {
    public FlatTabbedPaneUI$FlatTabAreaButton(FlatTabbedPaneUI this$0, int direction) {
        super(direction, this$0.arrowType, this$0.foreground, this$0.disabledForeground, (Color)null, this$0.buttonHoverBackground, (Color)null, this$0.buttonPressedBackground);
        this.this$0 = this$0;
        this.setArrowWidth(11);
    }

    protected void updateStyle() {
        this.updateStyle(this.this$0.arrowType, this.this$0.foreground, this.this$0.disabledForeground, (Color)null, this.this$0.buttonHoverBackground, (Color)null, this.this$0.buttonPressedBackground);
    }

    protected Color deriveBackground(Color background) {
        return FlatUIUtils.deriveColor(background, FlatTabbedPaneUI.access$400(this.this$0).getBackground());
    }

    public void paint(Graphics g) {
        if (this.this$0.tabsOpaque || FlatTabbedPaneUI.access$500(this.this$0).isOpaque()) {
            g.setColor(FlatTabbedPaneUI.access$600(this.this$0).getBackground());
            g.fillRect(0, 0, this.getWidth(), this.getHeight());
        }

        super.paint(g);
    }

    protected void paintBackground(Graphics2D g) {
        Insets insets = new Insets(0, 0, 0, 0);
        FlatTabbedPaneUI.access$800(this.this$0.buttonInsets, insets, FlatTabbedPaneUI.access$700(this.this$0).getTabPlacement());
        int top = UIScale.scale2(insets.top);
        int left = UIScale.scale2(insets.left);
        int bottom = UIScale.scale2(insets.bottom);
        int right = UIScale.scale2(insets.right);
        FlatUIUtils.paintComponentBackground(g, left, top, this.getWidth() - left - right, this.getHeight() - top - bottom, 0.0F, UIScale.scale((float)this.this$0.buttonArc));
    }
}
