//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Container;
import java.beans.PropertyChangeEvent;
import javax.swing.AbstractButton;
import javax.swing.JToolBar;
import javax.swing.event.ChangeEvent;
import javax.swing.plaf.ToolBarUI;
import javax.swing.plaf.basic.BasicButtonListener;

public class FlatButtonUI$FlatButtonListener extends BasicButtonListener {
    private final AbstractButton b;

    protected FlatButtonUI$FlatButtonListener(FlatButtonUI this$0, AbstractButton b) {
        super(b);
        this.this$0 = this$0;
        this.b = b;
    }

    public void propertyChange(PropertyChangeEvent e) {
        super.propertyChange(e);
        this.this$0.propertyChange(this.b, e);
    }

    public void stateChanged(ChangeEvent e) {
        super.stateChanged(e);
        AbstractButton b = (AbstractButton)e.getSource();
        Container parent = b.getParent();
        if (parent instanceof JToolBar) {
            JToolBar toolBar = (JToolBar)parent;
            ToolBarUI ui = toolBar.getUI();
            if (ui instanceof FlatToolBarUI) {
                ((FlatToolBarUI)ui).repaintButtonGroup(b);
            }
        }

    }
}
