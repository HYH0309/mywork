//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.util.SystemInfo;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;

class FlatMenuBarUI$TakeFocus extends AbstractAction {
    private FlatMenuBarUI$TakeFocus() {
    }

    public void actionPerformed(ActionEvent e) {
        JMenuBar menuBar = (JMenuBar)e.getSource();
        JMenu menu = menuBar.getMenu(0);
        if (menu != null) {
            MenuSelectionManager.defaultManager().setSelectedPath(SystemInfo.isWindows ? new MenuElement[]{menuBar, menu} : new MenuElement[]{menuBar, menu, menu.getPopupMenu()});
            FlatLaf.showMnemonics(menuBar);
        }

    }
}
