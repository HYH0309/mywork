//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;

class FlatArrowButton$1 extends MouseAdapter {
    FlatArrowButton$1(FlatArrowButton this$0) {
        this.this$0 = this$0;
    }

    public void mouseEntered(MouseEvent e) {
        FlatArrowButton.access$002(this.this$0, true);
        this.this$0.repaint();
    }

    public void mouseExited(MouseEvent e) {
        FlatArrowButton.access$002(this.this$0, false);
        this.this$0.repaint();
    }

    public void mousePressed(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e)) {
            FlatArrowButton.access$102(this.this$0, true);
            this.this$0.repaint();
        }

    }

    public void mouseReleased(MouseEvent e) {
        if (SwingUtilities.isLeftMouseButton(e)) {
            FlatArrowButton.access$102(this.this$0, false);
            this.this$0.repaint();
        }

    }
}
