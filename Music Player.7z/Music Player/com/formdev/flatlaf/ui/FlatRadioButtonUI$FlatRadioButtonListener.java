//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.beans.PropertyChangeEvent;
import javax.swing.AbstractButton;
import javax.swing.plaf.basic.BasicButtonListener;

public class FlatRadioButtonUI$FlatRadioButtonListener extends BasicButtonListener {
    private final AbstractButton b;

    protected FlatRadioButtonUI$FlatRadioButtonListener(FlatRadioButtonUI this$0, AbstractButton b) {
        super(b);
        this.this$0 = this$0;
        this.b = b;
    }

    public void propertyChange(PropertyChangeEvent e) {
        super.propertyChange(e);
        this.this$0.propertyChange(this.b, e);
    }
}
