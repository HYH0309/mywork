//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.Rectangle;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.SwingUtilities;

public class FlatTitlePane$FlatTitleLabelUI extends FlatLabelUI {
    protected FlatTitlePane$FlatTitleLabelUI(FlatTitlePane this$0) {
        super(false);
        this.this$0 = this$0;
    }

    protected void installDefaults(JLabel c) {
        super.installDefaults(c);
        if (this.this$0.titleFont != null) {
            c.setFont(this.this$0.titleFont);
        }

    }

    protected String layoutCL(JLabel label, FontMetrics fontMetrics, String text, Icon icon, Rectangle viewR, Rectangle iconR, Rectangle textR) {
        JMenuBar menuBar = this.this$0.rootPane.getJMenuBar();
        boolean hasEmbeddedMenuBar = this.this$0.hasVisibleEmbeddedMenuBar(menuBar);
        boolean hasEmbeddedLeadingMenus = hasEmbeddedMenuBar && this.hasLeadingMenus(menuBar);
        boolean leftToRight = this.this$0.getComponentOrientation().isLeftToRight();
        int iconTextGap;
        if (hasEmbeddedMenuBar) {
            iconTextGap = UIScale.scale(this.this$0.menuBarTitleMinimumGap);
            if (hasEmbeddedLeadingMenus) {
                if (leftToRight) {
                    viewR.x += iconTextGap;
                }

                viewR.width -= iconTextGap;
            }

            Component horizontalGlue = this.this$0.findHorizontalGlue(menuBar);
            if (horizontalGlue != null && menuBar.getComponent(menuBar.getComponentCount() - 1) != horizontalGlue) {
                if (!leftToRight) {
                    viewR.x += iconTextGap;
                }

                viewR.width -= iconTextGap;
            }
        }

        iconTextGap = 0;
        int iconWidthAndGap = 0;
        if (icon != null) {
            Insets iconInsets = this.this$0.iconLabel.getInsets();
            iconTextGap = leftToRight ? iconInsets.right : iconInsets.left;
            iconWidthAndGap = icon.getIconWidth() + iconTextGap;
        }

        String clippedText = SwingUtilities.layoutCompoundLabel(label, fontMetrics, text, icon, label.getVerticalAlignment(), label.getHorizontalAlignment(), label.getVerticalTextPosition(), label.getHorizontalTextPosition(), viewR, iconR, textR, iconTextGap);
        if (!clippedText.equals(text)) {
            textR.x = leftToRight ? viewR.x + iconWidthAndGap : viewR.x + viewR.width - iconWidthAndGap - textR.width;
        } else {
            int leadingGap = hasEmbeddedLeadingMenus ? UIScale.scale(this.this$0.menuBarTitleGap - this.this$0.menuBarTitleMinimumGap) : 0;
            boolean center = hasEmbeddedLeadingMenus ? this.this$0.centerTitleIfMenuBarEmbedded : this.this$0.centerTitle;
            if (center) {
                Container parent = label.getParent();
                int centeredTextX = parent != null ? (parent.getWidth() - textR.width - iconWidthAndGap) / 2 + iconWidthAndGap - label.getX() : -1;
                textR.x = centeredTextX >= viewR.x + leadingGap && centeredTextX + textR.width <= viewR.x + viewR.width - leadingGap ? centeredTextX : viewR.x + (viewR.width - textR.width - iconWidthAndGap) / 2 + iconWidthAndGap;
            } else {
                textR.x = leftToRight ? Math.min(viewR.x + leadingGap + iconWidthAndGap, viewR.x + viewR.width - textR.width) : Math.max(viewR.x + viewR.width - leadingGap - iconWidthAndGap - textR.width, viewR.x);
            }
        }

        if (icon != null) {
            iconR.x = leftToRight ? textR.x - iconWidthAndGap : textR.x + textR.width + iconTextGap;
        }

        return clippedText;
    }

    private boolean hasLeadingMenus(JMenuBar menuBar) {
        if (menuBar.getComponentCount() != 0 && menuBar.getWidth() != 0) {
            Component horizontalGlue = this.this$0.findHorizontalGlue(menuBar);
            if (horizontalGlue != null) {
                boolean leftToRight = this.this$0.getComponentOrientation().isLeftToRight();
                if (leftToRight && horizontalGlue.getX() == 0 || !leftToRight && horizontalGlue.getX() + horizontalGlue.getWidth() == menuBar.getWidth()) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }
}
