//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Insets;
import java.awt.Rectangle;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

public class FlatTabbedPaneUI$FlatTabbedPaneLayout extends BasicTabbedPaneUI.TabbedPaneLayout {
    protected FlatTabbedPaneUI$FlatTabbedPaneLayout(FlatTabbedPaneUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    protected Dimension calculateSize(boolean minimum) {
        return this.isContentEmpty() ? this.calculateTabAreaSize() : super.calculateSize(minimum);
    }

    protected boolean isContentEmpty() {
        int tabCount = FlatTabbedPaneUI.access$6600(this.this$0).getTabCount();
        if (tabCount == 0) {
            return false;
        } else {
            for(int i = 0; i < tabCount; ++i) {
                Component c = FlatTabbedPaneUI.access$6700(this.this$0).getComponentAt(i);
                if (c != null) {
                    Dimension cs = c.getPreferredSize();
                    if (cs.width != 0 || cs.height != 0) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    protected Dimension calculateTabAreaSize() {
        boolean horizontal = this.this$0.isHorizontalTabPlacement();
        int tabPlacement = FlatTabbedPaneUI.access$6800(this.this$0).getTabPlacement();
        FontMetrics metrics = FlatTabbedPaneUI.access$6900(this.this$0);
        int fontHeight = metrics.getHeight();
        int width = 0;
        int height = 0;
        int tabCount = FlatTabbedPaneUI.access$7000(this.this$0).getTabCount();

        for(int i = 0; i < tabCount; ++i) {
            if (horizontal) {
                width += this.this$0.calculateTabWidth(tabPlacement, i, metrics);
                height = Math.max(height, this.this$0.calculateTabHeight(tabPlacement, i, fontHeight));
            } else {
                width = Math.max(width, this.this$0.calculateTabWidth(tabPlacement, i, metrics));
                height += this.this$0.calculateTabHeight(tabPlacement, i, fontHeight);
            }
        }

        if (horizontal) {
            height += UIScale.scale(this.this$0.contentSeparatorHeight);
        } else {
            width += UIScale.scale(this.this$0.contentSeparatorHeight);
        }

        Insets insets = FlatTabbedPaneUI.access$7100(this.this$0).getInsets();
        Insets tabAreaInsets = this.this$0.getTabAreaInsets(tabPlacement);
        return new Dimension(width + insets.left + insets.right + tabAreaInsets.left + tabAreaInsets.right, height + insets.bottom + insets.top + tabAreaInsets.top + tabAreaInsets.bottom);
    }

    public void layoutContainer(Container parent) {
        super.layoutContainer(parent);
        Rectangle bounds = FlatTabbedPaneUI.access$7200(this.this$0).getBounds();
        Insets insets = FlatTabbedPaneUI.access$7300(this.this$0).getInsets();
        int tabPlacement = FlatTabbedPaneUI.access$7400(this.this$0).getTabPlacement();
        int tabAreaAlignment = this.this$0.getTabAreaAlignment();
        Insets tabAreaInsets = this.this$0.getRealTabAreaInsets(tabPlacement);
        boolean leftToRight = FlatTabbedPaneUI.access$1200(this.this$0);
        int tabAreaHeight;
        int tx;
        int ty;
        int tw;
        int th;
        int leadingWidth;
        int trailingWidth;
        int availWidth;
        int leftWidth;
        int rightWidth;
        if (tabPlacement != 1 && tabPlacement != 3) {
            tabAreaHeight = FlatTabbedPaneUI.access$9000(this.this$0) > 0 ? FlatTabbedPaneUI.access$9100(this.this$0) : Math.max(FlatTabbedPaneUI.access$8200(this.this$0), FlatTabbedPaneUI.access$7500(this.this$0));
            tx = tabPlacement == 2 ? insets.left + tabAreaInsets.left : bounds.width - insets.right - tabAreaInsets.right - tabAreaHeight;
            ty = insets.top;
            tw = tabAreaHeight;
            th = bounds.height - insets.top - insets.bottom;
            leadingWidth = FlatTabbedPaneUI.access$7900(this.this$0);
            trailingWidth = FlatTabbedPaneUI.access$8000(this.this$0);
            if (FlatTabbedPaneUI.access$9200(this.this$0) == 1 && FlatTabbedPaneUI.access$9300(this.this$0).length > 0) {
                availWidth = th - leadingWidth - trailingWidth - tabAreaInsets.top - tabAreaInsets.bottom;
                leftWidth = FlatTabbedPaneUI.access$9400(this.this$0);
                rightWidth = availWidth - leftWidth;
                switch (tabAreaAlignment) {
                    case 0:
                        FlatTabbedPaneUI.access$7600(this.this$0, 0, rightWidth / 2);
                        leadingWidth += rightWidth / 2;
                        trailingWidth += rightWidth - rightWidth / 2;
                        break;
                    case 10:
                        trailingWidth += rightWidth;
                        break;
                    case 11:
                        FlatTabbedPaneUI.access$7600(this.this$0, 0, rightWidth);
                        leadingWidth += rightWidth;
                        break;
                    case 100:
                        FlatTabbedPaneUI.access$9500(this.this$0, rightWidth);
                }
            } else if (FlatTabbedPaneUI.access$9600(this.this$0).length == 0) {
                trailingWidth = th - leadingWidth;
            }

            if (FlatTabbedPaneUI.access$8800(this.this$0) != null) {
                FlatTabbedPaneUI.access$8800(this.this$0).setBounds(tx, ty, tw, leadingWidth);
            }

            if (FlatTabbedPaneUI.access$8900(this.this$0) != null) {
                FlatTabbedPaneUI.access$8900(this.this$0).setBounds(tx, ty + th - trailingWidth, tw, trailingWidth);
            }
        } else {
            if (!leftToRight) {
                FlatTabbedPaneUI.access$7600(this.this$0, insets.left + tabAreaInsets.right + FlatTabbedPaneUI.access$7500(this.this$0), 0);
            }

            tabAreaHeight = FlatTabbedPaneUI.access$7700(this.this$0) > 0 ? FlatTabbedPaneUI.access$7800(this.this$0) : Math.max(Math.max(FlatTabbedPaneUI.access$7900(this.this$0), FlatTabbedPaneUI.access$8000(this.this$0)), UIScale.scale(FlatClientProperties.clientPropertyInt(FlatTabbedPaneUI.access$8100(this.this$0), "JTabbedPane.tabHeight", this.this$0.tabHeight)));
            tx = insets.left;
            ty = tabPlacement == 1 ? insets.top + tabAreaInsets.top : bounds.height - insets.bottom - tabAreaInsets.bottom - tabAreaHeight;
            tw = bounds.width - insets.left - insets.right;
            th = tabAreaHeight;
            leadingWidth = FlatTabbedPaneUI.access$8200(this.this$0);
            trailingWidth = FlatTabbedPaneUI.access$7500(this.this$0);
            if (FlatTabbedPaneUI.access$8300(this.this$0) == 1 && FlatTabbedPaneUI.access$8400(this.this$0).length > 0) {
                availWidth = tw - leadingWidth - trailingWidth - tabAreaInsets.left - tabAreaInsets.right;
                leftWidth = FlatTabbedPaneUI.access$8500(this.this$0, leftToRight);
                rightWidth = availWidth - leftWidth;
                switch (tabAreaAlignment) {
                    case 0:
                        FlatTabbedPaneUI.access$7600(this.this$0, (leftToRight ? rightWidth : -rightWidth) / 2, 0);
                        leadingWidth += rightWidth / 2;
                        trailingWidth += rightWidth - rightWidth / 2;
                        break;
                    case 10:
                        trailingWidth += rightWidth;
                        break;
                    case 11:
                        FlatTabbedPaneUI.access$7600(this.this$0, leftToRight ? rightWidth : -rightWidth, 0);
                        leadingWidth += rightWidth;
                        break;
                    case 100:
                        FlatTabbedPaneUI.access$8600(this.this$0, rightWidth, leftToRight);
                }
            } else if (FlatTabbedPaneUI.access$8700(this.this$0).length == 0) {
                trailingWidth = tw - leadingWidth;
            }

            Container leftComponent = leftToRight ? FlatTabbedPaneUI.access$8800(this.this$0) : FlatTabbedPaneUI.access$8900(this.this$0);
            if (leftComponent != null) {
                leftWidth = leftToRight ? leadingWidth : trailingWidth;
                leftComponent.setBounds(tx, ty, leftWidth, th);
            }

            Container rightComponent = leftToRight ? FlatTabbedPaneUI.access$8900(this.this$0) : FlatTabbedPaneUI.access$8800(this.this$0);
            if (rightComponent != null) {
                rightWidth = leftToRight ? trailingWidth : leadingWidth;
                rightComponent.setBounds(tx + tw - rightWidth, ty, rightWidth, th);
            }
        }

    }
}
