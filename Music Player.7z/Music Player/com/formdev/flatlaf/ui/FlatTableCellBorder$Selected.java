//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

public class FlatTableCellBorder$Selected extends FlatTableCellBorder {
    public int maxCheckCellsEditable = 50;

    public FlatTableCellBorder$Selected() {
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Boolean b = (Boolean)getStyleFromTableUI(c, (ui) -> {
            return ui.showCellFocusIndicator;
        });
        boolean showCellFocusIndicator = b != null ? b : this.showCellFocusIndicator;
        if (!showCellFocusIndicator) {
            JTable table = (JTable)SwingUtilities.getAncestorOfClass(JTable.class, c);
            if (table != null && !this.shouldShowCellFocusIndicator(table)) {
                return;
            }
        }

        super.paintBorder(c, g, x, y, width, height);
    }

    protected boolean shouldShowCellFocusIndicator(JTable table) {
        boolean rowSelectionAllowed = table.getRowSelectionAllowed();
        boolean columnSelectionAllowed = table.getColumnSelectionAllowed();
        if (rowSelectionAllowed && columnSelectionAllowed) {
            return false;
        } else {
            int rowCount;
            int selectedColumn;
            int row;
            if (rowSelectionAllowed) {
                if (table.getSelectedRowCount() != 1) {
                    return false;
                }

                rowCount = table.getColumnCount();
                if (rowCount > this.maxCheckCellsEditable) {
                    return true;
                }

                selectedColumn = table.getSelectedRow();

                for(row = 0; row < rowCount; ++row) {
                    if (table.isCellEditable(selectedColumn, row)) {
                        return true;
                    }
                }
            } else if (columnSelectionAllowed) {
                if (table.getSelectedColumnCount() != 1) {
                    return false;
                }

                rowCount = table.getRowCount();
                if (rowCount > this.maxCheckCellsEditable) {
                    return true;
                }

                selectedColumn = table.getSelectedColumn();

                for(row = 0; row < rowCount; ++row) {
                    if (table.isCellEditable(row, selectedColumn)) {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}
