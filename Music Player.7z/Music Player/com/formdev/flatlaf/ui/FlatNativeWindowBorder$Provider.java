//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Window;
import java.util.List;
import javax.swing.event.ChangeListener;

public interface FlatNativeWindowBorder$Provider {
    int SW_MAXIMIZE = 3;
    int SW_MINIMIZE = 6;
    int SW_RESTORE = 9;

    boolean hasCustomDecoration(Window var1);

    void setHasCustomDecoration(Window var1, boolean var2);

    void updateTitleBarInfo(Window var1, int var2, List<Rectangle> var3, Rectangle var4, Rectangle var5, Rectangle var6, Rectangle var7);

    boolean showWindow(Window var1, int var2);

    boolean isColorizationColorAffectsBorders();

    Color getColorizationColor();

    int getColorizationColorBalance();

    void addChangeListener(ChangeListener var1);

    void removeChangeListener(ChangeListener var1);
}
