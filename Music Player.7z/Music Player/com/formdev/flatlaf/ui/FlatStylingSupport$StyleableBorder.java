//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.util.Map;

public interface FlatStylingSupport$StyleableBorder {
    Object applyStyleProperty(String var1, Object var2);

    Map<String, Class<?>> getStyleableInfos() throws IllegalArgumentException;

    Object getStyleableValue(String var1) throws IllegalArgumentException;
}
