//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import javax.swing.JLabel;

class FlatTitlePane$1 extends JLabel {
    FlatTitlePane$1(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public void updateUI() {
        this.setUI(new FlatTitlePane.FlatTitleLabelUI(this.this$0));
    }
}
