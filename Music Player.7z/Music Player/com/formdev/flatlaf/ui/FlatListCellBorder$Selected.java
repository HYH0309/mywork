//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.Component;
import java.awt.Graphics;
import javax.swing.JList;
import javax.swing.SwingUtilities;

public class FlatListCellBorder$Selected extends FlatListCellBorder {
    public FlatListCellBorder$Selected() {
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Boolean b = (Boolean)getStyleFromListUI(c, (ui) -> {
            return ui.showCellFocusIndicator;
        });
        boolean showCellFocusIndicator = b != null ? b : this.showCellFocusIndicator;
        if (showCellFocusIndicator) {
            JList<?> list = (JList)SwingUtilities.getAncestorOfClass(JList.class, c);
            if (list == null || list.getMinSelectionIndex() != list.getMaxSelectionIndex()) {
                super.paintBorder(c, g, x, y, width, height);
            }
        }
    }
}
