//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.beans.PropertyChangeEvent;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane;

public class FlatInternalFrameTitlePane$FlatPropertyChangeHandler extends BasicInternalFrameTitlePane.PropertyChangeHandler {
    protected FlatInternalFrameTitlePane$FlatPropertyChangeHandler(FlatInternalFrameTitlePane this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void propertyChange(PropertyChangeEvent e) {
        switch (e.getPropertyName()) {
            case "title":
                FlatInternalFrameTitlePane.access$700(this.this$0).setText(FlatInternalFrameTitlePane.access$600(this.this$0).getTitle());
                break;
            case "frameIcon":
                this.this$0.updateFrameIcon();
                break;
            case "selected":
                this.this$0.updateColors();
                break;
            case "iconable":
            case "maximizable":
            case "closable":
                this.this$0.updateButtonsVisibility();
                FlatInternalFrameTitlePane.access$800(this.this$0);
                this.this$0.revalidate();
                this.this$0.repaint();
                return;
            case "componentOrientation":
                this.this$0.applyComponentOrientation(FlatInternalFrameTitlePane.access$900(this.this$0).getComponentOrientation());
                break;
            case "opaque":
                return;
        }

        super.propertyChange(e);
    }
}
