//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.ui.FlatNativeWindowBorder.WindowTopBorder;
import com.formdev.flatlaf.util.SystemInfo;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.JMenuBar;
import javax.swing.border.AbstractBorder;
import javax.swing.border.Border;

public class FlatTitlePane$FlatTitlePaneBorder extends AbstractBorder {
    protected FlatTitlePane$FlatTitlePaneBorder(FlatTitlePane this$0) {
        this.this$0 = this$0;
    }

    public Insets getBorderInsets(Component c, Insets insets) {
        super.getBorderInsets(c, insets);
        Border menuBarBorder = this.getMenuBarBorder();
        if (menuBarBorder != null) {
            Insets menuBarInsets = menuBarBorder.getBorderInsets(c);
            insets.bottom += menuBarInsets.bottom;
        } else if (this.this$0.borderColor != null && (this.this$0.rootPane.getJMenuBar() == null || !this.this$0.rootPane.getJMenuBar().isVisible())) {
            insets.bottom += UIScale.scale(1);
        }

        if (!SystemInfo.isWindows_11_orLater && this.this$0.hasNativeCustomDecoration() && !this.this$0.isWindowMaximized()) {
            insets = FlatUIUtils.addInsets(insets, WindowTopBorder.getInstance().getBorderInsets());
        }

        return insets;
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Border menuBarBorder = this.getMenuBarBorder();
        if (menuBarBorder != null) {
            menuBarBorder.paintBorder(this.this$0.rootPane.getJMenuBar(), g, x, y, width, height);
        } else if (this.this$0.borderColor != null && (this.this$0.rootPane.getJMenuBar() == null || !this.this$0.rootPane.getJMenuBar().isVisible())) {
            float lineHeight = UIScale.scale(1.0F);
            FlatUIUtils.paintFilledRectangle(g, this.this$0.borderColor, (float)x, (float)(y + height) - lineHeight, (float)width, lineHeight);
        }

        if (!SystemInfo.isWindows_11_orLater && this.this$0.hasNativeCustomDecoration() && !this.this$0.isWindowMaximized()) {
            WindowTopBorder.getInstance().paintBorder(c, g, x, y, width, height);
        }

    }

    protected Border getMenuBarBorder() {
        JMenuBar menuBar = this.this$0.rootPane.getJMenuBar();
        return this.this$0.hasVisibleEmbeddedMenuBar(menuBar) ? menuBar.getBorder() : null;
    }
}
