//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.awt.EventQueue;
import java.awt.event.FocusEvent;
import javax.swing.plaf.basic.BasicTableUI;

class FlatTableUI$1 extends BasicTableUI.FocusHandler {
    FlatTableUI$1(FlatTableUI this$0) {
        super(this$0);
        this.this$0 = this$0;
    }

    public void focusGained(FocusEvent e) {
        super.focusGained(e);
        FlatTableUI.access$000(this.this$0);
    }

    public void focusLost(FocusEvent e) {
        super.focusLost(e);
        EventQueue.invokeLater(() -> {
            FlatTableUI.access$000(this.this$0);
        });
    }
}
