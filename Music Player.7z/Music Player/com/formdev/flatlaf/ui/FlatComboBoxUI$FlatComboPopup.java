//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.ui.FlatComboBoxUI.MacCheckedItemIcon;
import com.formdev.flatlaf.util.SystemInfo;
import com.formdev.flatlaf.util.UIScale;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.beans.PropertyChangeListener;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JScrollBar;
import javax.swing.ListCellRenderer;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicComboPopup;

public class FlatComboBoxUI$FlatComboPopup extends BasicComboPopup {
    protected FlatComboBoxUI$FlatComboPopup(FlatComboBoxUI this$0, JComboBox combo) {
        super(combo);
        this.this$0 = this$0;
        ComponentOrientation o = this.comboBox.getComponentOrientation();
        this.list.setComponentOrientation(o);
        this.scroller.setComponentOrientation(o);
        this.setComponentOrientation(o);
    }

    protected Rectangle computePopupBounds(int px, int py, int pw, int ph) {
        int displayWidth = this.this$0.getDisplaySize().width;
        Border[] var6 = new Border[]{this.scroller.getViewportBorder(), this.scroller.getBorder()};
        int selectedIndex = var6.length;

        for(int var8 = 0; var8 < selectedIndex; ++var8) {
            Border border = var6[var8];
            if (border != null) {
                Insets borderInsets = border.getBorderInsets((Component)null);
                displayWidth += borderInsets.left + borderInsets.right;
            }
        }

        boolean isPopupOverComboBox = this.isPopupOverComboBox();
        selectedIndex = -1;
        if (isPopupOverComboBox && (selectedIndex = this.comboBox.getSelectedIndex()) >= 0) {
            displayWidth += MacCheckedItemIcon.INSTANCE.getIconWidth() + UIScale.scale(4);
        }

        JScrollBar verticalScrollBar = this.scroller.getVerticalScrollBar();
        if (verticalScrollBar != null) {
            displayWidth += verticalScrollBar.getPreferredSize().width;
        }

        int pw0 = pw;
        Insets listInsets;
        if (displayWidth > pw) {
            GraphicsConfiguration gc = this.comboBox.getGraphicsConfiguration();
            if (gc != null) {
                Rectangle screenBounds = gc.getBounds();
                listInsets = Toolkit.getDefaultToolkit().getScreenInsets(gc);
                displayWidth = Math.min(displayWidth, screenBounds.width - listInsets.left - listInsets.right);
            } else {
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                displayWidth = Math.min(displayWidth, screenSize.width);
            }

            int diff = displayWidth - pw;
            pw = displayWidth;
            if (!this.comboBox.getComponentOrientation().isLeftToRight()) {
                px -= diff;
            }
        }

        Rectangle cellBounds;
        if (isPopupOverComboBox && selectedIndex >= 0 && (cellBounds = this.list.getCellBounds(0, 0)) != null) {
            Insets comboBoxInsets = this.comboBox.getInsets();
            listInsets = this.list.getInsets();
            Insets popupInsets = this.getInsets();
            py -= cellBounds.height * (selectedIndex + 1) + comboBoxInsets.top + listInsets.top + popupInsets.top;
            int offset = Math.min(pw - pw0, MacCheckedItemIcon.INSTANCE.getIconWidth()) + UIScale.scale(4);
            if (this.comboBox.getComponentOrientation().isLeftToRight()) {
                px -= offset + comboBoxInsets.right + listInsets.right;
            } else {
                px += offset + comboBoxInsets.left + listInsets.left;
            }

            return new Rectangle(px, py, pw, ph);
        } else {
            return super.computePopupBounds(px, py, pw, ph);
        }
    }

    protected void configurePopup() {
        super.configurePopup();
        this.setOpaque(true);
        Border border = UIManager.getBorder("PopupMenu.border");
        if (border != null) {
            this.setBorder(FlatUIUtils.nonUIResource(border));
        }

        this.list.setCellRenderer(new PopupListCellRenderer((FlatComboBoxUI.1)null));
        this.updateStyle();
    }

    void updateStyle() {
        if (this.this$0.popupBackground != null) {
            this.list.setBackground(this.this$0.popupBackground);
        }

        this.setBackground(FlatUIUtils.nonUIResource(this.list.getBackground()));
        this.scroller.setViewportBorder(this.this$0.popupInsets != null ? new FlatEmptyBorder(this.this$0.popupInsets) : null);
        this.scroller.setOpaque(false);
        if (this.list.getUI() instanceof FlatListUI) {
            FlatListUI ui = (FlatListUI)this.list.getUI();
            ui.selectionInsets = this.this$0.selectionInsets;
            ui.selectionArc = this.this$0.selectionArc;
        }

    }

    protected PropertyChangeListener createPropertyChangeListener() {
        PropertyChangeListener superListener = super.createPropertyChangeListener();
        return (e) -> {
            superListener.propertyChange(e);
            if (e.getPropertyName() == "renderer") {
                this.list.setCellRenderer(new PopupListCellRenderer((FlatComboBoxUI.1)null));
            }

        };
    }

    protected int getPopupHeightForRowCount(int maxRowCount) {
        int height = super.getPopupHeightForRowCount(maxRowCount);
        FlatComboBoxUI.access$3500(this.this$0).uninstall();
        return height;
    }

    public void show(Component invoker, int x, int y) {
        if (y < 0 && !SystemInfo.isJava_9_orLater) {
            Border popupBorder = this.getBorder();
            if (popupBorder != null) {
                Insets insets = popupBorder.getBorderInsets(this);
                y -= insets.top + insets.bottom;
            }
        }

        if (this.list.getHeight() == 0) {
            int selectedIndex = this.list.getSelectedIndex();
            if (selectedIndex >= 1) {
                int maximumRowCount = this.comboBox.getMaximumRowCount();
                if (selectedIndex < maximumRowCount) {
                    this.list.scrollRectToVisible(new Rectangle());
                } else {
                    int firstVisibleIndex = Math.max(selectedIndex - maximumRowCount / 2, 0);
                    if (firstVisibleIndex > 0) {
                        this.list.ensureIndexIsVisible(firstVisibleIndex);
                    }
                }
            }
        }

        super.show(invoker, x, y);
    }

    protected void paintChildren(Graphics g) {
        super.paintChildren(g);
        FlatComboBoxUI.access$3500(this.this$0).uninstall();
    }

    private boolean isPopupOverComboBox() {
        return FlatComboBoxUI.access$2700(this.this$0) && !this.comboBox.isEditable() && this.comboBox.getItemCount() > 0 && this.comboBox.getItemCount() <= this.comboBox.getMaximumRowCount() && !FlatClientProperties.clientPropertyBoolean(this.comboBox, "JComboBox.isPopDown", false);
    }

    private class PopupListCellRenderer implements ListCellRenderer {
        private PopupListCellRenderer() {
        }

        public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            FlatComboBoxUI.access$3500(FlatComboBoxUI$FlatComboPopup.this.this$0).uninstall();
            ListCellRenderer renderer = FlatComboBoxUI$FlatComboPopup.this.comboBox.getRenderer();
            if (renderer == null) {
                renderer = new DefaultListCellRenderer();
            }

            Component c = ((ListCellRenderer)renderer).getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            c.applyComponentOrientation(FlatComboBoxUI$FlatComboPopup.this.comboBox.getComponentOrientation());
            if (FlatComboBoxUI$FlatComboPopup.this.isPopupOverComboBox() && c instanceof JComponent) {
                int selectedIndex = FlatComboBoxUI$FlatComboPopup.this.comboBox.getSelectedIndex();
                ((JComponent)c).putClientProperty("FlatLaf.internal.FlatComboBoxUI.macStyleHint", selectedIndex >= 0 ? index == selectedIndex : null);
            }

            FlatComboBoxUI.access$3500(FlatComboBoxUI$FlatComboPopup.this.this$0).install(c, Math.round(FlatUIUtils.getBorderFocusWidth(FlatComboBoxUI$FlatComboPopup.this.comboBox)));
            return c;
        }
    }
}
