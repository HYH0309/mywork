//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import com.formdev.flatlaf.util.UIScale;
import java.awt.Font;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.function.IntUnaryOperator;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

class FlatLaf$ActiveFont implements UIDefaults.ActiveValue {
    private final String baseFontKey;
    private final List<String> families;
    private final int style;
    private final int styleChange;
    private final int absoluteSize;
    private final int relativeSize;
    private final float scaleSize;
    private FontUIResource font;
    private Font lastBaseFont;
    private boolean inCreateValue;

    FlatLaf$ActiveFont(String baseFontKey, List<String> families, int style, int styleChange, int absoluteSize, int relativeSize, float scaleSize) {
        this.baseFontKey = baseFontKey;
        this.families = families;
        this.style = style;
        this.styleChange = styleChange;
        this.absoluteSize = absoluteSize;
        this.relativeSize = relativeSize;
        this.scaleSize = scaleSize;
    }

    public synchronized Object createValue(UIDefaults table) {
        if (this.inCreateValue) {
            throw new IllegalStateException("FlatLaf: endless recursion in font");
        } else {
            Font baseFont = null;
            this.inCreateValue = true;

            try {
                if (this.baseFontKey != null) {
                    baseFont = (Font)UIDefaultsLoader.lazyUIManagerGet(this.baseFontKey);
                }

                if (baseFont == null) {
                    baseFont = UIManager.getFont("defaultFont");
                }

                if (baseFont == null) {
                    baseFont = UIManager.getFont("Label.font");
                }
            } finally {
                this.inCreateValue = false;
            }

            if (this.lastBaseFont != baseFont) {
                this.lastBaseFont = baseFont;
                this.font = this.derive(baseFont, (fontSize) -> {
                    return UIScale.scale(fontSize);
                });
            }

            return this.font;
        }
    }

    FontUIResource derive(Font baseFont, IntUnaryOperator scale) {
        int baseStyle = baseFont.getStyle();
        int baseSize = baseFont.getSize();
        int newStyle = this.style != -1 ? this.style : (this.styleChange != 0 ? baseStyle & ~(this.styleChange >> 16 & '\uffff') | this.styleChange & '\uffff' : baseStyle);
        int newSize = this.absoluteSize > 0 ? scale.applyAsInt(this.absoluteSize) : (this.relativeSize != 0 ? baseSize + scale.applyAsInt(this.relativeSize) : (this.scaleSize > 0.0F ? Math.round((float)baseSize * this.scaleSize) : baseSize));
        if (newSize <= 0) {
            newSize = 1;
        }

        if (this.families != null && !this.families.isEmpty()) {
            label77: {
                String preferredFamily = preferredFamily(this.families);
                if (preferredFamily != null) {
                    Font font = FlatLaf.createCompositeFont(preferredFamily, newStyle, newSize);
                    if (!isFallbackFont(font) || isDialogFamily(preferredFamily)) {
                        return this.toUIResource(font);
                    }
                }

                Iterator var12 = this.families.iterator();

                String family;
                FontUIResource font;
                do {
                    if (!var12.hasNext()) {
                        break label77;
                    }

                    family = (String)var12.next();
                    font = FlatLaf.createCompositeFont(family, newStyle, newSize);
                } while(isFallbackFont(font) && !isDialogFamily(family));

                return this.toUIResource(font);
            }
        }

        if (newStyle == baseStyle && newSize == baseSize) {
            return this.toUIResource(baseFont);
        } else {
            if ("Ubuntu Medium".equalsIgnoreCase(baseFont.getName()) && "Ubuntu Light".equalsIgnoreCase(baseFont.getFamily())) {
                Font font = FlatLaf.createCompositeFont("Ubuntu Medium", newStyle, newSize);
                if (!isFallbackFont(font)) {
                    return this.toUIResource(font);
                }
            }

            return this.toUIResource(baseFont.deriveFont(newStyle, (float)newSize));
        }
    }

    private FontUIResource toUIResource(Font font) {
        return font instanceof FontUIResource ? (FontUIResource)font : new FontUIResource(font);
    }

    private static boolean isFallbackFont(Font font) {
        return "Dialog".equalsIgnoreCase(font.getFamily());
    }

    private static boolean isDialogFamily(String family) {
        return family.equalsIgnoreCase("Dialog");
    }

    private static String preferredFamily(List<String> families) {
        Iterator var1 = families.iterator();

        while(var1.hasNext()) {
            String family = (String)var1.next();
            family = family.toLowerCase(Locale.ENGLISH);
            if (!family.endsWith(" light") && !family.endsWith("-thin")) {
                if (!family.endsWith(" semibold") && !family.endsWith("-medium")) {
                    if (family.equals("monospaced")) {
                        return FlatLaf.access$500();
                    }
                    continue;
                }

                return FlatLaf.access$400();
            }

            return FlatLaf.access$300();
        }

        return null;
    }
}
