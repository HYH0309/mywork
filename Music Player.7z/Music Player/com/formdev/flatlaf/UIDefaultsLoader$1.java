//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import com.formdev.flatlaf.UIDefaultsLoader.ValueType;

// $FF: synthetic class
class UIDefaultsLoader$1 {
    static {
        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.STRING.ordinal()] = 1;
        } catch (NoSuchFieldError var20) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.BOOLEAN.ordinal()] = 2;
        } catch (NoSuchFieldError var19) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.CHARACTER.ordinal()] = 3;
        } catch (NoSuchFieldError var18) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.INTEGER.ordinal()] = 4;
        } catch (NoSuchFieldError var17) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.INTEGERORFLOAT.ordinal()] = 5;
        } catch (NoSuchFieldError var16) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.FLOAT.ordinal()] = 6;
        } catch (NoSuchFieldError var15) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.BORDER.ordinal()] = 7;
        } catch (NoSuchFieldError var14) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.ICON.ordinal()] = 8;
        } catch (NoSuchFieldError var13) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.INSETS.ordinal()] = 9;
        } catch (NoSuchFieldError var12) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.DIMENSION.ordinal()] = 10;
        } catch (NoSuchFieldError var11) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.COLOR.ordinal()] = 11;
        } catch (NoSuchFieldError var10) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.FONT.ordinal()] = 12;
        } catch (NoSuchFieldError var9) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.SCALEDINTEGER.ordinal()] = 13;
        } catch (NoSuchFieldError var8) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.SCALEDFLOAT.ordinal()] = 14;
        } catch (NoSuchFieldError var7) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.SCALEDINSETS.ordinal()] = 15;
        } catch (NoSuchFieldError var6) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.SCALEDDIMENSION.ordinal()] = 16;
        } catch (NoSuchFieldError var5) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.INSTANCE.ordinal()] = 17;
        } catch (NoSuchFieldError var4) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.CLASS.ordinal()] = 18;
        } catch (NoSuchFieldError var3) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.GRAYFILTER.ordinal()] = 19;
        } catch (NoSuchFieldError var2) {
        }

        try {
            $SwitchMap$com$formdev$flatlaf$UIDefaultsLoader$ValueType[ValueType.UNKNOWN.ordinal()] = 20;
        } catch (NoSuchFieldError var1) {
        }

    }
}
