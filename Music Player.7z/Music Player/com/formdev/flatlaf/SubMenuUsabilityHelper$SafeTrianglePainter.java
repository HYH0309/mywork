//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.awt.Color;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.JLayeredPane;
import javax.swing.JPopupMenu;
import javax.swing.RootPaneContainer;
import javax.swing.SwingUtilities;

class SubMenuUsabilityHelper$SafeTrianglePainter extends JComponent {
    SubMenuUsabilityHelper$SafeTrianglePainter(SubMenuUsabilityHelper var1, JPopupMenu popup) {
        this.this$0 = var1;
        Window window = SwingUtilities.windowForComponent(popup.getInvoker());
        if (window instanceof RootPaneContainer) {
            JLayeredPane layeredPane = ((RootPaneContainer)window).getLayeredPane();
            this.setSize(layeredPane.getSize());
            layeredPane.add(this, JLayeredPane.POPUP_LAYER + 1);
        }

    }

    void uninstall() {
        Container parent = this.getParent();
        if (parent != null) {
            parent.remove(this);
            parent.repaint();
        }

    }

    protected void paintComponent(Graphics g) {
        Point locationOnScreen = this.getLocationOnScreen();
        g.translate(-locationOnScreen.x, -locationOnScreen.y);
        g.setColor(Color.red);
        ((Graphics2D)g).draw(SubMenuUsabilityHelper.access$100(this.this$0));
    }
}
