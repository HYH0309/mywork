//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class MnemonicHandler$1 extends WindowAdapter {
    MnemonicHandler$1() {
    }

    public void windowDeactivated(WindowEvent e) {
        MnemonicHandler.access$002(0);
        MnemonicHandler.access$102(false);
        EventQueue.invokeLater(() -> {
            MnemonicHandler.showMnemonics(false, (Component)null);
        });
    }
}
