//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf;

import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.plaf.UIResource;

class FlatLaf$ImageIconUIResource extends ImageIcon implements UIResource {
    FlatLaf$ImageIconUIResource(Image image) {
        super(image);
    }
}
