//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.LookAndFeel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class MusicPlayerGUI extends JFrame {
    private final JTextField now_play;
    private final MusicList musicList = new MusicList();
    private MusicScrollPane musicScrollPane;
    private final MusicProgressBar musicProgressBar;
    private final MusicPlayer player = new MusicPlayer();
    private final JRadioButton loopCheckBox;
    private final JSlider volumeSlider;

    public MusicPlayerGUI() throws IOException {
        this.setVisible(false);
        this.setTitle("�Ź�2����ݵ�MusicPlayer");
        this.setSize(750, 464);
        this.setDefaultCloseOperation(3);
        this.setLayout(new BorderLayout());
        this.setResizable(false);
        JPanel mainPanel = new JPanel();
        JPanel showPanel = new JPanel();
        showPanel.setLayout(new BorderLayout());
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setOpaque(false);
        mainPanel.setBackground(new Color(0, 0, 0, 0));
        this.now_play = new JTextField(30);
        this.now_play.setEditable(false);
        this.volumeSlider = new JSlider(0, 0, 100, 80);
        this.musicScrollPane = new MusicScrollPane(this.musicList);
        this.musicProgressBar = new MusicProgressBar();
        ImageIcon open = new ImageIcon((URL)Objects.requireNonNull(this.getClass().getResource("resources/Open.png")));
        ImageIcon play = new ImageIcon((URL)Objects.requireNonNull(this.getClass().getResource("resources/Play.png")));
        ImageIcon stop = new ImageIcon((URL)Objects.requireNonNull(this.getClass().getResource("resources/Stop.png")));
        ImageIcon openScaled = new ImageIcon(open.getImage().getScaledInstance(50, 50, 4));
        ImageIcon playScaled = new ImageIcon(play.getImage().getScaledInstance(50, 50, 4));
        ImageIcon stopScaled = new ImageIcon(stop.getImage().getScaledInstance(50, 50, 4));
        this.loopCheckBox = new JRadioButton("����ѭ��");
        JButton toggleStyleButton = new JButton("��/��");
        JButton version = new JButton("˵��");
        version.setSize(10, 10);
        JButton openButton = new JButton("Open");
        openButton.setIcon(openScaled);
        JButton playButton = new JButton("Play");
        playButton.setIcon(playScaled);
        JButton stopButton = new JButton("Stop");
        stopButton.setIcon(stopScaled);
        JPanel controlPanel = new JPanel();
        JPanel text = new JPanel();
        text.add(this.now_play);
        showPanel.add(text, "North");
        showPanel.add(this.musicProgressBar, "South");
        showPanel.add(this.volumeSlider);
        controlPanel.add(openButton);
        controlPanel.add(playButton);
        controlPanel.add(stopButton);
        controlPanel.add(version);
        controlPanel.add(this.loopCheckBox);
        controlPanel.add(toggleStyleButton);
        mainPanel.add(this.musicScrollPane, "Center");
        mainPanel.add(showPanel, "South");
        mainPanel.add(controlPanel, "North");
        toggleStyleButton.addActionListener((e) -> {
            LookAndFeel currentLookAndFeel = UIManager.getLookAndFeel();

            try {
                if (currentLookAndFeel instanceof FlatLightLaf) {
                    UIManager.setLookAndFeel(new FlatDarkLaf());
                } else {
                    UIManager.setLookAndFeel(new FlatLightLaf());
                }

                SwingUtilities.updateComponentTreeUI(this);
            } catch (Exception var4) {
                Exception ex = var4;
                ex.printStackTrace();
            }

        });
        openButton.addActionListener((e) -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(1);
            int result = fileChooser.showOpenDialog((Component)null);
            if (result == 0) {
                mainPanel.remove(this.musicScrollPane);
                File selectedFile = fileChooser.getSelectedFile();
                this.now_play.setText(selectedFile.getAbsolutePath());

                try {
                    this.musicList.readWavFiles(this.now_play.getText());
                } catch (IOException var7) {
                    IOException ex = var7;
                    throw new RuntimeException(ex);
                }

                this.musicScrollPane = new MusicScrollPane(this.musicList);
                mainPanel.add(this.musicScrollPane, "Center");
                this.revalidate();
                this.repaint();
            }

        });
        playButton.addActionListener((e) -> {
            String selectedFilePath = this.musicScrollPane.getSelectedFilePath();
            if (selectedFilePath != null) {
                try {
                    this.player.play(selectedFilePath);
                    this.musicProgressBar.start();
                    this.musicProgressBar.setMaximum((int)(this.player.getClip().getMicrosecondLength() / 1000000L));
                    this.now_play.setText(selectedFilePath);
                } catch (Exception var4) {
                    Exception ex = var4;
                    this.showErrorMessage("���ų���: " + ex.getMessage());
                }
            }

        });
        stopButton.addActionListener((e) -> {
            this.player.stop();
            this.musicProgressBar.stop();
        });
        version.addActionListener((e) -> {
            Musicshow dialog = new Musicshow();
            dialog.showPopup();
        });
        this.loopCheckBox.addActionListener((e) -> {
            boolean isLoop = this.loopCheckBox.isSelected();
            this.player.setLoop(isLoop);
        });
        this.volumeSlider.setMajorTickSpacing(10);
        this.volumeSlider.setMinorTickSpacing(1);
        this.volumeSlider.setPaintTicks(true);
        this.volumeSlider.setPaintLabels(true);
        this.getContentPane().add(mainPanel);
        this.volumeSlider.addChangeListener((e) -> {
            JSlider source = (JSlider)e.getSource();
            if (!source.getValueIsAdjusting()) {
                int volume = source.getValue();
                this.player.setVolume((float)volume / 100.0F);
            }

        });
        this.musicProgressBar.setFocusable(true);
        this.musicProgressBar.getInputMap(2).put(KeyStroke.getKeyStroke(44, 0), "decrement");
        this.musicProgressBar.getInputMap(2).put(KeyStroke.getKeyStroke(46, 0), "increment");
        this.musicProgressBar.getActionMap().put("decrement", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (MusicPlayerGUI.this.player.getClip().isRunning()) {
                    int currentPosition = MusicPlayerGUI.this.musicProgressBar.getValue();
                    long length = MusicPlayerGUI.this.player.getClip().getMicrosecondLength();
                    long newPosition = TimeUnit.SECONDS.toMicros((long)currentPosition) - TimeUnit.SECONDS.toMicros(10L);
                    if (newPosition < 0L) {
                        newPosition = 0L;
                    }

                    MusicPlayerGUI.this.musicProgressBar.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                    MusicPlayerGUI.this.player.setMicrosecondPosition(newPosition);
                }

            }
        });
        this.musicProgressBar.getActionMap().put("increment", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (MusicPlayerGUI.this.player.getClip().isRunning()) {
                    int currentPosition = MusicPlayerGUI.this.musicProgressBar.getValue();
                    long length = MusicPlayerGUI.this.player.getClip().getMicrosecondLength();
                    long newPosition = TimeUnit.SECONDS.toMicros((long)currentPosition) + TimeUnit.SECONDS.toMicros(10L);
                    if (newPosition > length) {
                        newPosition = length;
                    }

                    MusicPlayerGUI.this.musicProgressBar.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                    MusicPlayerGUI.this.player.setMicrosecondPosition(newPosition);
                }

            }
        });
    }

    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "����", 0);
    }

    class MusicProgressBar extends JProgressBar implements Runnable {
        private boolean isRunning = false;
        private boolean isDragging = false;

        MusicProgressBar() {
            this.setStringPainted(true);
            this.setValue(0);
            this.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent evt) {
                    MusicProgressBar.this.isDragging = true;
                }

                public void mouseReleased(MouseEvent evt) {
                    MusicProgressBar.this.isDragging = false;
                    if (MusicPlayerGUI.this.player.getClip() == null) {
                        JOptionPane.showMessageDialog((Component)null, "�㻹û��ѡ�������");
                    } else {
                        int mouseX = evt.getX();
                        long length = MusicPlayerGUI.this.player.getClip().getMicrosecondLength();
                        long newPosition = (long)((double)mouseX / (double)MusicProgressBar.this.getWidth() * (double)length);
                        MusicPlayerGUI.this.player.setMicrosecondPosition(newPosition);
                        MusicProgressBar.this.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                    }
                }
            });
            this.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseDragged(MouseEvent evt) {
                    if (MusicProgressBar.this.isDragging) {
                        if (MusicPlayerGUI.this.player.getClip() == null) {
                            JOptionPane.showMessageDialog((Component)null, "�㻹û��ѡ�������");
                            return;
                        }

                        int mouseX = evt.getX();
                        long length = MusicPlayerGUI.this.player.getClip().getMicrosecondLength();
                        long newPosition = (long)((double)mouseX / (double)MusicProgressBar.this.getWidth() * (double)length);
                        MusicProgressBar.this.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                    }

                }
            });
        }

        void start() {
            this.isRunning = true;
            Thread thread = new Thread(this);
            thread.start();
        }

        void stop() {
            this.isRunning = false;
        }

        public void run() {
            while(this.isRunning) {
                int progress = MusicPlayerGUI.this.player.getProgress();
                if (!MusicPlayerGUI.this.player.getClip().isRunning() && MusicPlayerGUI.this.player.getClip().getMicrosecondPosition() >= MusicPlayerGUI.this.player.getClip().getMicrosecondLength()) {
                    this.setValue(0);
                    this.stop();
                } else {
                    this.setValue(progress);
                }

                try {
                    TimeUnit.MILLISECONDS.sleep(500L);
                } catch (InterruptedException var3) {
                    InterruptedException e = var3;
                    MusicPlayerGUI.this.showErrorMessage("���ų���: " + e.getMessage());
                } catch (NullPointerException var4) {
                    JOptionPane.showMessageDialog((Component)null, "No music is currently playing.", "No Music", 2);
                }
            }

        }
    }
}
