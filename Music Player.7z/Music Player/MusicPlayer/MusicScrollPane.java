//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.awt.BorderLayout;
import java.io.File;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MusicScrollPane extends JPanel {
    private final JList<String> musicJList;
    private final String[] musicPaths;

    public MusicScrollPane(MusicList musicList) {
        this.setLayout(new BorderLayout());
        this.musicPaths = musicList.getMusicPaths();
        String[] musicNames = new String[this.musicPaths.length];

        for(int i = 0; i < this.musicPaths.length; ++i) {
            musicNames[i] = this.getRelativePath(this.musicPaths[i]);
        }

        this.musicJList = new JList(musicNames);
        JScrollPane scrollPane = new JScrollPane(this.musicJList);
        this.add(scrollPane, "Center");
    }

    public String getSelectedFilePath() {
        int selectedIndex = this.musicJList.getSelectedIndex();
        return selectedIndex != -1 ? this.musicPaths[selectedIndex] : null;
    }

    private String getRelativePath(String absolutePath) {
        File file = new File(absolutePath);
        String fileName = file.getName();
        int lastDotIndex = fileName.lastIndexOf(".");
        if (lastDotIndex != -1) {
            fileName = fileName.substring(0, lastDotIndex);
        }

        return fileName;
    }
}
