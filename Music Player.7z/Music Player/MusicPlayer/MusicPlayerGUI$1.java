//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.awt.event.ActionEvent;
import java.util.concurrent.TimeUnit;
import javax.swing.AbstractAction;

class MusicPlayerGUI$1 extends AbstractAction {
    MusicPlayerGUI$1(final MusicPlayerGUI this$0) {
        this.this$0 = this$0;
    }

    public void actionPerformed(ActionEvent e) {
        if (this.this$0.player.getClip().isRunning()) {
            int currentPosition = this.this$0.musicProgressBar.getValue();
            long length = this.this$0.player.getClip().getMicrosecondLength();
            long newPosition = TimeUnit.SECONDS.toMicros((long)currentPosition) - TimeUnit.SECONDS.toMicros(10L);
            if (newPosition < 0L) {
                newPosition = 0L;
            }

            this.this$0.musicProgressBar.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
            this.this$0.player.setMicrosecondPosition(newPosition);
        }

    }
}
