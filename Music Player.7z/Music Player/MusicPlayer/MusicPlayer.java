//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.sound.sampled.FloatControl.Type;
import javax.swing.JOptionPane;

public class MusicPlayer {
    private Clip clip;
    private boolean loop = false;
    private boolean repeat = false;

    public MusicPlayer() {
    }

    public void play(String filePath) {
        if (this.clip != null && this.clip.isRunning()) {
            this.stop();
        }

        try {
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(filePath));

            try {
                AudioFormat format = audioStream.getFormat();
                DataLine.Info info = new DataLine.Info(Clip.class, format);
                this.clip = (Clip)AudioSystem.getLine(info);
                this.clip.open(audioStream);
                if (this.repeat) {
                    this.clip.loop(-1);
                } else {
                    this.clip.loop(this.loop ? -1 : 0);
                }
            } catch (Throwable var6) {
                if (audioStream != null) {
                    try {
                        audioStream.close();
                    } catch (Throwable var5) {
                        var6.addSuppressed(var5);
                    }
                }

                throw var6;
            }

            if (audioStream != null) {
                audioStream.close();
            }
        } catch (LineUnavailableException | IOException | UnsupportedAudioFileException var7) {
            Exception e = var7;
            JOptionPane.showMessageDialog((Component)null, "Failed to play audio: " + e.getMessage(), "Error", 0);
        }

    }

    public void stop() {
        if (this.clip != null && this.clip.isRunning()) {
            this.clip.stop();
            this.clip.close();
        }

    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public int getProgress() {
        return this.clip != null ? (int)(this.clip.getMicrosecondPosition() / 1000000L) : 0;
    }

    public Clip getClip() {
        return this.clip;
    }

    public void setMicrosecondPosition(long position) {
        if (this.clip != null) {
            this.clip.setMicrosecondPosition(position);
        }

    }

    public void setVolume(float volume) {
        if (this.clip != null) {
            FloatControl control = (FloatControl)this.clip.getControl(Type.MASTER_GAIN);
            float min = control.getMinimum();
            float max = control.getMaximum();
            control.setValue(min + (max - min) * volume);
        }

    }
}
