//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import com.formdev.flatlaf.FlatLightLaf;
import java.io.IOException;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class launch {
    public launch() {
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
        } catch (Exception var2) {
            Exception ex = var2;
            ex.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            MusicPlayerGUI musicPlayerGUI = null;

            try {
                musicPlayerGUI = new MusicPlayerGUI();
            } catch (IOException var2) {
                IOException e = var2;
                throw new RuntimeException(e);
            }

            musicPlayerGUI.setVisible(true);
        });
    }
}
