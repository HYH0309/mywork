//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MusicList {
    private List<String> musicPaths = new ArrayList();

    public MusicList() {
    }

    public void readWavFiles(String folderPath) throws IOException {
        File folder = new File(folderPath);
        if (folder.exists() && folder.isDirectory()) {
            this.clear();
            File[] wavFiles = folder.listFiles((dir, name) -> {
                return name.endsWith(".wav");
            });
            if (wavFiles != null) {
                File[] var4 = wavFiles;
                int var5 = wavFiles.length;

                for(int var6 = 0; var6 < var5; ++var6) {
                    File file = var4[var6];
                    this.addToMusicList(file.getAbsolutePath());
                }
            }

        } else {
            throw new IOException("�ļ��в����ڣ�");
        }
    }

    private void addToMusicList(String path) {
        this.musicPaths.add(path);
    }

    public String[] getMusicPaths() {
        return (String[])this.musicPaths.toArray(new String[0]);
    }

    public void clear() {
        this.musicPaths.clear();
    }
}
