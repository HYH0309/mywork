//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;

class MusicPlayerGUI$MusicProgressBar extends JProgressBar implements Runnable {
    private boolean isRunning;
    private boolean isDragging;

    MusicPlayerGUI$MusicProgressBar(final MusicPlayerGUI this$0) {
        this.this$0 = this$0;
        this.isRunning = false;
        this.isDragging = false;
        this.setStringPainted(true);
        this.setValue(0);
        this.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent evt) {
                MusicPlayerGUI$MusicProgressBar.this.isDragging = true;
            }

            public void mouseReleased(MouseEvent evt) {
                MusicPlayerGUI$MusicProgressBar.this.isDragging = false;
                if (MusicPlayerGUI$MusicProgressBar.this.this$0.player.getClip() == null) {
                    JOptionPane.showMessageDialog((Component)null, "�㻹û��ѡ�������");
                } else {
                    int mouseX = evt.getX();
                    long length = MusicPlayerGUI$MusicProgressBar.this.this$0.player.getClip().getMicrosecondLength();
                    long newPosition = (long)((double)mouseX / (double)MusicPlayerGUI$MusicProgressBar.this.getWidth() * (double)length);
                    MusicPlayerGUI$MusicProgressBar.this.this$0.player.setMicrosecondPosition(newPosition);
                    MusicPlayerGUI$MusicProgressBar.this.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                }
            }
        });
        this.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent evt) {
                if (MusicPlayerGUI$MusicProgressBar.this.isDragging) {
                    if (MusicPlayerGUI$MusicProgressBar.this.this$0.player.getClip() == null) {
                        JOptionPane.showMessageDialog((Component)null, "�㻹û��ѡ�������");
                        return;
                    }

                    int mouseX = evt.getX();
                    long length = MusicPlayerGUI$MusicProgressBar.this.this$0.player.getClip().getMicrosecondLength();
                    long newPosition = (long)((double)mouseX / (double)MusicPlayerGUI$MusicProgressBar.this.getWidth() * (double)length);
                    MusicPlayerGUI$MusicProgressBar.this.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
                }

            }
        });
    }

    void start() {
        this.isRunning = true;
        Thread thread = new Thread(this);
        thread.start();
    }

    void stop() {
        this.isRunning = false;
    }

    public void run() {
        while(this.isRunning) {
            int progress = this.this$0.player.getProgress();
            if (!this.this$0.player.getClip().isRunning() && this.this$0.player.getClip().getMicrosecondPosition() >= this.this$0.player.getClip().getMicrosecondLength()) {
                this.setValue(0);
                this.stop();
            } else {
                this.setValue(progress);
            }

            try {
                TimeUnit.MILLISECONDS.sleep(500L);
            } catch (InterruptedException var3) {
                InterruptedException e = var3;
                this.this$0.showErrorMessage("���ų���: " + e.getMessage());
            } catch (NullPointerException var4) {
                JOptionPane.showMessageDialog((Component)null, "No music is currently playing.", "No Music", 2);
            }
        }

    }
}
