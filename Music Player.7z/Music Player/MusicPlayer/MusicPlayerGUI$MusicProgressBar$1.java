//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package MusicPlayer;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;

class MusicPlayerGUI$MusicProgressBar$1 extends MouseAdapter {
    MusicPlayerGUI$MusicProgressBar$1(final MusicPlayerGUI.MusicProgressBar this$1, final MusicPlayerGUI var2) {
        this.this$1 = this$1;
        this.val$this$0 = var2;
    }

    public void mousePressed(MouseEvent evt) {
        this.this$1.isDragging = true;
    }

    public void mouseReleased(MouseEvent evt) {
        this.this$1.isDragging = false;
        if (this.this$1.this$0.player.getClip() == null) {
            JOptionPane.showMessageDialog((Component)null, "�㻹û��ѡ�������");
        } else {
            int mouseX = evt.getX();
            long length = this.this$1.this$0.player.getClip().getMicrosecondLength();
            long newPosition = (long)((double)mouseX / (double)this.this$1.getWidth() * (double)length);
            this.this$1.this$0.player.setMicrosecondPosition(newPosition);
            this.this$1.setValue((int)TimeUnit.MICROSECONDS.toSeconds(newPosition));
        }
    }
}
