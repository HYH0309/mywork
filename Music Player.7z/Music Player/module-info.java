//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

module com.formdev.flatlaf {
    requires java.desktop;

    exports com.formdev.flatlaf;
    exports com.formdev.flatlaf.icons;
    exports com.formdev.flatlaf.themes;
    exports com.formdev.flatlaf.ui;
    exports com.formdev.flatlaf.util;

    opens com.formdev.flatlaf.resources;

    uses com.formdev.flatlaf.FlatDefaultsAddon;
}
