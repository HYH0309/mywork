//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.AbstractMultiResolutionImage;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.function.Function;
import javax.swing.ImageIcon;

class MultiResolutionImageSupport$ProducerMultiResolutionImage extends AbstractMultiResolutionImage {
    private final Dimension[] dimensions;
    private final Function<Dimension, Image> producer;
    private final IdentityHashMap<Dimension, Image> cache = new IdentityHashMap();

    MultiResolutionImageSupport$ProducerMultiResolutionImage(Dimension[] dimensions, Function<Dimension, Image> producer) {
        this.dimensions = dimensions;
        this.producer = producer;
    }

    public Image getResolutionVariant(double destImageWidth, double destImageHeight) {
        return this.produceAndCacheImage(new Dimension((int)destImageWidth, (int)destImageHeight));
    }

    public List<Image> getResolutionVariants() {
        List<Image> mappedVariants = new ArrayList();
        Dimension[] var2 = this.dimensions;
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            Dimension size = var2[var4];
            mappedVariants.add(this.produceAndCacheImage(size));
        }

        return mappedVariants;
    }

    protected Image getBaseImage() {
        return this.produceAndCacheImage(this.dimensions[0]);
    }

    private Image produceAndCacheImage(Dimension size) {
        return (Image)this.cache.computeIfAbsent(size, (size2) -> {
            return (new ImageIcon((Image)this.producer.apply(size2))).getImage();
        });
    }
}
