//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.image.AbstractMultiResolutionImage;
import java.awt.image.BaseMultiResolutionImage;
import java.awt.image.MultiResolutionImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import javax.swing.ImageIcon;

public class MultiResolutionImageSupport {
    public MultiResolutionImageSupport() {
    }

    public static boolean isAvailable() {
        return true;
    }

    public static boolean isMultiResolutionImage(Image image) {
        return image instanceof MultiResolutionImage;
    }

    public static Image create(int baseImageIndex, Image... resolutionVariants) {
        return new BaseMultiResolutionImage(baseImageIndex, resolutionVariants);
    }

    public static Image create(int baseImageIndex, Dimension[] dimensions, Function<Dimension, Image> producer) {
        return new ProducerMultiResolutionImage(dimensions, producer);
    }

    public static Image map(Image image, Function<Image, Image> mapper) {
        return (Image)(image instanceof MultiResolutionImage ? new MappedMultiResolutionImage(image, mapper) : (Image)mapper.apply(image));
    }

    public static Image getResolutionVariant(Image image, int destImageWidth, int destImageHeight) {
        return image instanceof MultiResolutionImage ? ((MultiResolutionImage)image).getResolutionVariant((double)destImageWidth, (double)destImageHeight) : image;
    }

    public static List<Image> getResolutionVariants(Image image) {
        return image instanceof MultiResolutionImage ? ((MultiResolutionImage)image).getResolutionVariants() : Collections.singletonList(image);
    }

    private static class ProducerMultiResolutionImage extends AbstractMultiResolutionImage {
        private final Dimension[] dimensions;
        private final Function<Dimension, Image> producer;
        private final IdentityHashMap<Dimension, Image> cache = new IdentityHashMap();

        ProducerMultiResolutionImage(Dimension[] dimensions, Function<Dimension, Image> producer) {
            this.dimensions = dimensions;
            this.producer = producer;
        }

        public Image getResolutionVariant(double destImageWidth, double destImageHeight) {
            return this.produceAndCacheImage(new Dimension((int)destImageWidth, (int)destImageHeight));
        }

        public List<Image> getResolutionVariants() {
            List<Image> mappedVariants = new ArrayList();
            Dimension[] var2 = this.dimensions;
            int var3 = var2.length;

            for(int var4 = 0; var4 < var3; ++var4) {
                Dimension size = var2[var4];
                mappedVariants.add(this.produceAndCacheImage(size));
            }

            return mappedVariants;
        }

        protected Image getBaseImage() {
            return this.produceAndCacheImage(this.dimensions[0]);
        }

        private Image produceAndCacheImage(Dimension size) {
            return (Image)this.cache.computeIfAbsent(size, (size2) -> {
                return (new ImageIcon((Image)this.producer.apply(size2))).getImage();
            });
        }
    }

    private static class MappedMultiResolutionImage extends AbstractMultiResolutionImage {
        private final Image mrImage;
        private final Function<Image, Image> mapper;
        private final IdentityHashMap<Image, Image> cache = new IdentityHashMap();

        MappedMultiResolutionImage(Image mrImage, Function<Image, Image> mapper) {
            assert mrImage instanceof MultiResolutionImage;

            this.mrImage = mrImage;
            this.mapper = mapper;
        }

        public Image getResolutionVariant(double destImageWidth, double destImageHeight) {
            Image variant = ((MultiResolutionImage)this.mrImage).getResolutionVariant(destImageWidth, destImageHeight);
            return this.mapAndCacheImage(variant);
        }

        public List<Image> getResolutionVariants() {
            List<Image> variants = ((MultiResolutionImage)this.mrImage).getResolutionVariants();
            List<Image> mappedVariants = new ArrayList();
            Iterator var3 = variants.iterator();

            while(var3.hasNext()) {
                Image image = (Image)var3.next();
                mappedVariants.add(this.mapAndCacheImage(image));
            }

            return mappedVariants;
        }

        protected Image getBaseImage() {
            return this.mapAndCacheImage(this.mrImage);
        }

        private Image mapAndCacheImage(Image image) {
            return (Image)this.cache.computeIfAbsent(image, (img) -> {
                return (new ImageIcon((Image)this.mapper.apply(img))).getImage();
            });
        }
    }
}
