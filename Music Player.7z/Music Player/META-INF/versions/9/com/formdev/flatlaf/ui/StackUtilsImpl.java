//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.ui;

import java.util.function.BiPredicate;

class StackUtilsImpl extends StackUtils {
    StackUtilsImpl() {
    }

    boolean wasInvokedFromImpl(BiPredicate<String, String> predicate, int limit) {
        return (Boolean)StackWalker.getInstance().walk((stream) -> {
            if (limit > 0) {
                stream = stream.limit((long)(limit + 2));
            }

            return stream.anyMatch((f) -> {
                return predicate.test(f.getClassName(), f.getMethodName());
            });
        });
    }
}
