//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import java.awt.Image;
import java.awt.image.AbstractMultiResolutionImage;
import java.awt.image.MultiResolutionImage;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import javax.swing.ImageIcon;

class MultiResolutionImageSupport$MappedMultiResolutionImage extends AbstractMultiResolutionImage {
    private final Image mrImage;
    private final Function<Image, Image> mapper;
    private final IdentityHashMap<Image, Image> cache = new IdentityHashMap();

    MultiResolutionImageSupport$MappedMultiResolutionImage(Image mrImage, Function<Image, Image> mapper) {
        if (!$assertionsDisabled && !(mrImage instanceof MultiResolutionImage)) {
            throw new AssertionError();
        } else {
            this.mrImage = mrImage;
            this.mapper = mapper;
        }
    }

    public Image getResolutionVariant(double destImageWidth, double destImageHeight) {
        Image variant = ((MultiResolutionImage)this.mrImage).getResolutionVariant(destImageWidth, destImageHeight);
        return this.mapAndCacheImage(variant);
    }

    public List<Image> getResolutionVariants() {
        List<Image> variants = ((MultiResolutionImage)this.mrImage).getResolutionVariants();
        List<Image> mappedVariants = new ArrayList();
        Iterator var3 = variants.iterator();

        while(var3.hasNext()) {
            Image image = (Image)var3.next();
            mappedVariants.add(this.mapAndCacheImage(image));
        }

        return mappedVariants;
    }

    protected Image getBaseImage() {
        return this.mapAndCacheImage(this.mrImage);
    }

    private Image mapAndCacheImage(Image image) {
        return (Image)this.cache.computeIfAbsent(image, (img) -> {
            return (new ImageIcon((Image)this.mapper.apply(img))).getImage();
        });
    }
}
