//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.formdev.flatlaf.util;

import com.formdev.flatlaf.FlatLaf;
import java.lang.System.Logger.Level;

class LoggingFacadeImpl implements LoggingFacade {
    private static final System.Logger LOG = System.getLogger(FlatLaf.class.getName());

    LoggingFacadeImpl() {
    }

    public void logSevere(String message, Throwable t) {
        LOG.log(Level.ERROR, message, t);
    }

    public void logConfig(String message, Throwable t) {
        LOG.log(Level.DEBUG, message, t);
    }
}
